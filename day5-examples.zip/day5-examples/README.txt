Day 5 - Reusable Modules: example files
=======================================

1. Copy the folder  practice/day5  (including its  shop  sub-folder) into your
   novaretail-toolkit project:  novaretail-toolkit/practice/day5/...
2. Copy the folder  lab5  into the project root.
3. Activate the venv; start the mock API in a second terminal:  python mock_api/server.py
4. Run each example from the project root, in order:
       python practice/day5/d5_01_modules_and_imports.py
       ...
       python practice/day5/d5_07_entry_points.py
   Only Example 05 needs the mock API.

Lab 5 (novaretail watchlist command)
   Follow Part 3 of the Day 5 guide: small additions to
   src/novaretail/transform.py, workflow.py and cli.py.
   lab5/solution/  holds the three complete files after the lab (trainer reference).
   lab5/watchlist.csv  -> data/input/watchlist.csv  if it is missing.
   Expected:  novaretail watchlist --file data/input/watchlist.csv
              -> Watchlist: 5 watched, 3 alert(s), 1 unknown      (exit code 0)
              pytest -> 48 passed
