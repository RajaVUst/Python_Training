"""
Day 5 - Example 03: Draw the capstone's module map and check the layers

WHAT THIS EXAMPLE TEACHES
  * How the novaretail package is split: one job per module.
  * Which module imports which (read from the source code, not guessed).
  * The LAYER RULE: a module may import from layers BELOW it, never from layers above.
        4 interface      cli
        3 orchestration  workflow
        2 services       api_client, file_ops, transform, logging_setup
        1 foundation     config, models, exceptions
    Breaking the rule causes circular imports and makes low-level code impossible to
    reuse or test on its own.
  * The script reads each .py file with the `ast` module (Python's own code parser),
    collects its imports, and flags any import that points UP.

WHERE THE CAPSTONE USES THIS
  The whole src/novaretail/ package. Run this again after Lab 5 to prove your new code
  kept the rule.

RUN (no API needed):
  python practice/day5/d5_03_module_map.py
"""
import ast
from pathlib import Path

import novaretail

PACKAGE_DIR = Path(novaretail.__file__).parent          # .../src/novaretail
LAYERS = {                                              # module name -> layer number
    "config": 1, "models": 1, "exceptions": 1,
    "api_client": 2, "file_ops": 2, "transform": 2, "logging_setup": 2,
    "workflow": 3,
    "cli": 4,
}


def first_doc_line(tree: ast.Module) -> str:
    """The first line of the module's docstring: what the module is for."""
    doc = ast.get_docstring(tree) or ""
    return doc.strip().splitlines()[0] if doc else "(no docstring)"


def internal_imports(tree: ast.Module) -> set[str]:
    """Names of novaretail modules imported by this module (relative or absolute)."""
    found = set()
    for node in ast.walk(tree):                         # visit every node of the code tree
        if isinstance(node, ast.ImportFrom):            # from .x import y  /  from novaretail.x import y
            if node.level == 1 and node.module:         # level 1 = one dot = this package
                found.add(node.module.split(".")[0])
            elif node.module and node.module.startswith("novaretail."):
                found.add(node.module.split(".")[1])
    return found & set(LAYERS)                          # keep only modules we know


# ---------------------------------------------------------------- 1. Read every module
modules = {}
for path in sorted(PACKAGE_DIR.glob("*.py")):
    name = path.stem
    if name not in LAYERS:                              # __init__ and __main__ are not layers
        continue
    tree = ast.parse(path.read_text(encoding="utf-8"))
    modules[name] = {"doc": first_doc_line(tree), "imports": internal_imports(tree),
                     "lines": len(path.read_text(encoding="utf-8").splitlines())}

# ---------------------------------------------------------------- 2. Print the map, top layer first
print("1. module map (layer: module  lines  -> imports)")
for name in sorted(modules, key=lambda n: (-LAYERS[n], n)):
    info = modules[name]
    deps = ", ".join(sorted(info["imports"])) or "-"
    print(f"   {LAYERS[name]}: {name:<14} {info['lines']:>4}  -> {deps}")

print("2. what each module is for")
for name in sorted(modules, key=lambda n: (-LAYERS[n], n)):
    print(f"   {name:<14} {modules[name]['doc'][:70]}")

# ---------------------------------------------------------------- 3. Check the layer rule
violations = [(name, dep) for name, info in modules.items() for dep in info["imports"]
              if LAYERS[dep] > LAYERS[name]]            # importing a HIGHER layer = wrong direction
print("3. imports that point UP (must be none):", violations or "none")

# ---------------------------------------------------------------- 4. Who uses third-party code?
for name in ("transform", "models"):
    source = (PACKAGE_DIR / f"{name}.py").read_text(encoding="utf-8")
    print(f"4. {name}.py imports requests? {'import requests' in source}  (pure logic must not)")
