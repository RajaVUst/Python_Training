"""
Day 5 - Example 02: __name__, "__main__" and how a module is started

WHAT THIS EXAMPLE TEACHES
  * Every module has a variable __name__:
      - "__main__"      when the file is the program you started
      - "shop.pricing"  when the file is imported
  * if __name__ == "__main__":  lets one file be both a reusable module AND a runnable
    script; the script part does not run on import.
  * Three ways to start code, and why relative imports need the package:
      python shop/pricing.py      -> runs as a plain script
      python -m shop.pricing      -> runs as part of the package (relative imports work)
      python shop/stock.py        -> FAILS: "attempted relative import with no known parent package"

  This example starts each of them with subprocess, so you see the real output side by side.

WHERE THE CAPSTONE USES THIS
  src/novaretail/cli.py       ends with  if __name__ == "__main__": sys.exit(main())
  src/novaretail/__main__.py  is what runs for  python -m novaretail

RUN (no API needed):
  python practice/day5/d5_02_name_main.py
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent          # practice/day5

print("1. In this file, __name__ =", repr(__name__))

import shop.pricing  # noqa: E402

print("   In the imported module, __name__ =", repr(shop.pricing.__name__))


def start(title: str, args: list[str]) -> None:
    """Start `python <args>` from practice/day5 and show what it prints (stdout and stderr)."""
    proc = subprocess.run([sys.executable, *args], cwd=HERE, capture_output=True, text=True)
    print(title)
    print("   $ python", " ".join(args))
    for line in (proc.stdout + proc.stderr).strip().splitlines():
        if line.startswith(("Traceback", "  File")):    # skip the traceback path lines; keep the error
            continue
        print("  ", line.strip())


start("2. Run the module file directly: the __main__ block runs", ["shop/pricing.py"])
start("3. Run it as part of the package with -m: same result, package context", ["-m", "shop.pricing"])
start("4. Run a module that uses a RELATIVE import directly: it fails", ["shop/stock.py"])
start("5. The same module with -m: works (it has no __main__ block, so it only loads)", ["-m", "shop.stock"])
