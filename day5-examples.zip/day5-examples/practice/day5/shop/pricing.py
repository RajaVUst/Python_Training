"""shop.pricing - price rules. A MODULE is one .py file; its name is the file name.

This module only DEFINES things (a constant and functions). It does no work when it is
imported, apart from the one print below, which is there only to show WHEN Python runs it.
"""
GST_RATE = 0.18                                 # a constant: UPPER_CASE by convention

print("   [shop/pricing.py ran: module 'shop.pricing' loaded]")


def price_with_tax(price: float, rate: float = GST_RATE) -> float:
    """Price including tax, rounded to 2 decimals.

    >>> price_with_tax(100.0)
    118.0
    """
    return round(price * (1 + rate), 2)


def _round_to_rupee(value: float) -> int:
    """Leading underscore = PRIVATE: used inside this module only, may change any time."""
    return int(round(value))


# This block runs ONLY when the file is run directly (python practice/day5/shop/pricing.py),
# never when it is imported. Handy for a quick self-check of the module.
if __name__ == "__main__":
    print("   self-check:", price_with_tax(799.0), _round_to_rupee(942.82))
