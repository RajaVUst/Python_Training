"""shop.stock - stock rules.

It imports from its sibling module with a RELATIVE import (the leading dot).
Relative imports only work when this file is loaded as part of the package.
"""
from .pricing import price_with_tax  # sibling module in the same package

print("   [shop/stock.py ran: module 'shop.stock' loaded]")


def is_low_stock(on_hand: int, reorder_level: int) -> bool:
    """True when stock is at or below the reorder level (the capstone's rule)."""
    return on_hand <= reorder_level


def stock_value_with_tax(price: float, on_hand: int) -> float:
    """Value of the stock at the tax-inclusive price."""
    return round(price_with_tax(price) * on_hand, 2)
