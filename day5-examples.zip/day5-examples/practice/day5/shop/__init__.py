"""shop - a tiny demo package for Day 5.

A PACKAGE is a folder that contains an __init__.py file. This file runs once, the first
time anything inside the package is imported. Keep it small: the package version, and
(optionally) re-exports of the names users should import. The capstone's
src/novaretail/__init__.py sets __version__ and re-exports Settings and NovaError.
"""
__version__ = "0.1.0"

print(f"   [shop/__init__.py ran: package 'shop' {__version__} loaded]")
