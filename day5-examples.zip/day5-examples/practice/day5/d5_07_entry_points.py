"""
Day 5 - Example 07: Where the `novaretail` command comes from

WHAT THIS EXAMPLE TEACHES
  * pyproject.toml is the package's ID card: name, version, dependencies, and
        [project.scripts]
        novaretail = "novaretail.cli:main"
    which tells pip: "create a command called novaretail that calls main() in novaretail.cli".
  * pip install -e . created that command inside the venv (novaretail.exe on Windows).
  * Three ways to run the same main():
        novaretail report          the installed command
        python -m novaretail report  runs src/novaretail/__main__.py
        python -c "from novaretail.cli import main; main(['report'])"   a plain function call
  * importlib.metadata reads what pip installed: version, dependencies, entry points.

WHERE THE CAPSTONE USES THIS
  pyproject.toml, src/novaretail/__main__.py, src/novaretail/cli.py

RUN (no API needed):
  python practice/day5/d5_07_entry_points.py
"""
import importlib.metadata as md  # noqa: I001  (tomllib is standard library from Python 3.11)
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

# ---------------------------------------------------------------- 1. What pyproject.toml says
project = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))["project"]
print("1. pyproject.toml")
print("   name        :", project["name"], project["version"])
print("   needs Python:", project["requires-python"])
print("   dependencies:", project["dependencies"], "| dev extras:", project["optional-dependencies"]["dev"])
print("   scripts     :", project["scripts"])

# ---------------------------------------------------------------- 2. What pip installed from it
dist = md.distribution("novaretail-toolkit")           # the installed package's metadata
print("2. installed")
print("   version     :", dist.version)
for ep in dist.entry_points:                           # entry points = the commands it created
    print(f"   command     : {ep.name} -> {ep.value}  (group {ep.group})")
exe = shutil.which("novaretail")                       # where the command file is on disk
print("   command file:", Path(exe).parent.name + "/" + Path(exe).name if exe else "NOT FOUND - is the venv active?")

# ---------------------------------------------------------------- 3. Three ways, one main()
print("3. the same main(), started three ways")
ways = [
    ("the installed command", ["novaretail", "--version"]),
    ("python -m novaretail", [sys.executable, "-m", "novaretail", "--version"]),
    ("a plain function call", [sys.executable, "-c", "from novaretail.cli import main; main(['--version'])"]),
]
for label, args in ways:
    out = subprocess.run(args, capture_output=True, text=True).stdout.strip()   # what it printed
    print(f"   {label:<22} -> {out}")

# ---------------------------------------------------------------- 4. What __main__.py contains
print("4. src/novaretail/__main__.py:")
import novaretail  # noqa: E402

for line in (Path(novaretail.__file__).parent / "__main__.py").read_text(encoding="utf-8").splitlines():
    print("   |", line)
