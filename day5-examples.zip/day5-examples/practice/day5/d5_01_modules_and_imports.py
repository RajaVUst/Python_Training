"""
Day 5 - Example 01: Modules, packages and the ways to import

WHAT THIS EXAMPLE TEACHES
  * module  = one .py file           (shop/pricing.py  ->  shop.pricing)
  * package = a folder with __init__.py that groups modules (shop/)
  * The four import forms, and when to use each.
  * A module's top-level code runs ONCE, on the first import. Python then keeps it in
    sys.modules, and later imports reuse it. That is why module top level must only
    define things, never do work like calling an API.
  * Where Python looks for modules: sys.path.

THE DEMO PACKAGE (in practice/day5/shop/)
  shop/__init__.py   marks the folder as a package, sets __version__
  shop/pricing.py    price_with_tax(), GST_RATE
  shop/stock.py      is_low_stock(), imports pricing with a relative import
  Each file prints one line when Python runs it, so you can SEE when imports happen.

WHERE THE CAPSTONE USES THIS
  src/novaretail/ is a package; every file in it is a module: novaretail.transform, ...

RUN (no API needed):
  python practice/day5/d5_01_modules_and_imports.py
"""
import sys

# ---------------------------------------------------------------- 1. Where Python looks
# sys.path[0] is the folder of the script being run (practice/day5), which is why
# "import shop" finds practice/day5/shop/. The installed packages (like novaretail) are
# found through the venv's site-packages folder, further down the list.
print("1. first place Python looks:", sys.path[0].replace("\\", "/").split("/")[-2:])

# ---------------------------------------------------------------- 2. The first import runs the code
print("2. import shop.pricing  (watch which files run)")
import shop.pricing  # noqa: E402  (imports are placed inside the story on purpose)

# Form 1: import the module, use the full name.  Clear where each name comes from.
print("   shop.pricing.price_with_tax(799) ->", shop.pricing.price_with_tax(799))

# ---------------------------------------------------------------- 3. The second import is free
print("3. import shop.pricing again        (nothing runs: it is cached)")
import shop.pricing  # noqa: E402,F811

print("   cached in sys.modules?", "shop.pricing" in sys.modules)

# ---------------------------------------------------------------- 4. The other import forms
print("4. other import forms")
from shop.stock import is_low_stock  # noqa: E402   Form 2: one name from a module (the most common)

print("   from shop.stock import is_low_stock  ->", is_low_stock(1, 20))

import shop.stock as st  # noqa: E402               Form 3: a short alias for a long module name

print("   import shop.stock as st              ->", st.stock_value_with_tax(799, 40))

from novaretail import Settings  # noqa: E402       Form 4: a name the package re-exports in __init__.py

print("   from novaretail import Settings       ->", Settings.__module__, "(defined in config.py)")

# ---------------------------------------------------------------- 5. What is in a module?
# A module is an object too. Its attributes are everything defined at its top level.
public = [name for name in dir(shop.pricing) if not name.startswith("_")]
print("5. public names in shop.pricing:", public)
print("   shop.__version__ =", shop.__version__)

# ---------------------------------------------------------------- 6. The same for the capstone
import novaretail  # noqa: E402
import novaretail.transform  # noqa: E402

print("6. novaretail version:", novaretail.__version__)
print("   novaretail.transform lives in:", novaretail.transform.__file__.replace("\\", "/").split("src/")[-1])
