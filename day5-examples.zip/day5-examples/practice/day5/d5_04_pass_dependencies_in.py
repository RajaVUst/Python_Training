"""
Day 5 - Example 04: Pass dependencies in - reuse the workflow with a fake API

WHAT THIS EXAMPLE TEACHES
  * A function that creates everything it needs inside itself (reads os.environ, opens
    its own HTTP session, prints) can only be used ONE way.
  * A function that RECEIVES what it needs (settings, a client) can be reused: by the CLI,
    by a scheduler, by a test, by another script.
  * The capstone's run_report(settings, client=None) does this: no client given -> it
    creates the real NovaApiClient; a client given -> it uses that one.
  * Here we pass a FAKE client that returns fixed data. The whole capstone report runs
    with no API at all - this is exactly how Day 6 tests the workflow.

WHERE THE CAPSTONE USES THIS
  src/novaretail/workflow.py -> run_report(settings, client=None, allow_cache=True)
  src/novaretail/config.py   -> Settings, built here directly instead of from .env

RUN (no API needed - that is the point):
  python practice/day5/d5_04_pass_dependencies_in.py
"""
import logging
import sys
from pathlib import Path

from novaretail.config import Settings
from novaretail.exceptions import ApiUnavailableError
from novaretail.models import Product, StockLevel
from novaretail.workflow import run_report

# Show the workflow's own WARNING lines, in order with our prints.
logging.basicConfig(level=logging.WARNING, format="   %(levelname)s | %(name)s | %(message)s", stream=sys.stdout)


# ---------------------------------------------------------------- 1. The hard-to-reuse version
def report_hard_wired() -> None:
    """Reads .env itself, calls the real API itself, prints itself. One job? No: four.
    You cannot run it without a server, test it with odd data, or reuse the numbers."""
    ...                                                   # (shown only to compare; not called)


# ---------------------------------------------------------------- 2. A fake client
class FakeClient:
    """Has the same methods as NovaApiClient, but returns data we choose."""

    def __init__(self, down: bool = False):
        self.down = down                                  # True = pretend the API is unreachable

    def get_products(self) -> list[Product]:
        if self.down:
            raise ApiUnavailableError("fake: API down")
        return [Product(1, "NR-1001", "Wireless Mouse", "Electronics", 799.0),
                Product(2, "NR-1002", "USB-C Charger 65W", "Electronics", 1899.0),
                Product(7, "NR-1007", "Basmati Rice 5kg", "Grocery", 699.0)]

    def get_inventory(self) -> list[StockLevel]:
        return [StockLevel("NR-1001", 40, 10), StockLevel("NR-1002", 1, 20)]   # NR-1007 has no stock record

    def close(self) -> None:                              # run_report only closes clients it created itself
        pass


# ---------------------------------------------------------------- 3. Settings built in code
# No .env and no environment variables needed: the values are passed in directly.
# The output goes to a practice folder so the real output/ stays clean.
settings = Settings(api_base_url="http://unused", api_key="not-needed",
                    output_dir=Path("work") / "day5" / "output", log_dir=Path("work") / "day5" / "logs")

# ---------------------------------------------------------------- 4. Reuse the real workflow
result = run_report(settings, client=FakeClient())        # the capstone's own function, fake data
print("1. report with the fake client")
print("   source       :", result.source)
print("   products     :", result.products, "| low stock:", result.low_stock, "| value:", result.total_value)
print("   missing stock:", result.missing_skus)
print("   csv written  :", result.csv_path.name.startswith("inventory_report_"))

# ---------------------------------------------------------------- 5. Same workflow, API down
# The fake client now raises ApiUnavailableError. run_report falls back to the snapshot
# saved by the run above - the Day 4 alternate flow, tested without breaking any server.
result = run_report(settings, client=FakeClient(down=True))
print("2. same workflow, fake API down")
print("   source       :", result.source, "| products:", result.products)
