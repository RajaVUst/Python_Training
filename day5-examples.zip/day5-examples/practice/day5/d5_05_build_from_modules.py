"""
Day 5 - Example 05: A new feature in 25 lines, built only from package modules

WHAT THIS EXAMPLE TEACHES
  The business asks for a new file: a CATEGORY report (one row per category with products,
  units, stock value and low-stock count). On Day 3 this would have been 100 lines of
  session, pagination, CSV and JSON code. With the package, every piece already exists:

      Settings.from_env()        config.py       settings, validated, key hidden
      NovaApiClient              api_client.py   session, timeouts, retries, pagination
      join_inventory()           transform.py    products + stock -> rows
      summarize_by_category()    transform.py    rows -> per-category totals
      write_csv(), timestamped_path()  file_ops.py   atomic, timestamped CSV
      setup_logging()            logging_setup.py  one log format, key redacted

  Reuse means: import the piece, call it, trust it - it is already tested.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

WHERE THE CAPSTONE USES THIS
  workflow.run_report() is built the same way, from the same pieces.

RUN:
  python practice/day5/d5_05_build_from_modules.py
"""
import logging
from pathlib import Path

from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.file_ops import timestamped_path, write_csv
from novaretail.logging_setup import setup_logging
from novaretail.transform import join_inventory, summarize_by_category

OUT = Path("work") / "day5"

settings = Settings.from_env()                                    # 1. settings
setup_logging("INFO", log_dir=None, secrets=[settings.api_key])   # 2. logging (console only)
log = logging.getLogger("day5.category_report")

with NovaApiClient(settings) as client:                           # 3. data from the API
    rows, missing = join_inventory(client.get_products(), client.get_inventory())

summary = summarize_by_category(rows)                             # 4. business rule
table = [{"category": cat, **values} for cat, values in summary.items()]   # dict -> rows for the CSV

path = write_csv(table, timestamped_path(OUT, "category_report", ".csv"))  # 5. atomic CSV
log.info("Category report: %d categories -> %s", len(table), path.as_posix())

print(f"{'category':<12} {'products':>8} {'units':>6} {'stock value':>13} {'low':>4}")
for row in table:
    print(f"{row['category']:<12} {row['products']:>8} {row['units']:>6} {row['stock_value']:>13,.2f} {row['low_stock']:>4}")
