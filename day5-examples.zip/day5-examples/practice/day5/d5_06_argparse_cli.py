"""
Day 5 - Example 06: A command-line interface with argparse

WHAT THIS EXAMPLE TEACHES
  * argparse turns the words typed after a command into Python values:
        novaretail restock --execute --cover 3   ->   command="restock", execute=True, cover=3
  * Sub-commands (health / report / restock) with their own options.
  * Options: flags (store_true), typed values (type=int), defaults, required options.
  * --help is generated for free from the help= texts.
  * main(argv) returns an exit code instead of calling exit() everywhere, so it can be
    called from a test with a list of words.

  The example builds a tiny CLI called "stock" first, then shows the capstone's real parser.

WHERE THE CAPSTONE USES THIS
  src/novaretail/cli.py -> build_parser(), main(argv)

RUN (no API needed):
  python practice/day5/d5_06_argparse_cli.py
"""
import argparse

from novaretail.cli import build_parser


# ---------------------------------------------------------------- 1. A tiny CLI of our own
def build_stock_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="stock", description="Tiny demo CLI")
    parser.add_argument("-v", "--verbose", action="store_true", help="say more")     # a flag: True if present
    sub = parser.add_subparsers(dest="command", required=True)                        # one of the commands below

    check = sub.add_parser("check", help="check one SKU")
    check.add_argument("sku", help="the SKU, e.g. NR-1001")                           # positional: required, no dashes

    order = sub.add_parser("order", help="plan an order")
    order.add_argument("sku")
    order.add_argument("--qty", type=int, default=10, help="units (default 10)")      # converted to int for us
    order.add_argument("--execute", action="store_true", help="really place it")
    return parser


def main(argv: list[str] | None = None) -> int:
    """argv=None means 'use the real command line'; a list is handy for tests and demos."""
    args = build_stock_parser().parse_args(argv)
    if args.command == "check":
        print(f"   checking {args.sku} (verbose={args.verbose})")
    elif args.command == "order":
        mode = "PLACED" if args.execute else "planned (dry-run)"
        print(f"   order {args.qty} x {args.sku}: {mode}")
    return 0                                                                           # exit code


print("1. parse some command lines")
for words in (["check", "NR-1001"], ["-v", "check", "NR-1002"], ["order", "NR-1009", "--qty", "25"],
              ["order", "NR-1009", "--execute"]):
    print("   $ stock", " ".join(words))
    main(words)

# ---------------------------------------------------------------- 2. Bad input: argparse explains and exits with code 2
print("2. a wrong value")
try:
    main(["order", "NR-1009", "--qty", "many"])
except SystemExit as exc:                     # argparse calls sys.exit(2) after printing the error to stderr
    print("   argparse stopped with exit code", exc.code)

# ---------------------------------------------------------------- 3. The generated help
print("3. $ stock order --help")
try:
    main(["order", "--help"])                 # argparse prints the help, then exits with code 0
except SystemExit as exc:
    print("   (help printed, exit code", exc.code, ")")

# ---------------------------------------------------------------- 4. The capstone's real parser
print("4. the capstone's parser understands:")
parser = build_parser()
for words in (["report"], ["report", "--no-cache"], ["-v", "restock", "--execute", "--cover", "3"]):
    args = parser.parse_args(words)
    print(f"   novaretail {' '.join(words):<32} -> {vars(args)}")
