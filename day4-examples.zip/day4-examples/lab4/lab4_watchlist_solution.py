"""
Lab 4 - Hardened stock watchlist (TRAINER SOLUTION)

WHAT CHANGED SINCE LAB 3
  1. print() replaced by logging: console at INFO, logs/lab4.log at DEBUG.
  2. The API key is redacted from every log line (RedactFilter).
  3. GET /inventory is retried with exponential backoff - but ONLY for temporary
     failures: connection errors, timeouts, 429 and 5xx. Never for 401 or 400.
  4. Every unknown SKU gets its own WARNING line; the run continues.
  5. Exit codes a scheduler can read:
        0 = success   1 = run failed (API down)   2 = configuration / input error   3 = wrong API key

INPUT    data/input/watchlist.csv                    columns: sku,min_stock
OUTPUT   output/watchlist_<timestamp>.csv and .json
LOG      logs/lab4.log

RUN (project root, venv active, mock API running in terminal 2):
  python examples/lab4_watchlist.py

EXPECTED with the sample watchlist: 3 alerts, 1 unknown SKU (NR-9999), exit code 0
"""
import csv
import functools
import json
import logging
import logging.handlers
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

from novaretail.config import load_dotenv

INPUT = Path("data") / "input" / "watchlist.csv"
OUT_DIR = Path("output")
LOG_FILE = Path("logs") / "lab4.log"
CSV_FIELDS = ["sku", "on_hand", "min_stock", "short_by"]
RETRYABLE_STATUS = {429, 500, 502, 503, 504}

EXIT_OK, EXIT_FAILED, EXIT_CONFIG, EXIT_AUTH = 0, 1, 2, 3

log = logging.getLogger("lab4")


# ================================================================ errors of our own
class ConfigError(Exception):
    """Settings or input file are wrong: fix them, do not retry. Exit code 2."""


class TransientApiError(Exception):
    """The API answered 429 or 5xx: worth retrying."""


# ================================================================ logging
class RedactFilter(logging.Filter):
    """Replace the secret with **** in every log line, on screen and in the file."""

    def __init__(self, secret: str):
        super().__init__()
        self.secret = secret

    def filter(self, record: logging.LogRecord) -> bool:
        if self.secret:
            msg = record.getMessage()
            if self.secret in msg:
                record.msg, record.args = msg.replace(self.secret, "****"), ()
        return True


def setup_logging(secret: str) -> None:
    """Configure logging ONCE: console at INFO, rotating file at DEBUG."""
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    for h in list(root.handlers):                 # safe to call twice
        root.removeHandler(h)
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    redact = RedactFilter(secret)

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(formatter)
    console.addFilter(redact)

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    logfile = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    logfile.setLevel(logging.DEBUG)
    logfile.setFormatter(formatter)
    logfile.addFilter(redact)

    root.addHandler(console)
    root.addHandler(logfile)
    logging.getLogger("urllib3").setLevel(logging.WARNING)   # hide the library's own chatter


# ================================================================ retry decorator
def retry(times: int, delay: float, exceptions: tuple):
    """Retry the listed exceptions with exponential backoff and a little jitter."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(1, times + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    # requests errors have very long messages; the class name is enough on one line
                    reason = str(exc) if isinstance(exc, TransientApiError) else type(exc).__name__
                    if attempt == times:
                        log.error("%s gave up after %d attempts: %s", func.__name__, times, reason)
                        raise
                    wait = delay * 2 ** (attempt - 1) + random.uniform(0, 0.1)
                    log.warning("%s failed (%s), retry %d/%d in %.1f s",
                                func.__name__, reason, attempt, times - 1, wait)
                    time.sleep(wait)
        return wrapper
    return decorator


# ================================================================ settings and input
def load_settings() -> dict:
    load_dotenv()
    key = os.getenv("NOVA_API_KEY", "").strip()
    if not key:
        raise ConfigError("NOVA_API_KEY is not set. Copy .env.example to .env.")
    try:
        timeout = float(os.getenv("NOVA_TIMEOUT", "5"))
        backoff = float(os.getenv("NOVA_BACKOFF", "0.5"))
    except ValueError as exc:
        raise ConfigError(f"NOVA_TIMEOUT / NOVA_BACKOFF must be numbers: {exc}") from exc
    return {"base_url": os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/"),
            "api_key": key, "timeout": timeout, "backoff": backoff}


def read_watchlist(path: Path) -> dict[str, int]:
    if not path.is_file():
        raise ConfigError(f"Watchlist not found: {path}")
    with path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = {"sku", "min_stock"} - set(reader.fieldnames or [])
        if missing:
            raise ConfigError(f"{path}: missing columns {sorted(missing)}")
        watch = {}
        for line_no, row in enumerate(reader, start=2):
            try:
                watch[row["sku"].strip()] = int(row["min_stock"])
            except ValueError as exc:
                raise ConfigError(f"{path} line {line_no}: min_stock {row['min_stock']!r} is not a whole number") from exc
    log.debug("Watchlist: %s", watch)
    return watch


# ================================================================ API call with retries
def fetch_stock(settings: dict) -> dict[str, int]:
    """GET /inventory once (plus retries) and return {sku: on_hand}."""

    @retry(times=4, delay=settings["backoff"],
           exceptions=(requests.ConnectionError, requests.Timeout, TransientApiError))
    def get_inventory(session: requests.Session) -> dict:
        resp = session.get(f"{settings['base_url']}/inventory", timeout=settings["timeout"])
        log.debug("GET /inventory -> %d in %.0f ms", resp.status_code, resp.elapsed.total_seconds() * 1000)
        if resp.status_code in RETRYABLE_STATUS:
            raise TransientApiError(f"HTTP {resp.status_code}")   # retried by the decorator
        resp.raise_for_status()                                    # 401, 400 ... -> HTTPError, NOT retried
        return resp.json()

    with requests.Session() as session:
        session.headers.update({"X-API-Key": settings["api_key"], "Accept": "application/json"})
        data = get_inventory(session)
    return {item["sku"]: item["on_hand"] for item in data["items"]}


# ================================================================ business rule and outputs
def check(watch: dict[str, int], stock: dict[str, int]) -> tuple[list[dict], list[str]]:
    alerts, unknown = [], []
    for sku, min_stock in watch.items():
        if sku not in stock:
            log.warning("Unknown SKU %s: not in the API inventory, skipped", sku)   # one line per SKU
            unknown.append(sku)
        elif stock[sku] < min_stock:
            alerts.append({"sku": sku, "on_hand": stock[sku], "min_stock": min_stock,
                           "short_by": min_stock - stock[sku]})
    alerts.sort(key=lambda a: a["short_by"], reverse=True)
    return alerts, sorted(unknown)


def write_outputs(alerts: list[dict], summary: dict, stamp: str) -> tuple[Path, Path]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUT_DIR / f"watchlist_{stamp}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(alerts)
    json_path = OUT_DIR / f"watchlist_{stamp}.json"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return csv_path, json_path


# ================================================================ main: every failure becomes an exit code
def main() -> int:
    started = time.perf_counter()
    load_dotenv()
    setup_logging(os.getenv("NOVA_API_KEY", ""))
    log.info("Lab 4 watchlist run started")
    try:
        settings = load_settings()
        watch = read_watchlist(INPUT)
        stock = fetch_stock(settings)
    except ConfigError as exc:
        log.error("Configuration problem: %s", exc)
        return EXIT_CONFIG
    except requests.HTTPError as exc:
        status = exc.response.status_code
        if status in (401, 403):
            log.error("The API rejected the key (%d). Check NOVA_API_KEY in .env.", status)
            return EXIT_AUTH
        log.error("The API answered %d: %s", status, exc.response.text[:200])
        return EXIT_FAILED
    except (requests.ConnectionError, requests.Timeout, TransientApiError) as exc:
        log.error("API unavailable after retries (%s). Is the mock server running?", type(exc).__name__)
        return EXIT_FAILED
    except Exception:                                  # a bug: keep the traceback in the log
        log.exception("Unexpected error")
        return EXIT_FAILED

    alerts, unknown = check(watch, stock)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary = {"run_at": stamp, "watched": len(watch), "alerts": len(alerts),
               "unknown_skus": unknown, "seconds": round(time.perf_counter() - started, 3)}
    csv_path, json_path = write_outputs(alerts, summary, stamp)
    for a in alerts:
        log.info("ALERT %s: on hand %d, minimum %d, short by %d", a["sku"], a["on_hand"], a["min_stock"], a["short_by"])
    log.info("Done: watched %d, alerts %d, unknown %d -> %s", len(watch), len(alerts), len(unknown), csv_path.as_posix())
    log.debug("Summary written to %s", json_path.as_posix())
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
