"""
Lab 4 - Hardened stock watchlist (STARTER FILE: complete every TODO)

Lab 3 already works when everything is fine. Lab 4 makes it survive - and explain - failures.
The parts from Lab 3 are filled in; the new parts are TODOs.

GOALS
  1. Replace print() with logging: console at INFO, logs/lab4.log at DEBUG.
  2. Hide the API key in every log line (RedactFilter).
  3. Retry GET /inventory with exponential backoff, but ONLY for temporary failures:
     connection errors, timeouts, 429 and 5xx. Never retry 401 or 400.
  4. Log one WARNING per unknown SKU, and continue.
  5. Exit codes: 0 success, 1 run failed (API down), 2 configuration/input error, 3 wrong key.

RUN (project root, venv active, mock API running in terminal 2):
  python examples/lab4_watchlist.py

EXPECTED with the sample watchlist: 3 alerts, 1 unknown SKU (NR-9999), exit code 0
"""
import csv
import functools  # noqa: F401  (needed for TODO 4)
import json
import logging
import logging.handlers  # noqa: F401  (needed for TODO 3)
import os
import random  # noqa: F401  (needed for TODO 4)
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

from novaretail.config import load_dotenv

INPUT = Path("data") / "input" / "watchlist.csv"
OUT_DIR = Path("output")
LOG_FILE = Path("logs") / "lab4.log"
CSV_FIELDS = ["sku", "on_hand", "min_stock", "short_by"]
RETRYABLE_STATUS = {429, 500, 502, 503, 504}

EXIT_OK, EXIT_FAILED, EXIT_CONFIG, EXIT_AUTH = 0, 1, 2, 3

log = logging.getLogger("lab4")


# ================================================================ errors of our own
class ConfigError(Exception):
    """Settings or input file are wrong: fix them, do not retry. Exit code 2."""


class TransientApiError(Exception):
    """The API answered 429 or 5xx: worth retrying."""


# ================================================================ logging
class RedactFilter(logging.Filter):
    def __init__(self, secret: str):
        super().__init__()
        self.secret = secret

    def filter(self, record: logging.LogRecord) -> bool:
        # TODO 1: if self.secret appears in record.getMessage(), replace it with "****"
        #         (set record.msg to the new text and record.args to ()).   See Example 04.
        return True


def setup_logging(secret: str) -> None:
    # TODO 2: get the root logger, set its level to DEBUG, remove any old handlers.
    # TODO 3: add a StreamHandler at INFO and a RotatingFileHandler(LOG_FILE, maxBytes=1_000_000,
    #         backupCount=3, encoding="utf-8") at DEBUG. Both get the same Formatter
    #         "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s" and RedactFilter(secret).
    #         Create LOG_FILE.parent first.                                      See Example 04.
    ...


# ================================================================ retry decorator
def retry(times: int, delay: float, exceptions: tuple):
    # TODO 4: return a decorator that calls the function up to `times` times.
    #         On one of `exceptions`: if it was the last attempt, log.error(...) and raise;
    #         otherwise log.warning(...) and sleep  delay * 2 ** (attempt - 1) + random.uniform(0, 0.1).
    #         Use @functools.wraps(func).                                        See Example 05.
    ...


# ================================================================ settings and input (from Lab 3)
def load_settings() -> dict:
    load_dotenv()
    key = os.getenv("NOVA_API_KEY", "").strip()
    if not key:
        raise ConfigError("NOVA_API_KEY is not set. Copy .env.example to .env.")
    # TODO 5: read NOVA_TIMEOUT (default "5") and NOVA_BACKOFF (default "0.5") with float().
    #         If float() raises ValueError, raise ConfigError(...) from the ValueError.
    timeout, backoff = 5.0, 0.5
    return {"base_url": os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/"),
            "api_key": key, "timeout": timeout, "backoff": backoff}


def read_watchlist(path: Path) -> dict[str, int]:
    if not path.is_file():
        raise ConfigError(f"Watchlist not found: {path}")
    with path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = {"sku", "min_stock"} - set(reader.fieldnames or [])
        if missing:
            raise ConfigError(f"{path}: missing columns {sorted(missing)}")
        return {row["sku"].strip(): int(row["min_stock"]) for row in reader}


# ================================================================ API call
def fetch_stock(settings: dict) -> dict[str, int]:
    # TODO 6: decorate this inner function with
    #         @retry(times=4, delay=settings["backoff"],
    #                exceptions=(requests.ConnectionError, requests.Timeout, TransientApiError))
    def get_inventory(session: requests.Session) -> dict:
        resp = session.get(f"{settings['base_url']}/inventory", timeout=settings["timeout"])
        # TODO 7: if resp.status_code is in RETRYABLE_STATUS, raise TransientApiError(f"HTTP {resp.status_code}")
        resp.raise_for_status()
        return resp.json()

    with requests.Session() as session:
        session.headers.update({"X-API-Key": settings["api_key"], "Accept": "application/json"})
        data = get_inventory(session)
    return {item["sku"]: item["on_hand"] for item in data["items"]}


# ================================================================ business rule and outputs (from Lab 3)
def check(watch: dict[str, int], stock: dict[str, int]) -> tuple[list[dict], list[str]]:
    alerts = [{"sku": sku, "on_hand": stock[sku], "min_stock": m, "short_by": m - stock[sku]}
              for sku, m in watch.items() if sku in stock and stock[sku] < m]
    alerts.sort(key=lambda a: a["short_by"], reverse=True)
    unknown = sorted(sku for sku in watch if sku not in stock)
    # TODO 8: log.warning one line per unknown SKU, e.g. "Unknown SKU NR-9999: not in the API inventory, skipped"
    return alerts, unknown


def write_outputs(alerts: list[dict], summary: dict, stamp: str) -> tuple[Path, Path]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUT_DIR / f"watchlist_{stamp}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(alerts)
    json_path = OUT_DIR / f"watchlist_{stamp}.json"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return csv_path, json_path


# ================================================================ main
def main() -> int:
    started = time.perf_counter()
    load_dotenv()
    setup_logging(os.getenv("NOVA_API_KEY", ""))
    log.info("Lab 4 watchlist run started")

    # TODO 9: wrap the next three lines in try/except and RETURN an exit code:
    #   ConfigError                                         -> log.error(...), return EXIT_CONFIG
    #   requests.HTTPError with status 401/403              -> log.error(...), return EXIT_AUTH
    #   requests.HTTPError with another status              -> log.error(...), return EXIT_FAILED
    #   ConnectionError / Timeout / TransientApiError       -> log.error(...), return EXIT_FAILED
    #   any other Exception (a bug)                         -> log.exception(...), return EXIT_FAILED
    settings = load_settings()
    watch = read_watchlist(INPUT)
    stock = fetch_stock(settings)

    alerts, unknown = check(watch, stock)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary = {"run_at": stamp, "watched": len(watch), "alerts": len(alerts),
               "unknown_skus": unknown, "seconds": round(time.perf_counter() - started, 3)}
    csv_path, json_path = write_outputs(alerts, summary, stamp)
    # TODO 10: replace these print() calls with log.info(...)
    for a in alerts:
        print(f"ALERT {a['sku']}: on hand {a['on_hand']}, minimum {a['min_stock']}, short by {a['short_by']}")
    print(f"Done: watched {len(watch)}, alerts {len(alerts)}, unknown {len(unknown)} -> {csv_path.as_posix()}")
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())     # the return value becomes the exit code: 0 = success
