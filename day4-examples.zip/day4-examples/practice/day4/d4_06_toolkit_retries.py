"""
Day 4 - Example 06: The capstone client against a failing API

WHAT THIS EXAMPLE TEACHES
  Watch NovaApiClient (src/novaretail/api_client.py) react to real failures from the
  mock API. The script switches the server into "chaos" mode for each scenario:

    A. 503 for about 1 second, then healthy  -> retries, then success
    B. 503 all the time                      -> gives up: ApiUnavailableError
    C. wrong API key                         -> ApiAuthError at once, NO retries
    D. bad order (quantity 600)              -> ApiError 400, NO retries
    E. server slower than the timeout        -> Timeout, retried, then ApiUnavailableError

  Read the WARNING lines: each one is a retry the client made by itself.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py
  The script always resets the server at the end (try/finally).

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> NovaApiClient._request(): retries, backoff, error types
  src/novaretail/exceptions.py -> ApiAuthError, ApiUnavailableError, ApiError

RUN:
  python practice/day4/d4_06_toolkit_retries.py
"""
import logging
import sys
import threading
import time
from dataclasses import replace

import requests

from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.exceptions import ApiAuthError, ApiError, ApiUnavailableError

# Show the client's own log lines (it logs under the name "novaretail.api_client").
logging.basicConfig(level=logging.INFO, format="   %(levelname)-8s | %(name)s | %(message)s", stream=sys.stdout)

settings = Settings.from_env()                 # reads .env: max_retries=3, backoff=0.5, timeout=5
ADMIN = settings.api_base_url + "/admin"


def chaos(fail_rate: float = 0.0, latency: float = 0.0) -> None:
    """Training helper: make the mock API fail (fail_rate 1.0 = every call) or slow down."""
    requests.post(f"{ADMIN}/chaos", json={"fail_rate": fail_rate, "latency": latency}, timeout=5)


def reset() -> None:
    requests.post(f"{ADMIN}/reset", timeout=5)


try:
    # ------------------------------------------------------------ A. temporary outage
    print("A. API returns 503 for about 1 second, then recovers")
    chaos(fail_rate=1.0)
    threading.Timer(1.0, reset).start()        # heal the server 1 second from now, in the background
    start = time.perf_counter()
    with NovaApiClient(settings) as client:    # `with` closes the HTTP session afterwards
        stock = client.get_inventory()
    print(f"   -> success: {len(stock)} stock records after {time.perf_counter() - start:.1f} s")

    # ------------------------------------------------------------ B. outage that does not end
    print("B. API returns 503 all the time (backoff shortened to 0.2 s for the demo)")
    chaos(fail_rate=1.0)
    fast = replace(settings, backoff=0.2)      # a copy of the settings with one value changed
    try:
        with NovaApiClient(fast) as client:
            client.get_inventory()
    except ApiUnavailableError as exc:
        print(f"   -> {type(exc).__name__}: {exc}")
    reset()

    # ------------------------------------------------------------ C. wrong key
    print("C. wrong API key")
    bad_key = replace(settings, api_key="wrong-key")
    try:
        with NovaApiClient(bad_key) as client:
            client.get_inventory()
    except ApiAuthError as exc:                # no WARNING lines above: 401 is never retried
        print(f"   -> {type(exc).__name__} (status {exc.status}): {exc}")

    # ------------------------------------------------------------ D. bad data in our request
    print("D. order with quantity 600 (the API allows 1..500)")
    try:
        with NovaApiClient(settings) as client:
            client.create_order("NR-1009", 600)
    except ApiError as exc:                    # 400 is never retried either
        print(f"   -> {type(exc).__name__} (status {exc.status})")

    # ------------------------------------------------------------ E. slow server
    print("E. server takes 2 s, client timeout is 1 s, 1 retry")
    chaos(latency=2)
    slow = replace(settings, timeout=1.0, max_retries=1, backoff=0.2)
    try:
        with NovaApiClient(slow) as client:
            client.get_inventory()
    except ApiUnavailableError as exc:
        print(f"   -> {type(exc).__name__}: failed after 2 attempts (ReadTimeout)")
finally:
    reset()                                    # always leave the server healthy
    print("Server reset to normal.")
