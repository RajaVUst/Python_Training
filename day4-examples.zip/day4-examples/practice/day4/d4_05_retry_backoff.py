"""
Day 4 - Example 05: Retries with exponential backoff (no API needed)

WHAT THIS EXAMPLE TEACHES
  * Retry only TEMPORARY failures: connection errors, timeouts, 429 and 5xx.
    Never retry 400/401/404: the same request fails the same way again.
  * Exponential backoff: wait 0.5 s, 1 s, 2 s ... so a struggling server can recover.
  * Jitter: a small random extra wait, so 100 clients do not all retry at the same instant.
  * The same logic packaged as a reusable @retry decorator.

  A fake "API" that fails a set number of times is used, so the output is the same every run.

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> RETRYABLE_STATUS, the loop in NovaApiClient._request()

RUN:
  python practice/day4/d4_05_retry_backoff.py
"""
import functools
import logging
import random
import sys
import time

logging.basicConfig(level=logging.INFO, format="%(levelname)-8s | %(message)s", stream=sys.stdout)
log = logging.getLogger("day4.retry")

RETRYABLE_STATUS = {429, 500, 502, 503, 504}     # same set as the capstone


# ---------------------------------------------------------------- 1. Which failures to retry?
def should_retry(status: int) -> bool:
    return status in RETRYABLE_STATUS


print("1. retry or not?")
for status in (200, 400, 401, 404, 429, 500, 503):
    if status < 400:
        verdict = "success, nothing to retry"
    elif should_retry(status):
        verdict = "temporary -> retry"
    else:
        verdict = "our request is wrong -> do not retry"
    print(f"   {status}: {verdict}")


# ---------------------------------------------------------------- 2. The backoff schedule
# delay = backoff * 2 ** (attempt - 1)  ->  0.5, 1, 2, 4 ...   plus up to 0.1 s of jitter.
def backoff_delay(attempt: int, backoff: float = 0.5, jitter: float = 0.1) -> float:
    return backoff * 2 ** (attempt - 1) + random.uniform(0, jitter)


random.seed(1)                                    # fixed seed so the printed jitter is the same every run
print("2. backoff schedule (backoff=0.5):")
for attempt in (1, 2, 3, 4):
    print(f"   after attempt {attempt}: wait {backoff_delay(attempt):.2f} s")


# ---------------------------------------------------------------- 3. A fake API that fails N times
class FakeApi:
    """Answers with the status codes in `script`, one per call, then 200."""

    def __init__(self, script: list[int]):
        self.script = list(script)
        self.calls = 0

    def get(self) -> int:
        self.calls += 1
        return self.script.pop(0) if self.script else 200


# ---------------------------------------------------------------- 4. The retry loop, written out
def fetch_with_retry(api: FakeApi, max_retries: int = 3, backoff: float = 0.05) -> int:
    attempts = max_retries + 1                    # 3 retries = 4 attempts in total
    for attempt in range(1, attempts + 1):
        status = api.get()
        if status < 400:
            log.info("success on attempt %d/%d", attempt, attempts)
            return status
        if not should_retry(status):              # 4xx: stop immediately
            log.error("got %d: not retryable, giving up", status)
            raise RuntimeError(f"HTTP {status}")
        log.warning("got %d (attempt %d/%d)", status, attempt, attempts)
        if attempt < attempts:
            time.sleep(backoff_delay(attempt, backoff, jitter=0))   # short waits for the demo
    raise RuntimeError(f"failed after {attempts} attempts")


print("3. two 503s, then OK:")
api = FakeApi([503, 503])
fetch_with_retry(api)
print("   calls made:", api.calls)

print("4. a 401 is not retried:")
api = FakeApi([401])
try:
    fetch_with_retry(api)
except RuntimeError as exc:
    print("   error:", exc, "| calls made:", api.calls)

print("5. always 503: give up after 4 attempts:")
api = FakeApi([503] * 10)
try:
    fetch_with_retry(api)
except RuntimeError as exc:
    print("   error:", exc, "| calls made:", api.calls)


# ---------------------------------------------------------------- 6. The same idea as a decorator
# A decorator wraps any function with the retry loop. You choose which exceptions to retry.
def retry(times: int = 3, delay: float = 0.05, exceptions: tuple = (ConnectionError, TimeoutError)):
    def decorator(func):
        @functools.wraps(func)                    # keeps the original function's name for the logs
        def wrapper(*args, **kwargs):
            for attempt in range(1, times + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:         # only the listed exceptions are retried
                    if attempt == times:
                        log.error("%s gave up after %d attempts", func.__name__, times)
                        raise
                    wait = delay * 2 ** (attempt - 1)
                    log.warning("%s failed (%s), retry %d/%d in %.2fs", func.__name__, exc, attempt, times, wait)
                    time.sleep(wait)
        return wrapper
    return decorator


failures_left = 2


@retry(times=4)
def get_inventory() -> str:
    global failures_left
    if failures_left:
        failures_left -= 1
        raise ConnectionError("network blip")
    return "24 stock records"


print("6. @retry decorator:")
print("   result:", get_inventory())
