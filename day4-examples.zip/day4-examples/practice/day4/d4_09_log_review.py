"""
Day 4 - Example 09: Review the logs and produce evidence

WHAT THIS EXAMPLE TEACHES
  Logs are evidence. After a run (or a night of scheduled runs) someone must answer:
    * How many warnings and errors were there, and what were they?
    * Did any run fall back to the cache?
    * Did the API key leak into a log file?   (a security check)
  This script reads the log files, answers those questions, and saves the answer as
  work/day4/log_review.json - the kind of file you attach to a capstone review.

BEFORE YOU RUN
  Run Example 07 first, so work/day4/logs/novaretail.log has some failures in it.
  Any novaretail command you ran yourself also writes to logs/novaretail.log.

WHERE THE CAPSTONE USES THIS
  logs/novaretail.log is written by src/novaretail/logging_setup.py.
  Day 8 collects the same kind of evidence for the final demo.

RUN:
  python practice/day4/d4_09_log_review.py
"""
import json
import os
from collections import Counter
from pathlib import Path

from novaretail.config import load_dotenv

load_dotenv()
SECRET = os.getenv("NOVA_API_KEY", "")
LOG_FILES = sorted(Path("logs").glob("*.log*")) + sorted((Path("work") / "day4" / "logs").glob("*.log*"))
OUT = Path("work") / "day4" / "log_review.json"

# ---------------------------------------------------------------- 1. Read every line of every log file
levels: Counter[str] = Counter()         # Counter counts things: levels["WARNING"] += 1
problems: list[str] = []
fallbacks = 0
leaks: list[str] = []

for path in LOG_FILES:
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        parts = line.split(" | ")        # our format: time | LEVEL | logger | message
        if len(parts) < 4:
            continue                     # traceback lines and other text: no level to count
        level, message = parts[1].strip(), parts[3]
        levels[level] += 1
        if level in ("ERROR", "CRITICAL"):
            problems.append(f"{path.name}:{number} {message}")
        if "source=cache" in message:
            fallbacks += 1
        if SECRET and SECRET in line:    # the key must NEVER appear in a log
            leaks.append(f"{path.name}:{number}")

# ---------------------------------------------------------------- 2. Print the review
print("1. files read :", [p.as_posix() for p in LOG_FILES])
print("2. lines by level:", dict(sorted(levels.items())))
print("3. errors:")
for p in problems[-5:]:                  # the last 5 are enough on screen; all are saved
    print("  ", p)
print("4. runs that used the cache:", fallbacks)
print("5. API key found in logs?  ", "YES - fix this!" if leaks else "no (good)")

# ---------------------------------------------------------------- 3. Save as evidence
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps({
    "files": [p.as_posix() for p in LOG_FILES],
    "levels": dict(levels),
    "errors": problems,
    "cache_fallbacks": fallbacks,
    "key_leaks": leaks,
}, indent=2), encoding="utf-8")
print("6. saved", OUT.as_posix())
