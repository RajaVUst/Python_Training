"""
Day 4 - Example 07: Cache fallback and exit codes of the capstone command

WHAT THIS EXAMPLE TEACHES
  The capstone command  novaretail report  is run five times, each time with a different
  problem, and we look at two things a scheduler (Day 7) relies on:
    * the EXIT CODE:  0 ok, 1 run failed, 2 configuration error, 3 authentication error
    * the LOG: what happened, in one or two lines

    1. normal run                         -> live data, exit 0 (and a snapshot is saved)
    2. API down                           -> retries, then the last snapshot is used, exit 0
    3. API down + --no-cache              -> no fallback allowed, exit 1
    4. wrong API key                      -> stops at once, exit 3
    5. NOVA_TIMEOUT=abc (bad setting)     -> stops before any call, exit 2

  Each run is started with subprocess, exactly as a scheduler would start it.
  Outputs and logs go to work/day4/ so the real output/ folder stays clean.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

WHERE THE CAPSTONE USES THIS
  src/novaretail/workflow.py -> run_report(): live fetch, else _fetch_cache()
  src/novaretail/cli.py      -> except ConfigError: 2, ApiAuthError: 3, NovaError: 1

RUN:
  python practice/day4/d4_07_fallback_exit_codes.py
"""
import os
import subprocess
import sys

import requests

from novaretail.config import load_dotenv

load_dotenv()
BASE = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")

# Environment for every run: the normal settings, plus a short backoff (faster demo) and
# separate output/log folders for this example.
BASE_ENV = {**os.environ, "NOVA_BACKOFF": "0.2",
            "NOVA_OUTPUT_DIR": "work/day4/output", "NOVA_LOG_DIR": "work/day4/logs"}
MEANING = {0: "success", 1: "run failed", 2: "configuration error", 3: "authentication error"}


def run(title: str, args: list[str], **env_changes: str) -> None:
    """Run `python -m novaretail <args>` and show the exit code plus the key lines."""
    env = {**BASE_ENV, **env_changes}
    # sys.executable = the Python of this venv, so the same packages are used.
    proc = subprocess.run([sys.executable, "-m", "novaretail", *args],
                          capture_output=True, text=True, env=env)
    print(f"{title}")
    print(f"   command : novaretail {' '.join(args)}")
    print(f"   exit    : {proc.returncode} ({MEANING.get(proc.returncode, '?')})")
    # The log goes to stderr, the summary to stdout. Show the lines that matter,
    # without the timestamp (the part before the first " | ").
    for line in (proc.stderr + proc.stdout).splitlines():
        if any(word in line for word in ("WARNING", "ERROR", "Report (", "CONFIG ERROR", "source=")):
            print("   log     :", line.split(" | ", 1)[-1][:140])


def chaos(fail_rate: float) -> None:
    requests.post(f"{BASE}/admin/chaos", json={"fail_rate": fail_rate}, timeout=5)


try:
    run("1. normal run", ["report"])

    chaos(1.0)                                     # every API call now returns 503
    run("2. API down: fall back to the last snapshot", ["report"])
    run("3. API down and --no-cache", ["report", "--no-cache"])
    chaos(0.0)

    run("4. wrong API key", ["report"], NOVA_API_KEY="wrong-key")
    run("5. bad setting", ["report"], NOVA_TIMEOUT="abc")
finally:
    requests.post(f"{BASE}/admin/reset", timeout=5)
