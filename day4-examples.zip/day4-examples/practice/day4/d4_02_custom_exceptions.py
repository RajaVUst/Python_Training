"""
Day 4 - Example 02: Your own exception classes, and raise ... from

WHAT THIS EXAMPLE TEACHES
  * A small exception hierarchy, so callers can react BY TYPE:
        NovaError                (anything from our toolkit)
          ConfigError            fix the settings, do not retry
          DataValidationError    bad data in a file or API answer
          ApiError               the API answered with an error (keeps .status)
            ApiAuthError         401/403: stop, fix the key
            ApiUnavailableError  network down / 5xx after all retries
  * Catching the parent class catches all its children.
  * raise NewError(...) from original: a clear message AND the original cause.
  * Converting low-level errors (json, KeyError) into our own types at the boundary.

WHERE THE CAPSTONE USES THIS
  src/novaretail/exceptions.py -> exactly this hierarchy
  src/novaretail/file_ops.py   -> read_json() raises DataValidationError from JSONDecodeError

RUN (no API needed):
  python practice/day4/d4_02_custom_exceptions.py
"""
import json


# ---------------------------------------------------------------- 1. The hierarchy
# A custom exception is just a class that inherits from Exception. The docstring is enough body.
class NovaError(Exception):
    """Base class for every error raised by the toolkit."""


class ConfigError(NovaError):
    """Missing or invalid configuration."""


class DataValidationError(NovaError):
    """Data does not have the expected shape."""


class ApiError(NovaError):
    """The API answered with an error status."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)          # the normal Exception message
        self.status = status               # extra information the caller can use


class ApiAuthError(ApiError):
    """401/403: retrying will not help."""


class ApiUnavailableError(ApiError):
    """Network failure or 5xx after all retries."""


# issubclass shows the family tree.
print("1. ApiAuthError is an ApiError?  ", issubclass(ApiAuthError, ApiError))
print("   ApiAuthError is a NovaError?  ", issubclass(ApiAuthError, NovaError))
print("   ConfigError is an ApiError?   ", issubclass(ConfigError, ApiError))


# ---------------------------------------------------------------- 2. Reacting by type
# One function that can fail in different ways. The caller decides what to do per type.
def call_api(scenario: str) -> str:
    if scenario == "ok":
        return "24 products"
    if scenario == "auth":
        raise ApiAuthError("GET /inventory -> 401: check NOVA_API_KEY", status=401)
    if scenario == "down":
        raise ApiUnavailableError("GET /inventory failed after 4 attempts", status=503)
    raise ConfigError("NOVA_TIMEOUT must be a number")


print("2. reacting by type")
for scenario in ["ok", "auth", "down", "config"]:
    try:
        print(f"   {scenario:<7}-> success:", call_api(scenario))
    except ApiAuthError as exc:                      # most specific first
        print(f"   {scenario:<7}-> STOP, alert the owner ({exc.status}): {exc}")
    except ApiUnavailableError as exc:
        print(f"   {scenario:<7}-> use the cached snapshot instead: {exc}")
    except NovaError as exc:                         # any other toolkit error
        print(f"   {scenario:<7}-> fail the run: {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------- 3. raise ... from
# json.loads raises json.JSONDecodeError with a technical message. At the boundary we turn it
# into OUR error with a message the operator understands. "from exc" keeps the original
# error attached as __cause__, so the full traceback shows both.
def parse_snapshot(text: str, name: str) -> dict:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise DataValidationError(f"{name} is not valid JSON (line {exc.lineno}): {exc.msg}") from exc


print("3. raise ... from")
try:
    parse_snapshot('{"products": [1, 2', "snapshot_20261013.json")
except DataValidationError as exc:
    print("   our message :", exc)
    print("   the cause   :", type(exc.__cause__).__name__, "-", exc.__cause__)


# ---------------------------------------------------------------- 4. Validate at the boundary
# A missing field would otherwise surface as a KeyError three functions later, far from
# where the bad data came in. Checking on the way in gives a precise message immediately.
def product_from_dict(data: dict) -> dict:
    for field in ("sku", "price"):
        if field not in data:
            raise DataValidationError(f"product {data.get('sku', '?')}: missing field {field!r}")
    if data["price"] < 0:
        raise DataValidationError(f"product {data['sku']}: negative price {data['price']}")
    return data


print("4. validate at the boundary")
good, bad = [], []
for item in [{"sku": "NR-1001", "price": 799.0}, {"sku": "NR-1002"}, {"sku": "NR-1003", "price": -5}]:
    try:
        good.append(product_from_dict(item))
    except DataValidationError as exc:      # one bad item is reported and skipped; the rest continue
        bad.append(str(exc))
print("   accepted:", [p["sku"] for p in good])
for message in bad:
    print("   rejected:", message)
