"""
Day 4 - Example 03: Logging instead of print

WHAT THIS EXAMPLE TEACHES
  * The five levels: DEBUG, INFO, WARNING, ERROR, CRITICAL, and when to use each.
  * The level setting hides everything below it (INFO hides DEBUG).
  * A format that answers: when, how serious, which module, what happened.
  * One logger per module: logging.getLogger(__name__).
  * %-style arguments:  log.info("loaded %d rows", n)  - not an f-string.
  * log.exception(...) inside except: the message PLUS the full traceback.

WHERE THE CAPSTONE USES THIS
  Every module in src/novaretail starts with   log = logging.getLogger(__name__)
  src/novaretail/logging_setup.py uses the same format string.

RUN (no API needed):
  python practice/day4/d4_03_logging_basics.py
"""
import logging
import sys

# ---------------------------------------------------------------- 1. Configure logging ONCE
# basicConfig sets up the root logger: where messages go (stdout here), the minimum level,
# and the format of each line. Real programs do this once, at the very start (cli.py does).
#   %(asctime)s    when            %(levelname)-8s  how serious (padded to 8 characters)
#   %(name)s       which logger    %(message)s      what happened
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
    stream=sys.stdout,          # print to the same place as print(), so the order stays readable
)

# ---------------------------------------------------------------- 2. One logger per module
# __name__ is the module name. In the toolkit it becomes e.g. "novaretail.api_client",
# so every log line says which module wrote it. Run as a script, __name__ is "__main__".
log = logging.getLogger("day4.demo")

print("2. the five levels with level=INFO (DEBUG is hidden):")
log.debug("GET /inventory -> 200 in 4 ms")                        # developer detail
log.info("Report done: products=24 low_stock=7")                   # normal milestone
log.warning("GET /products -> 503 (attempt 1/4), retrying")        # unexpected, job continues
log.error("Order failed for NR-1009: quantity must be 1..500")     # an operation failed
log.critical("Cannot write to output/: disk full")                 # the program cannot continue

# ---------------------------------------------------------------- 3. Changing the level
# Lower the level to DEBUG to see the detail while investigating a problem.
# The toolkit does this with:  novaretail -v report
print("3. same logger at DEBUG:")
logging.getLogger().setLevel(logging.DEBUG)    # getLogger() with no name = the root logger
log.debug("GET /inventory -> 200 in 4 ms")
logging.getLogger().setLevel(logging.INFO)     # back to normal

# ---------------------------------------------------------------- 4. %-style arguments
# The text is only built if the line is actually printed, and every line from the same
# template looks alike, so log tools can count them ("how many 503s today?").
rows, seconds = 24, 0.0123
print("4. %-style arguments:")
log.info("Loaded %d rows in %.3f s", rows, seconds)

# ---------------------------------------------------------------- 5. log.exception keeps the traceback
# Inside an except block, log.exception logs at ERROR level and adds the traceback, so the
# log file shows WHERE the error happened, not just that it happened.
print("5. log.exception:")
stock = {"NR-1001": 40}
try:
    stock["NR-9999"]
except KeyError:
    log.exception("Lookup failed for SKU %s", "NR-9999")

# ---------------------------------------------------------------- 6. A good log line vs a bad one
print("6. useful vs useless:")
log.error("error!!")                                                    # what? where? which item?
log.error("GET /inventory -> 503 after 4 attempts (2.1 s); using snapshot from 07:30")
