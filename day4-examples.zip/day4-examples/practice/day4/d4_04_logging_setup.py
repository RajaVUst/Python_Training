"""
Day 4 - Example 04: Console + rotating log file + secret redaction

WHAT THIS EXAMPLE TEACHES
  * Handlers decide WHERE log lines go: one to the console, one to a file.
  * Each handler can have its own level: console at INFO, file at DEBUG (more detail on disk).
  * RotatingFileHandler: when the file reaches a size, it is renamed .1, .2 ... so the disk
    never fills up.
  * A Filter that replaces the API key with **** before anything is written.
  * The capstone's setup_logging() does all of this in one call.

WHERE THE CAPSTONE USES THIS
  src/novaretail/logging_setup.py -> setup_logging(), RedactFilter
  src/novaretail/cli.py           -> calls setup_logging() once, at start

RUN (no API needed):
  python practice/day4/d4_04_logging_setup.py
"""
import logging
import logging.handlers
import sys
from pathlib import Path

LOG_DIR = Path("work") / "day4"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "app.log"
FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
API_KEY = "nova-lab-key-123"          # pretend secret, to show the redaction


# ---------------------------------------------------------------- 1. A filter that hides secrets
class RedactFilter(logging.Filter):
    """Replace every secret in the message with ****. Returning True keeps the line."""

    def __init__(self, secrets: list[str]):
        super().__init__()
        self.secrets = [s for s in secrets if s]       # ignore empty strings

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()                      # the final text, with %-arguments filled in
        for secret in self.secrets:
            if secret in msg:
                record.msg, record.args = msg.replace(secret, "****"), ()
                msg = record.msg
        return True


# ---------------------------------------------------------------- 2. Build the handlers
root = logging.getLogger()
root.setLevel(logging.DEBUG)              # the root lets everything through; handlers filter by level
for h in list(root.handlers):             # remove old handlers so running twice does not double lines
    root.removeHandler(h)

formatter = logging.Formatter(FORMAT)
redact = RedactFilter([API_KEY])

console = logging.StreamHandler(sys.stdout)
console.setLevel(logging.INFO)            # console: INFO and above
console.setFormatter(formatter)
console.addFilter(redact)

logfile = logging.handlers.RotatingFileHandler(
    LOG_FILE,
    maxBytes=1_000_000,                   # about 1 MB per file ...
    backupCount=5,                        # ... keep app.log.1 to app.log.5, delete older
    encoding="utf-8",
)
logfile.setLevel(logging.DEBUG)           # file: everything, for investigation later
logfile.setFormatter(formatter)
logfile.addFilter(redact)

root.addHandler(console)
root.addHandler(logfile)

# ---------------------------------------------------------------- 3. Log some lines
log = logging.getLogger("novaretail.demo")
print("3. console output (INFO and above):")
log.debug("Request headers: X-API-Key=%s", API_KEY)       # DEBUG: file only, key redacted
log.info("Starting report with key %s", API_KEY)          # key redacted on screen AND in file
log.warning("GET /products -> 503 (attempt 1/4)")
log.info("Report done: products=24 low_stock=7")

# ---------------------------------------------------------------- 4. What is in the file?
for h in root.handlers:
    h.flush()                              # make sure everything is written before we read it
lines = LOG_FILE.read_text(encoding="utf-8").splitlines()[-4:]   # last 4 lines of this run
print("4. last 4 lines in", LOG_FILE.as_posix(), "(includes DEBUG):")
for line in lines:
    print("  ", line.split(" | ", 1)[1])                  # drop the timestamp so the output is stable
print("   key present in file?", API_KEY in LOG_FILE.read_text(encoding="utf-8"))

# ---------------------------------------------------------------- 5. The capstone in one call
# setup_logging(level, log_dir, secrets) builds the same console + rotating file + redaction.
from novaretail.logging_setup import setup_logging  # noqa: E402  (imported here to keep the story in order)

setup_logging("INFO", LOG_DIR, secrets=[API_KEY], filename="toolkit_demo.log")
logging.getLogger("novaretail.workflow").info("Same format from the toolkit; key %s hidden", API_KEY)
