"""
Day 4 - Example 08: Context managers - cleanup and timing that always happen

WHAT THIS EXAMPLE TEACHES
  * A `with` block guarantees the cleanup code runs, even when an error happens inside.
  * @contextmanager turns a small generator function into your own `with` helper:
        code before `yield`  = set-up
        code after `yield`   = clean-up (put it in `finally` so it always runs)
  * A `timed(step)` helper that logs START, END and the duration of every step,
    and logs FAILED if the step fails, then lets the error continue to the caller.

WHERE THE CAPSTONE USES THIS
  NovaApiClient has __enter__/__exit__, so   with NovaApiClient(settings) as client:
  always closes its HTTP session. Files are opened with `with open(...)` everywhere.

RUN (no API needed):
  python practice/day4/d4_08_context_managers.py
"""
import logging
import sys
import time
from contextlib import contextmanager

logging.basicConfig(level=logging.INFO, format="%(levelname)-8s | %(message)s", stream=sys.stdout)
log = logging.getLogger("day4.timed")


# ---------------------------------------------------------------- 1. A context manager of our own
@contextmanager
def timed(step: str):
    """Log how long a step takes. If the step fails, log the error and re-raise it."""
    start = time.perf_counter()                 # set-up: runs when the with-block starts
    log.info("START %s", step)
    try:
        yield                                   # the code inside the with-block runs here
    except Exception:
        log.error("FAILED %s", step)            # log it ...
        raise                                   # ... and let the caller decide what to do
    finally:
        # clean-up: runs whether the block succeeded or failed.
        # Rounded to 0.1 s so the printed output is the same on every machine.
        log.info("END %s (%.1f s)", step, round(time.perf_counter() - start, 1))


# ---------------------------------------------------------------- 2. A step that works
print("1. a step that works")
with timed("fetch products"):
    time.sleep(0.2)                             # pretend to call the API

# ---------------------------------------------------------------- 3. A step that fails
print("2. a step that fails")
try:
    with timed("write report"):
        raise PermissionError("output/report.csv is open in Excel")
except PermissionError as exc:
    print("   caller handled it:", exc)


# ---------------------------------------------------------------- 4. The class way: __enter__ / __exit__
# This is how NovaApiClient does it. __exit__ is called when the with-block ends, with or
# without an error, so the session is always closed.
class FakeClient:
    def __enter__(self):
        print("   session opened")
        return self                             # this becomes the name after `as`

    def __exit__(self, exc_type, exc, tb):
        print("   session closed (error inside:", exc_type.__name__ if exc_type else None, ")")
        return False                            # False = do not hide the error

    def get_inventory(self, fail: bool):
        if fail:
            raise ConnectionError("network down")
        return ["NR-1001", "NR-1002"]


print("3. class-based context manager")
with FakeClient() as client:
    print("   got", client.get_inventory(fail=False))
try:
    with FakeClient() as client:
        client.get_inventory(fail=True)
except ConnectionError as exc:
    print("   caller saw:", exc)
