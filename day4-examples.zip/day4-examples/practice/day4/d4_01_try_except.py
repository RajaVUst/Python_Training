"""
Day 4 - Example 01: try / except / else / finally

WHAT THIS EXAMPLE TEACHES
  * What an exception is, and how to read the last line of a traceback.
  * try / except: catch ONE kind of error that you know how to handle.
  * else: code that runs only when nothing failed.
  * finally: code that ALWAYS runs (cleanup, timing), even after a return or an error.
  * Why a bare "except:" or "except Exception: pass" hides bugs.

WHERE THE CAPSTONE USES THIS
  src/novaretail/config.py  -> _env_int() / _env_float(): try int(...) except ValueError
  src/novaretail/models.py  -> validation raises clear errors instead of KeyError later

RUN (no API needed):
  python practice/day4/d4_01_try_except.py
"""


# ---------------------------------------------------------------- 1. An exception stops the program
# int("five") cannot work, so Python RAISES a ValueError. If nobody catches it, the program
# stops and prints a traceback. Here we catch it only to print the same last line you would see.
try:
    int("five")
except ValueError as exc:
    # type(exc).__name__ is the error class; str(exc) is its message.
    print("1. Last traceback line would be ->", f"{type(exc).__name__}: {exc}")


# ---------------------------------------------------------------- 2. try / except / else / finally
def parse_quantity(raw: str) -> int | None:
    """Turn the text "5" into the number 5. Return None for text that is not a number."""
    try:
        qty = int(raw)                 # ONLY the line that can fail goes inside try
    except ValueError:                 # the one error we expect and know how to handle
        print(f"   {raw!r:>8}: not a number -> None")
        return None
    else:                              # runs only when the try block did NOT fail
        print(f"   {raw!r:>8}: parsed -> {qty}")
        return qty
    finally:                           # runs in BOTH cases, even after the return statements above
        print(f"   {raw!r:>8}: finally ran")


print("2. parse_quantity")
results = [parse_quantity(x) for x in ["5", "five", " 12 "]]   # int() ignores spaces around digits
print("   results:", results)


# ---------------------------------------------------------------- 3. Several except blocks
# Different errors need different reactions, so each gets its own except.
# Python checks them top to bottom and runs the FIRST one that matches.
def unit_price(row: dict) -> float:
    try:
        return row["price"] / row["quantity"]
    except KeyError as exc:            # a column is missing in the data
        print(f"   missing field {exc} in {row}")
    except ZeroDivisionError:          # quantity is 0
        print(f"   quantity is 0 in {row}")
    except TypeError:                  # wrong type, e.g. price is text
        print(f"   wrong type in {row}")
    return 0.0


print("3. unit_price")
for row in [{"price": 100, "quantity": 4},
            {"price": 100},
            {"price": 100, "quantity": 0},
            {"price": "100", "quantity": 4}]:
    print("   ->", unit_price(row))


# ---------------------------------------------------------------- 4. The anti-pattern: swallowing errors
# This function has a TYPO: "quantiy". With "except Exception: pass" the typo is hidden,
# the function quietly returns 0, and the report shows wrong totals with no error anywhere.
def total_units_bad(rows: list[dict]) -> int:
    total = 0
    for r in rows:
        try:
            total += r["quantiy"]          # typo!
        except Exception:                  # catches EVERYTHING, including our own bug
            pass                           # ... and says nothing
    return total


def total_units_good(rows: list[dict]) -> int:
    # No try at all: if the data is wrong or the code has a typo, we WANT to see the error.
    return sum(r["quantity"] for r in rows)


rows = [{"quantity": 3}, {"quantity": 4}]
print("4. bad version returns :", total_units_bad(rows), "(wrong, and no error shown)")
print("   good version returns:", total_units_good(rows))


# ---------------------------------------------------------------- 5. finally for cleanup
# finally is where cleanup goes: closing files, sessions, stopping timers.
# Here the work fails, but "cleanup" still prints before the error reaches the caller.
def risky_step() -> None:
    print("5. open resource")
    try:
        raise ConnectionError("API dropped the connection")
    finally:
        print("   cleanup ran (resource closed)")


try:
    risky_step()
except ConnectionError as exc:
    print("   caller saw:", exc)
