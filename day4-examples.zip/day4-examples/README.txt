Day 4 - Error Handling and Logging: example files
=================================================

1. Copy the folder  practice/day4  into your novaretail-toolkit project
   (so you have  novaretail-toolkit/practice/day4/d4_01_try_except.py ...).
2. Copy the folder  lab4  into the project root.
3. Activate the venv, and start the mock API in a second terminal:
       python mock_api/server.py
4. Run each example from the project root, in order:
       python practice/day4/d4_01_try_except.py
       ...
       python practice/day4/d4_09_log_review.py
   Examples 01-05, 08 and 09 do not need the API; 06 and 07 do (run 07 before 09).
   Examples 06 and 07 put the mock API into "chaos" mode and reset it at the end.
   Output and logs go to  work/day4/  (safe to delete at any time).

Lab 4 (hardened watchlist) - builds on Lab 3
   needs data/input/watchlist.csv from Lab 3
   copy lab4/lab4_watchlist_starter.py  -> examples/lab4_watchlist.py   (complete the 10 TODOs)
   lab4_watchlist_solution.py           trainer reference solution
   Expected with a healthy API: 3 alerts, 1 unknown SKU (NR-9999), exit code 0
   Exit codes: 0 ok, 1 run failed, 2 configuration error, 3 wrong API key
