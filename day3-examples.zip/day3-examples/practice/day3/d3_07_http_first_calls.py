"""
Day 3 - Example 07: First API calls with requests

WHAT THIS EXAMPLE TEACHES
  * A request = method + URL (+ query parameters) + headers (+ body).
  * A response = status code + headers + body (JSON here).
  * The NovaRetail API needs the header  X-API-Key  on every endpoint except /health.
  * What 200, 401 and 404 look like, and how to read them in Python.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> NovaApiClient._request() does these calls for the toolkit

RUN:
  python practice/day3/d3_07_http_first_calls.py
"""
import os

import requests  # installed in the venv on Day 1

from novaretail.config import load_dotenv  # the toolkit's .env loader (same as Example 06)

load_dotenv()                                     # puts NOVA_API_KEY etc. into os.environ
BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")
API_KEY = os.environ["NOVA_API_KEY"]              # [] (not getenv): crash early if it is missing

# ---------------------------------------------------------------- 1. GET /health (no key needed)
# timeout=5: give up after 5 seconds. requests has NO default timeout (Example 08 shows why it matters).
resp = requests.get(f"{BASE_URL}/health", timeout=5)
print("1. GET /health")
print("   status code  :", resp.status_code)                     # 200 = OK
print("   content type :", resp.headers["Content-Type"])         # the server says: the body is JSON
print("   body as text :", resp.text[:40], "...")                # raw text (first 40 characters)
print("   body as dict :", resp.json()["status"])                # .json() parses the text into a dict
print("   took (ms)    :", round(resp.elapsed.total_seconds() * 1000))   # varies on every run

# ---------------------------------------------------------------- 2. GET /products/1 WITHOUT the key
resp = requests.get(f"{BASE_URL}/products/1", timeout=5)
print("2. GET /products/1 without key ->", resp.status_code, resp.json())

# ---------------------------------------------------------------- 3. The same call WITH the key
# Headers are a dict. X-API-Key carries the key; Accept says which format we want back.
headers = {"X-API-Key": API_KEY, "Accept": "application/json"}
resp = requests.get(f"{BASE_URL}/products/1", headers=headers, timeout=5)
product = resp.json()
print("3. GET /products/1 with key    ->", resp.status_code)
print("   product      :", product)
print("   name, price  :", product["name"], product["price"])

# ---------------------------------------------------------------- 4. A product that does not exist
resp = requests.get(f"{BASE_URL}/products/99", headers=headers, timeout=5)
print("4. GET /products/99            ->", resp.status_code, resp.json()["detail"])
print("   resp.ok      :", resp.ok, "(True only for status codes below 400)")

# ---------------------------------------------------------------- 5. Query parameters
# params= builds the ?page=2&page_size=5 part of the URL for you (and escapes special characters).
resp = requests.get(f"{BASE_URL}/products", params={"page": 2, "page_size": 5}, headers=headers, timeout=5)
data = resp.json()
print("5. final URL    :", resp.url)
print("   keys in body :", list(data.keys()))
print("   page", data["page"], "has", len(data["items"]), "items; first:", data["items"][0]["name"],
      "| total", data["total"], "| has_next", data["has_next"])
