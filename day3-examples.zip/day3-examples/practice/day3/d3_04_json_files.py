"""
Day 3 - Example 04: JSON files - the format APIs speak

WHAT THIS EXAMPLE TEACHES
  * json.dumps() turns Python data into JSON text; json.loads() turns it back.
  * indent=2 (readable), ensure_ascii=False (keeps ₹), default=str (dates, paths).
  * How Python types map to JSON types (dict->object, None->null, True->true).
  * Handle a broken JSON file with json.JSONDecodeError and report the line number.

WHERE THE CAPSTONE USES THIS
  src/novaretail/file_ops.py -> write_json() and read_json() (same three options)
  src/novaretail/workflow.py -> the report summary and the API snapshot are JSON files

RUN:
  python practice/day3/d3_04_json_files.py
"""
import json
from datetime import datetime
from pathlib import Path

work = Path("work") / "day3"
work.mkdir(parents=True, exist_ok=True)
summary_file = work / "summary.json"

# ---------------------------------------------------------------- 1. Python data to JSON text
# A typical report summary. Note the two values JSON does not understand natively:
# a datetime and a Path. A fixed date is used so everyone sees the same output.
summary = {
    "generated_at": datetime(2026, 10, 9, 10, 15, 0),
    "report_file": work / "inventory_report.csv",
    "store": "NovaRetail ₹ outlet",
    "totals": {"products": 24, "low_stock": 7},
    "low_stock_skus": ["NR-1004", "NR-1009"],
    "from_cache": False,
    "cache_taken_at": None,
}
text = json.dumps(
    summary,
    indent=2,             # one key per line, indented: readable in any editor and in Git diffs
    ensure_ascii=False,   # keep ₹ as ₹ (otherwise it is saved as an escape code)
    default=str,          # anything json cannot handle (datetime, Path, Decimal) -> str(value)
)
print("1. JSON text:")
print(text)

# ---------------------------------------------------------------- 2. Write and read the file
summary_file.write_text(text, encoding="utf-8")
loaded = json.loads(summary_file.read_text(encoding="utf-8"))   # JSON text -> Python dict

# Values come back as Python types again: dict, list, int, bool, None.
# The datetime came back as a STRING, because JSON has no date type.
print("2. low_stock      :", loaded["totals"]["low_stock"])
print("   first low SKU  :", loaded["low_stock_skus"][0])
print("   from_cache     :", loaded["from_cache"], type(loaded["from_cache"]).__name__)
print("   cache_taken_at :", loaded["cache_taken_at"])
print("   generated_at   :", loaded["generated_at"], type(loaded["generated_at"]).__name__)

# ---------------------------------------------------------------- 3. Without default=str
# This is the error trainees meet first when they put a datetime in a report.
try:
    json.dumps({"when": datetime(2026, 10, 9)})
except TypeError as exc:
    print("3. TypeError:", exc)

# ---------------------------------------------------------------- 4. A broken JSON file
# A missing comma between two keys. JSONDecodeError tells us the line and column, so the
# message can point the user straight at the problem.
broken = work / "broken.json"
broken.write_text('{\n  "products": 24\n  "low_stock": 7\n}', encoding="utf-8")
try:
    json.loads(broken.read_text(encoding="utf-8"))
except json.JSONDecodeError as exc:
    print(f"4. {broken.name} is not valid JSON (line {exc.lineno}, column {exc.colno}): {exc.msg}")
