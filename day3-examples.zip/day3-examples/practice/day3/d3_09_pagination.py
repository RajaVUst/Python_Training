"""
Day 3 - Example 09: Pagination - fetching every page

WHAT THIS EXAMPLE TEACHES
  * Why APIs return lists one page at a time (page, page_size, has_next, total).
  * A while-loop that keeps asking for the next page until has_next is False.
  * The same loop as a GENERATOR (yield), so callers just write: for p in iter_products()
  * What the server says when page_size is out of range (400).

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> NovaApiClient.iter_products() and get_products()

RUN:
  python practice/day3/d3_09_pagination.py
"""
import os
from collections.abc import Iterator

import requests

from novaretail.config import load_dotenv

load_dotenv()
BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")

session = requests.Session()
session.headers.update({"X-API-Key": os.environ["NOVA_API_KEY"], "Accept": "application/json"})

# ---------------------------------------------------------------- 1. The loop, written out
# Ask for page 1, keep the items, look at has_next, ask for page 2 ... until there are no more.
print("1. while-loop with page_size=10")
all_products = []
page = 1
while True:
    resp = session.get(f"{BASE_URL}/products", params={"page": page, "page_size": 10}, timeout=5)
    resp.raise_for_status()                      # any error stops the loop with an exception
    data = resp.json()
    all_products.extend(data["items"])           # extend adds every item of the page to our list
    print(f"   page {page}: {len(data['items'])} items, has_next={data['has_next']}")
    if not data["has_next"]:                     # the API tells us when we have reached the end
        break
    page += 1
print("   total collected:", len(all_products), "| API says total =", data["total"])


# ---------------------------------------------------------------- 2. The same loop as a generator
def iter_products(page_size: int = 10) -> Iterator[dict]:
    """Yield products one by one, fetching the next page only when it is needed.

    `yield` hands one item to the caller and PAUSES here. When the caller asks for the
    next item, the function continues where it stopped. The caller never sees pages.
    """
    page = 1
    while True:
        resp = session.get(f"{BASE_URL}/products", params={"page": page, "page_size": page_size}, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        yield from data["items"]                 # same as: for item in data["items"]: yield item
        if not data["has_next"]:
            return                               # ends the generator; the caller's for-loop stops
        page += 1


# The caller simply loops. Pagination is hidden inside iter_products().
grocery = [p["name"] for p in iter_products(page_size=7) if p["category"] == "Grocery"]
print("2. grocery items  :", grocery)

# A generator can stop early: next() takes just the first item, so only page 1 is fetched.
first = next(iter_products(page_size=5))
print("   first product  :", first["sku"], first["name"])

# ---------------------------------------------------------------- 3. Out-of-range page size
# The server accepts page_size 1..50. 51 is rejected with 400 (bad request): our input is wrong.
resp = session.get(f"{BASE_URL}/products", params={"page": 1, "page_size": 51}, timeout=5)
print("3. page_size=51   :", resp.status_code, resp.json()["detail"])

# ---------------------------------------------------------------- 4. Fewer calls with bigger pages
# page_size=50 returns all 24 products in ONE call. Fewer calls = faster and kinder to the API.
for page_size in (5, 10, 50):
    calls = -(-24 // page_size)                  # ceiling division: how many pages for 24 items
    print(f"4. page_size={page_size:<2} -> {calls} call(s), got {len(list(iter_products(page_size)))} products")

session.close()
