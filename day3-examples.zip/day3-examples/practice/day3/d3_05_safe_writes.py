"""
Day 3 - Example 05: Writing report files safely

WHAT THIS EXAMPLE TEACHES
  * Timestamped file names, so each run keeps its own report.
  * Atomic writes: write to a temporary file, then swap it in with os.replace().
    If the script crashes halfway, the previous good report is still there.
  * Housekeeping: keep only the newest N reports.

WHERE THE CAPSTONE USES THIS
  src/novaretail/file_ops.py -> timestamped_path(), _atomic_write_text(), cleanup_old_files()
  This file is a small, fully commented copy of those three functions.

RUN:
  python practice/day3/d3_05_safe_writes.py
"""
import os
import tempfile
from datetime import datetime
from pathlib import Path

work = Path("work") / "day3" / "safe"
work.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------- helper 1: timestamped name
def timestamped_path(folder: Path, prefix: str, suffix: str, now: datetime | None = None) -> Path:
    """Return folder/prefix_YYYYmmdd_HHMMSS.suffix, e.g. inventory_report_20261009_101500.csv.

    `now` can be passed in, so the same input always gives the same name (handy for tests).
    """
    now = now or datetime.now()                       # use the real clock if no time is given
    return folder / f"{prefix}_{now:%Y%m%d_%H%M%S}{suffix}"   # year-month-day sorts correctly by name


# ---------------------------------------------------------------- helper 2: unsafe write
def unsafe_write(path: Path, lines: list[str], crash_after: int | None = None) -> None:
    """Write straight into the target file. A crash leaves a HALF-written file behind."""
    with open(path, "w", encoding="utf-8") as fh:     # "w" empties the old report immediately
        for i, line in enumerate(lines):
            if i == crash_after:
                raise RuntimeError("simulated crash")  # pretend the API failed mid-report
            fh.write(line + "\n")


# ---------------------------------------------------------------- helper 3: atomic write
def atomic_write(path: Path, lines: list[str], crash_after: int | None = None) -> None:
    """Write to a temp file in the SAME folder, then replace the target in one step."""
    path.parent.mkdir(parents=True, exist_ok=True)
    # mkstemp creates a new, uniquely named temp file and returns (file descriptor, path).
    # The same folder matters: os.replace is only atomic within one drive / file system.
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            for i, line in enumerate(lines):
                if i == crash_after:
                    raise RuntimeError("simulated crash")
                fh.write(line + "\n")
        os.replace(tmp, path)          # the swap: readers see the old file or the new one, never half
    except BaseException:
        Path(tmp).unlink(missing_ok=True)   # clean up the temp file, then let the error continue
        raise


good_report = ["sku,on_hand", "NR-1001,40", "NR-1002,3"]

# ---------------------------------------------------------------- 1. The problem: a crash mid-write
plain = work / "report_plain.csv"
unsafe_write(plain, good_report)                       # first run succeeds
try:
    unsafe_write(plain, good_report, crash_after=1)    # second run crashes after one line
except RuntimeError as exc:
    print("1. unsafe write crashed:", exc)
print("   report_plain.csv now contains:", plain.read_text(encoding="utf-8").splitlines())

# ---------------------------------------------------------------- 2. The fix: atomic write
safe = work / "report_safe.csv"
atomic_write(safe, good_report)
try:
    atomic_write(safe, good_report, crash_after=1)
except RuntimeError as exc:
    print("2. atomic write crashed:", exc)
print("   report_safe.csv still contains:", safe.read_text(encoding="utf-8").splitlines())
print("   temp files left behind:", list(work.glob("*.tmp")))

# ---------------------------------------------------------------- 3. Timestamped names
# Five "daily runs" at 09:00 on five different days.
for day in range(5, 10):
    path = timestamped_path(work, "inventory_report", ".csv", now=datetime(2026, 10, day, 9, 0, 0))
    atomic_write(path, good_report)
names = sorted(p.name for p in work.glob("inventory_report_*.csv"))
print("3. reports on disk:", len(names))
for name in names:
    print("  ", name)

# ---------------------------------------------------------------- 4. Keep only the newest 3
# Sort newest first (by name, because the timestamp is in the name), keep 3, delete the rest.
# The toolkit sorts by file modification time (st_mtime) instead; the idea is the same.
reports = sorted(work.glob("inventory_report_*.csv"), reverse=True)
for old in reports[3:]:
    old.unlink()                                       # delete the file
print("4. after cleanup:", sorted(p.name for p in work.glob("inventory_report_*.csv")))
