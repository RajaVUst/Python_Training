"""
Day 3 - Example 11: The capstone report in miniature (API -> join -> CSV + JSON)

WHAT THIS EXAMPLE TEACHES
  Everything from Examples 01-10 combined into ONE small automation, written as
  plain functions so every step is visible:

      .env  ->  settings
      GET /products (all pages) + GET /inventory     (API)
      save the raw API data as a snapshot JSON        (evidence + Day 4 fallback)
      join products with stock by SKU                 (Day 2 skills)
      CSV report + JSON summary, timestamped, atomic  (files)

  This is the same flow as the capstone's  run_report()  in src/novaretail/workflow.py.
  Example 12 runs the capstone's own version and compares the numbers.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

RUN:
  python practice/day3/d3_11_mini_pipeline.py
"""
import csv
import io
import json
import os
import tempfile
import time
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

import requests

from novaretail.config import load_dotenv

OUT = Path("work") / "day3" / "reports"
REPORT_FIELDS = ["sku", "name", "category", "price", "on_hand", "reorder_level", "stock_value", "is_low_stock"]


# ================================================================ step 1: settings
def load_settings() -> dict:
    """Read the three settings we need. The key comes from .env, never from the code."""
    load_dotenv()
    key = os.getenv("NOVA_API_KEY")
    if not key:
        raise SystemExit("NOVA_API_KEY is not set (copy .env.example to .env)")
    return {
        "base_url": os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/"),
        "api_key": key,
        "timeout": float(os.getenv("NOVA_TIMEOUT", "5")),
    }


# ================================================================ step 2: API calls
def make_session(settings: dict) -> requests.Session:
    """One Session with the auth header, reused for every call."""
    session = requests.Session()
    session.headers.update({"X-API-Key": settings["api_key"], "Accept": "application/json"})
    return session


def iter_products(session: requests.Session, settings: dict, page_size: int = 10) -> Iterator[dict]:
    """Generator over every product, page by page (Example 09)."""
    page = 1
    while True:
        resp = session.get(f"{settings['base_url']}/products",
                           params={"page": page, "page_size": page_size}, timeout=settings["timeout"])
        resp.raise_for_status()
        data = resp.json()
        yield from data["items"]
        if not data["has_next"]:
            return
        page += 1


def get_inventory(session: requests.Session, settings: dict) -> list[dict]:
    resp = session.get(f"{settings['base_url']}/inventory", timeout=settings["timeout"])
    resp.raise_for_status()
    return resp.json()["items"]


# ================================================================ step 3: files (Example 05)
def timestamped_path(folder: Path, prefix: str, suffix: str) -> Path:
    return folder / f"{prefix}_{datetime.now():%Y%m%d_%H%M%S}{suffix}"


def atomic_write_text(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
    return path


def write_json(data, path: Path) -> Path:
    return atomic_write_text(path, json.dumps(data, indent=2, ensure_ascii=False, default=str))


def write_csv(rows: list[dict], path: Path, fieldnames: list[str]) -> Path:
    # Build the CSV text in memory (io.StringIO acts like a file), then write it atomically.
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")   # ignore extra keys
    writer.writeheader()
    writer.writerows(rows)
    return atomic_write_text(path, buf.getvalue())


# ================================================================ step 4: business logic (Day 2)
def join_inventory(products: list[dict], stock: list[dict]) -> tuple[list[dict], list[str]]:
    """One report row per product that has a stock record. Products without one are listed, not dropped."""
    stock_by_sku = {s["sku"]: s for s in stock}          # dict lookup by SKU instead of a nested loop
    rows, missing = [], []
    for p in products:
        s = stock_by_sku.get(p["sku"])
        if s is None:
            missing.append(p["sku"])
            continue
        rows.append({
            **p,                                          # id, sku, name, category, price
            "on_hand": s["on_hand"],
            "reorder_level": s["reorder_level"],
            "stock_value": round(p["price"] * s["on_hand"], 2),
            "is_low_stock": s["on_hand"] <= s["reorder_level"],
        })
    return rows, missing


# ================================================================ the pipeline
def run() -> None:
    started = time.perf_counter()                         # to measure how long the run takes
    settings = load_settings()

    with make_session(settings) as session:               # the with-block closes the session at the end
        products = list(iter_products(session, settings))
        stock = get_inventory(session, settings)
    print(f"Fetched {len(products)} products and {len(stock)} stock records")

    # Raw API data, saved before any processing: proof of what the API returned.
    snapshot = write_json({"taken_at": datetime.now().isoformat(timespec="seconds"),
                           "products": products, "inventory": stock},
                          timestamped_path(OUT.parent / "snapshots", "snapshot", ".json"))

    rows, missing = join_inventory(products, stock)
    low = sorted((r for r in rows if r["is_low_stock"]), key=lambda r: r["on_hand"] - r["reorder_level"])
    total_value = round(sum(r["stock_value"] for r in rows), 2)

    csv_path = write_csv(rows, timestamped_path(OUT, "inventory_report", ".csv"), REPORT_FIELDS)
    json_path = write_json({
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "totals": {"products": len(rows), "low_stock": len(low), "stock_value": total_value},
        "low_stock_items": [{"sku": r["sku"], "name": r["name"], "on_hand": r["on_hand"],
                             "reorder_level": r["reorder_level"]} for r in low],
        "missing_skus": missing,
    }, timestamped_path(OUT, "inventory_summary", ".json"))

    print(f"Products: {len(rows)} | low stock: {len(low)} | stock value: {total_value:,.2f}")
    print("Most urgent:", [(r["sku"], r["on_hand"], r["reorder_level"]) for r in low[:3]])
    print("Files written:")
    for path in (snapshot, csv_path, json_path):
        print("  ", path.as_posix())
    print(f"Done in {time.perf_counter() - started:.2f} s")


if __name__ == "__main__":     # run() only when the file is executed, not when it is imported
    run()
