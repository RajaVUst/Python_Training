"""
Day 3 - Example 08: A Session, timeouts, and every kind of failure

WHAT THIS EXAMPLE TEACHES
  * requests.Session: set the headers once and reuse the connection for every call.
  * One helper function that decides what to do with each status code.
  * raise_for_status(): turn any 4xx/5xx into an exception.
  * The three failures every automation must expect:
      - the server answers with an error (401, 404, 503)
      - the server is too slow  -> requests.Timeout
      - nothing is listening    -> requests.ConnectionError

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py
  This script uses the mock API's /admin/chaos endpoint to make it slow or failing
  for a moment, and /admin/reset to put it back to normal.

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> one Session, timeout on every call, status-code rules.
  Day 4 adds automatic retries for the failures that are worth retrying.

RUN:
  python practice/day3/d3_08_session_and_errors.py
"""
import os

import requests

from novaretail.config import load_dotenv

load_dotenv()
BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")

# ---------------------------------------------------------------- 1. One Session for the whole run
# Every request made through `session` sends these headers automatically, and the TCP
# connection is kept open and reused, which is faster than reconnecting for each call.
session = requests.Session()
session.headers.update({
    "X-API-Key": os.environ["NOVA_API_KEY"],
    "Accept": "application/json",
    "User-Agent": "novaretail-day3-practice",   # tells the server who is calling (shows in its logs)
})


def get_json(path: str, timeout: float = 5) -> dict | None:
    """GET a path and apply the NovaRetail status-code rules.

    200       -> return the parsed JSON
    404       -> the item does not exist: return None, the caller skips it
    401 / 403 -> configuration problem: stop the whole run with a clear message
    others    -> raise_for_status() raises requests.HTTPError
    """
    resp = session.get(f"{BASE_URL}{path}", timeout=timeout)
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 404:
        return None
    if resp.status_code in (401, 403):
        raise SystemExit(f"Authentication failed ({resp.status_code}): check NOVA_API_KEY in .env")
    resp.raise_for_status()          # 400, 500, 503 ... -> requests.HTTPError
    return None                      # only reached for other 2xx/3xx codes, which this API never sends


# ---------------------------------------------------------------- 2. Normal calls through the helper
print("1. product 3      :", get_json("/products/3")["name"])
print("   product 99     :", get_json("/products/99"), "(None = not found, skipped)")
print("   inventory rows :", len(get_json("/inventory")["items"]))

# ---------------------------------------------------------------- 3. Server error: 503
# Ask the mock API to fail every call (fail_rate 1.0 = 100%).
requests.post(f"{BASE_URL}/admin/chaos", json={"fail_rate": 1.0}, timeout=5)
try:
    get_json("/inventory")
except requests.HTTPError as exc:
    print("2. HTTPError      :", exc.response.status_code, "-", exc.response.json()["detail"])
requests.post(f"{BASE_URL}/admin/reset", timeout=5)          # back to normal

# ---------------------------------------------------------------- 4. Too slow: Timeout
# Make every call take 2 seconds, but only wait 1 second.
requests.post(f"{BASE_URL}/admin/chaos", json={"latency": 2}, timeout=5)
try:
    get_json("/inventory", timeout=1)
except requests.Timeout as exc:
    print("3. Timeout        :", type(exc).__name__, "- gave up after 1 second instead of waiting forever")
requests.post(f"{BASE_URL}/admin/reset", timeout=5)

# ---------------------------------------------------------------- 5. Nothing listening: ConnectionError
# Port 8099 has no server, so the connection is refused immediately.
try:
    requests.get("http://127.0.0.1:8099/health", timeout=2)
except requests.ConnectionError as exc:
    print("4. ConnectionError:", type(exc).__name__, "- is the server running? right host and port?")

# ---------------------------------------------------------------- 6. Wrong key: stop the run
session.headers["X-API-Key"] = "wrong-key"
try:
    get_json("/inventory")
except SystemExit as exc:
    print("5. Stopped        :", exc)

session.close()   # release the connection (a `with requests.Session() as session:` block does this for you)
