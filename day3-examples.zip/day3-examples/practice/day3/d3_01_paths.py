"""
Day 3 - Example 01: Paths that work on every operating system (pathlib)

WHAT THIS EXAMPLE TEACHES
  * Build file paths with pathlib.Path and the / operator, never by gluing strings.
  * Read the parts of a path: name, stem, suffix, parent.
  * Create folders safely, check whether a file exists, and find files with glob().
  * Build paths from the script's own location, so the script works from any folder.

WHERE THE CAPSTONE USES THIS
  src/novaretail/file_ops.py -> timestamped_path(), latest_file(), cleanup_old_files()
  src/novaretail/config.py   -> Settings.output_dir and Settings.log_dir are Path objects

RUN (from the project root, venv active):
  python practice/day3/d3_01_paths.py
"""
from pathlib import Path  # Path is a class: one Path object describes one location on disk

# ---------------------------------------------------------------- 1. Build a path
# The / operator joins the parts with the right separator for the operating system:
#   Windows       -> work\day3\paths_demo
#   Linux / macOS -> work/day3/paths_demo
# Writing "work" + "/" + "day3" by hand breaks on one OS or the other; Path never does.
work = Path("work") / "day3"
reports = work / "paths_demo"
print("1. demo folder    :", reports)

# ---------------------------------------------------------------- 2. Create folders
# parents=True  -> also create "work" and "work/day3" if they do not exist yet
# exist_ok=True -> no error if the folder already exists, so the script can run many times
reports.mkdir(parents=True, exist_ok=True)
print("2. exists?        :", reports.exists(), "| is a folder?", reports.is_dir())

# ---------------------------------------------------------------- 3. Parts of a path
# Building a Path does NOT create a file. It is only a description of a location.
report = reports / "inventory_report_20261009_101500.csv"
print("3. full path      :", report)
print("   name           :", report.name)     # last part, with the extension
print("   stem           :", report.stem)     # name without the extension
print("   suffix         :", report.suffix)   # the extension, including the dot
print("   parent         :", report.parent)   # the folder that contains it
print("   exists?        :", report.exists()) # False: nothing has been written yet

# ---------------------------------------------------------------- 4. Create files and find them with glob
# touch() creates an empty file (or just updates its time if it already exists).
# We create three "daily reports" and one unrelated file.
for stamp in ["20261007_090000", "20261008_090000", "20261009_090000"]:
    (reports / f"inventory_report_{stamp}.csv").touch()
(reports / "notes.txt").touch()

# glob() finds files that match a pattern; * means "any characters".
# notes.txt does not match, so it is not returned.
# sorted() puts them in name order; our names contain the date, so name order = date order.
matches = sorted(reports.glob("inventory_report_*.csv"))
print("4. glob found     :", len(matches), "reports ->", [p.name for p in matches])
print("   newest report  :", matches[-1].name)   # [-1] is the last item in the list

# ---------------------------------------------------------------- 5. Relative vs absolute paths
# A relative path is relative to the CURRENT folder (the folder you ran the command from).
# resolve() turns it into the full absolute path. This line differs on every machine.
print("5. relative       :", report)
print("   absolute       :", report.resolve())
print("   current folder :", Path.cwd())

# ---------------------------------------------------------------- 6. Paths relative to the script itself
# __file__ is the path of this .py file. A scheduler (Day 7) often starts scripts from
# another folder, so "work/day3" would land somewhere unexpected. Paths built from the
# script's own location are always correct.
HERE = Path(__file__).resolve().parent      # .../practice/day3
PROJECT_ROOT = HERE.parent.parent           # up two levels: practice/day3 -> practice -> project root
print("6. script folder  :", HERE.name)
print("   project root has pyproject.toml?", (PROJECT_ROOT / "pyproject.toml").exists())
