"""
Day 3 - Example 03: CSV files - write, read, validate

WHAT THIS EXAMPLE TEACHES
  * csv.DictWriter / csv.DictReader: each row is a dict, keyed by the column name.
  * newline="" when opening a CSV file (otherwise Windows writes a blank line between rows).
  * Commas inside a value are quoted automatically by the csv module.
  * Everything read from a CSV is a STRING: convert and validate at the boundary.
  * Check the required columns before processing (fail fast with a clear message).
  * encoding="utf-8-sig" when business users will open the file in Excel.

WHERE THE CAPSTONE USES THIS
  src/novaretail/file_ops.py -> write_csv(), read_csv(path, required=[...])
  Lab 3 reads data/input/watchlist.csv exactly this way.

RUN:
  python practice/day3/d3_03_csv_files.py
"""
import csv
from pathlib import Path

work = Path("work") / "day3"
work.mkdir(parents=True, exist_ok=True)
restock_csv = work / "restock_request.csv"

# ---------------------------------------------------------------- 1. Write a CSV with DictWriter
# Each row is a dict. fieldnames fixes the column order in the file.
# Row 2 has a comma inside the note; row 3 has a deliberate mistake ("two" is not a number).
rows = [
    {"sku": "NR-1001", "quantity": 5, "note": "Wireless Mouse"},
    {"sku": "NR-1007", "quantity": 12, "note": "Basmati Rice, 5kg"},
    {"sku": "NR-1013", "quantity": "two", "note": "typo in quantity"},
    {"sku": "NR-1004", "quantity": 900, "note": "too many"},
]
# newline="" lets the csv module write its own line endings. Without it, Windows
# turns each "\r\n" into "\r\r\n" and Excel shows an empty row after every row.
with restock_csv.open("w", newline="", encoding="utf-8") as fh:
    writer = csv.DictWriter(fh, fieldnames=["sku", "quantity", "note"])
    writer.writeheader()          # first line: sku,quantity,note
    writer.writerows(rows)        # one line per dict

# Look at the raw file: the note with a comma is wrapped in double quotes, so the
# comma is treated as text, not as a column separator.
print("1. raw file on disk:")
print(restock_csv.read_text(encoding="utf-8"))

# ---------------------------------------------------------------- 2. Read it back with DictReader
with restock_csv.open(newline="", encoding="utf-8") as fh:
    reader = csv.DictReader(fh)           # uses the first line as the keys
    columns = reader.fieldnames           # ['sku', 'quantity', 'note']
    raw_rows = list(reader)               # read all rows now, while the file is open
print("2. columns     :", columns)
print("   first row   :", raw_rows[0])
print("   quantity is :", type(raw_rows[0]["quantity"]).__name__, "- every CSV value is text")

# ---------------------------------------------------------------- 3. Check required columns
# A set difference gives the columns that are required but missing from the file.
REQUIRED = {"sku", "quantity"}
missing_columns = REQUIRED - set(columns)
if missing_columns:
    raise SystemExit(f"{restock_csv}: missing columns {sorted(missing_columns)}")
print("3. required columns present:", sorted(REQUIRED))

# ---------------------------------------------------------------- 4. Convert and validate each row
# Good rows go to `valid`, bad rows go to `errors` with the line number, so one bad row
# does not stop the whole file. Line 1 is the header, so data starts at line 2.
valid, errors = [], []
for line_no, row in enumerate(raw_rows, start=2):
    try:
        qty = int(row["quantity"])                       # "5" -> 5 ; "two" -> ValueError
    except ValueError:
        errors.append(f"line {line_no}: quantity {row['quantity']!r} is not a whole number")
        continue                                         # skip to the next row
    if not 1 <= qty <= 500:                              # the API accepts 1..500 only
        errors.append(f"line {line_no}: quantity {qty} must be between 1 and 500")
        continue
    valid.append({"sku": row["sku"].strip(), "quantity": qty})   # strip() removes stray spaces

print("4. valid rows  :", valid)
for message in errors:
    print("   rejected    :", message)

# ---------------------------------------------------------------- 5. An Excel-friendly copy
# Excel on Windows guesses the encoding. "utf-8-sig" adds 3 marker bytes (a BOM) at the
# start so Excel knows it is UTF-8 and shows ₹ correctly. Python reads it fine too.
excel_csv = work / "restock_request_excel.csv"
with excel_csv.open("w", newline="", encoding="utf-8-sig") as fh:
    writer = csv.DictWriter(fh, fieldnames=["sku", "quantity", "price"])
    writer.writeheader()
    writer.writerow({"sku": "NR-1001", "quantity": 5, "price": "₹799"})
print("5. first bytes :", excel_csv.read_bytes()[:3], "<- the BOM that Excel looks for")
