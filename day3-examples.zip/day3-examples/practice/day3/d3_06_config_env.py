"""
Day 3 - Example 06: Configuration and secrets from .env

WHAT THIS EXAMPLE TEACHES
  * Why the API key never goes in the code: it lives in .env (ignored by Git) or in
    the server's environment variables.
  * How a .env file is loaded into os.environ (real environment variables win).
  * Reading settings with defaults, converting types, and failing fast on bad values.
  * Hiding the key: field(repr=False) and a masked version for logs.
  * The toolkit's own Settings.from_env() does all of this in one call.

WHERE THE CAPSTONE USES THIS
  src/novaretail/config.py -> load_dotenv(), Settings, Settings.from_env(), masked_key

RUN (from the project root, so .env is found):
  python practice/day3/d3_06_config_env.py
"""
import os
from dataclasses import dataclass, field
from pathlib import Path


# ---------------------------------------------------------------- 1. Load .env into the environment
def load_dotenv(path: Path = Path(".env")) -> int:
    """Read KEY=VALUE lines into os.environ. Returns how many lines were read."""
    if not path.is_file():                    # no .env file is not an error: the server may set real env vars
        return 0
    count = 0
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:   # skip blanks and comments
            continue
        key, value = line.split("=", 1)       # split on the FIRST "=" only; values may contain "="
        # setdefault: only set it if it is NOT already set. A real environment variable
        # (set in the terminal or by the scheduler) therefore wins over the file.
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
        count += 1
    return count


print("1. lines read from .env:", load_dotenv())


# ---------------------------------------------------------------- 2. A small Settings class
@dataclass(frozen=True)                       # frozen: settings cannot be changed by accident later
class Settings:
    base_url: str
    api_key: str = field(repr=False)          # repr=False: print(settings) will NOT show the key
    timeout: float = 5.0

    @property
    def masked_key(self) -> str:
        """Safe to log: only the last 4 characters."""
        return "****" + self.api_key[-4:]


def settings_from_env() -> Settings:
    key = os.getenv("NOVA_API_KEY", "").strip()       # getenv returns the default if the name is missing
    if not key:
        # Fail fast: a clear message now is better than a 401 from the API later.
        raise SystemExit("NOVA_API_KEY is not set. Copy .env.example to .env and fill it in.")
    raw_timeout = os.getenv("NOVA_TIMEOUT", "5")      # environment values are ALWAYS strings
    try:
        timeout = float(raw_timeout)
    except ValueError:
        raise SystemExit(f"NOVA_TIMEOUT must be a number, got {raw_timeout!r}") from None
    base = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")   # no trailing slash
    return Settings(base_url=base, api_key=key, timeout=timeout)


settings = settings_from_env()
print("2. settings       :", settings)                 # the key is not in this line
print("   masked key     :", settings.masked_key)
print("   timeout type   :", type(settings.timeout).__name__)

# ---------------------------------------------------------------- 3. Real env vars win over .env
# Simulate an operator overriding the timeout for one run, then reload.
os.environ["NOVA_TIMEOUT"] = "12"
load_dotenv()                                          # .env says 5, but setdefault keeps 12
print("3. timeout after override:", settings_from_env().timeout)
del os.environ["NOVA_TIMEOUT"]                         # undo the override

# ---------------------------------------------------------------- 4. The capstone does the same in one call
# novaretail is installed in the venv (pip install -e .), so we can import it from anywhere.
from novaretail.config import Settings as ToolkitSettings  # noqa: E402  (import here to keep the story in order)

toolkit_settings = ToolkitSettings.from_env()
print("4. toolkit Settings:", toolkit_settings.api_base_url, "| key", toolkit_settings.masked_key,
      "| retries", toolkit_settings.max_retries, "| output", toolkit_settings.output_dir)
