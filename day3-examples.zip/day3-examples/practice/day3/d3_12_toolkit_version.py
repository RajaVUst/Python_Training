"""
Day 3 - Example 12: The same report with the capstone toolkit

WHAT THIS EXAMPLE TEACHES
  Example 11 wrote every step by hand. The capstone keeps each step in its own module,
  so the same report takes a few lines. Compare the two files side by side:

      Example 11 (by hand)            capstone module
      ----------------------------    -------------------------------------------
      load_settings()                 config.Settings.from_env()
      make_session(), iter_products() api_client.NovaApiClient (+ retries, Day 4)
      get_inventory()                 NovaApiClient.get_inventory()
      dicts                           models.Product / StockLevel (validated, Day 2)
      join_inventory()                transform.join_inventory(), find_low_stock()
      write_csv(), write_json()       file_ops.write_csv(), write_json() (atomic)
      the whole run()                 workflow.run_report()  /  novaretail report

  The numbers printed here must match Example 11. If they do, the hand-written
  pipeline and the capstone agree.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py

RUN:
  python practice/day3/d3_12_toolkit_version.py
"""
from pathlib import Path

from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.file_ops import timestamped_path, write_csv, write_json
from novaretail.transform import find_low_stock, join_inventory, total_stock_value

OUT = Path("work") / "day3" / "toolkit"

# ---------------------------------------------------------------- 1. Settings: one call
settings = Settings.from_env()          # reads .env, validates every value, hides the key
print("1. API:", settings.api_base_url, "| key:", settings.masked_key)

# ---------------------------------------------------------------- 2. API: a client object
# `with` closes the HTTP session at the end, even if an error happens.
with NovaApiClient(settings) as client:
    products = client.get_products()    # all pages; each item is a validated Product object
    stock = client.get_inventory()      # list of StockLevel objects
print("2. first product object:", products[0])

# ---------------------------------------------------------------- 3. Business rules (Day 2 functions)
rows, missing = join_inventory(products, stock)
low = find_low_stock(rows)
print(f"3. Products: {len(rows)} | low stock: {len(low)} | stock value: {total_stock_value(rows):,.2f}")
print("   Most urgent:", [(r.sku, r.on_hand, r.reorder_level) for r in low[:3]])

# ---------------------------------------------------------------- 4. Files: atomic, timestamped
csv_path = write_csv([r.to_dict() for r in rows], timestamped_path(OUT, "inventory_report", ".csv"))
json_path = write_json({"low_stock": [r.to_dict() for r in low], "missing_skus": missing},
                       timestamped_path(OUT, "low_stock", ".json"))
print("4. Files written:")
print("  ", csv_path.as_posix())
print("  ", json_path.as_posix())

# ---------------------------------------------------------------- 5. The full capstone command
# The capstone wraps all of this (plus logging, retries and a cache fallback) in one command.
# Run it yourself in the terminal and look in output/reports/:
#     novaretail report            (or:  python -m novaretail report)
print("5. Next: run  novaretail report  and open output/reports/")
