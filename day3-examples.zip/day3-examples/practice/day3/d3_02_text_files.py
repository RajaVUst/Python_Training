"""
Day 3 - Example 02: Reading and writing text files

WHAT THIS EXAMPLE TEACHES
  * open() with a mode: "w" (write, replaces the file), "a" (append), "r" (read, the default).
  * Why every open() needs encoding="utf-8" (the Rupee sign is the test).
  * The with-statement: the file is closed for you, even if an error happens inside.
  * The shortcuts Path.write_text() / Path.read_text() for small files.
  * Reading a file line by line, and handling a missing file.

WHERE THE CAPSTONE USES THIS
  src/novaretail/config.py   -> load_dotenv() reads .env with read_text(encoding="utf-8")
  src/novaretail/file_ops.py -> every read and write passes encoding="utf-8"

RUN:
  python practice/day3/d3_02_text_files.py
"""
from pathlib import Path

work = Path("work") / "day3"
work.mkdir(parents=True, exist_ok=True)
notes = work / "run_notes.txt"

# ---------------------------------------------------------------- 1. Write a new file ("w")
# "w" creates the file, or EMPTIES it first if it already exists.
# encoding="utf-8": without it Windows may use an old code page (cp1252) and the
# Rupee sign either fails to write or comes back as garbage on another machine.
# The with-block closes the file automatically when the indented block ends.
with open(notes, "w", encoding="utf-8") as fh:
    fh.write("NovaRetail run notes\n")            # \n = end of line; write() does NOT add one
    fh.write("Wireless Mouse price: ₹799\n")

# ---------------------------------------------------------------- 2. Add to the end ("a")
# "a" (append) keeps what is already there and writes after it. Useful for simple logs.
with open(notes, "a", encoding="utf-8") as fh:
    fh.write("Second run: OK\n")

# ---------------------------------------------------------------- 3. Read the whole file
# read_text() opens, reads everything into ONE string, and closes the file. Good for small files.
text = notes.read_text(encoding="utf-8")
print("3. whole file as one string:")
print(text)

# ---------------------------------------------------------------- 4. Read line by line
# Looping over the file object gives one line at a time, so even a 2 GB log file
# never has to fit in memory. enumerate(..., start=1) numbers the lines from 1.
# rstrip("\n") removes the line ending so print() does not add a blank line.
print("4. line by line:")
with open(notes, encoding="utf-8") as fh:        # mode "r" (read) is the default
    for number, line in enumerate(fh, start=1):
        clean = line.rstrip("\n")
        print(f"   line {number}: {clean}")

# ---------------------------------------------------------------- 5. Characters vs bytes
# A file on disk stores BYTES. The encoding decides how characters become bytes.
# In UTF-8 the letter A is 1 byte but the Rupee sign is 3 bytes.
print("5. 'A' in UTF-8 :", "A".encode("utf-8"))   # noqa: UP012  (explicit on purpose)
print("   '₹' in UTF-8 :", "₹".encode("utf-8"), "->", len("₹".encode("utf-8")), "bytes")   # noqa: UP012
print("   file size    :", notes.stat().st_size, "bytes for", len(text), "characters")

# ---------------------------------------------------------------- 6. A file that does not exist
# Reading a missing file raises FileNotFoundError. Catch it and say clearly what is missing,
# instead of letting the script crash with a long traceback.
missing = work / "does_not_exist.txt"
try:
    missing.read_text(encoding="utf-8")
except FileNotFoundError as exc:
    print("6. FileNotFoundError for:", Path(exc.filename).name)

# The alternative: check first with exists(). Both are fine; try/except is safer when
# another program might delete the file between the check and the read.
if not missing.exists():
    print("   exists() says False, so we skip reading it")
