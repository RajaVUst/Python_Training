"""
Day 3 - Example 10: Sending data - POST /orders

WHAT THIS EXAMPLE TEACHES
  * POST with a JSON body: json={...} serialises the dict and sets Content-Type for you.
  * 201 Created on success; 400 with a list of validation errors on bad data.
  * data= vs json=: data= sends a web form, which this API rejects.
  * A batch of orders with a DRY-RUN switch, where one bad line does not stop the batch.

BEFORE YOU RUN
  Terminal 2 must be running the mock API:   python mock_api/server.py
  The script calls /admin/reset first, so order numbers start at 1 every time.

WHERE THE CAPSTONE USES THIS
  src/novaretail/api_client.py -> NovaApiClient.create_order()
  src/novaretail/workflow.py   -> run_restock(execute=False) is the same dry-run pattern

RUN:
  python practice/day3/d3_10_post_orders.py
"""
import os

import requests

from novaretail.config import load_dotenv

load_dotenv()
BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")

session = requests.Session()
session.headers.update({"X-API-Key": os.environ["NOVA_API_KEY"], "Accept": "application/json"})
session.post(f"{BASE_URL}/admin/reset", timeout=5)          # training only: clear old orders

# ---------------------------------------------------------------- 1. A valid order
# json= turns the dict into JSON text and adds the header Content-Type: application/json.
resp = session.post(f"{BASE_URL}/orders", json={"sku": "NR-1001", "quantity": 3}, timeout=5)
order = resp.json()
print("1. valid order    :", resp.status_code, "->", {k: order[k] for k in ("order_id", "sku", "quantity", "status")})

# ---------------------------------------------------------------- 2. An invalid order
# The server checks the data and lists EVERY problem. 400 means "your request is wrong":
# sending it again will fail again, so we never retry a 400. We record it and move on.
resp = session.post(f"{BASE_URL}/orders", json={"sku": "NOPE", "quantity": 0}, timeout=5)
print("2. invalid order  :", resp.status_code, resp.json()["detail"])

# ---------------------------------------------------------------- 3. data= instead of json=
# data= sends "sku=NR-1001&quantity=3" (a web form). This API only accepts JSON.
resp = session.post(f"{BASE_URL}/orders", data={"sku": "NR-1001", "quantity": 3}, timeout=5)
print("3. data= mistake  :", resp.status_code, resp.json()["detail"])


# ---------------------------------------------------------------- 4. A batch with a dry-run switch
def place_orders(lines: list[dict], execute: bool = False) -> list[dict]:
    """Return one result per line. With execute=False nothing is sent (safe default)."""
    results = []
    for line in lines:
        if not execute:
            results.append({**line, "status": "planned (dry-run)"})     # {**line, ...} copies the dict and adds a key
            continue
        resp = session.post(f"{BASE_URL}/orders", json=line, timeout=5)
        if resp.status_code == 201:
            results.append({**line, "status": "created", "order_id": resp.json()["order_id"]})
        else:
            # One bad line must not stop the others: record the reason and continue.
            results.append({**line, "status": f"failed {resp.status_code}: {resp.json()['detail']}"})
    return results


batch = [
    {"sku": "NR-1004", "quantity": 20},
    {"sku": "NR-1009", "quantity": 600},          # too many: the server will reject this line
    {"sku": "NR-1019", "quantity": 15},
]
print("4. dry run:")
for r in place_orders(batch):
    print("  ", r)
print("   execute=True:")
for r in place_orders(batch, execute=True):
    print("  ", r)

# ---------------------------------------------------------------- 5. Read back what was created
orders = session.get(f"{BASE_URL}/orders", timeout=5).json()["items"]
print("5. orders on the server:", [(o["order_id"], o["sku"], o["quantity"]) for o in orders])
session.close()
