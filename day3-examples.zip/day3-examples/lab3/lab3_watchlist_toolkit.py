"""
Lab 3 - STRETCH solution: the watchlist using the capstone toolkit

Same result as lab3_watchlist_solution.py, but the settings, the HTTP client and the
file writing come from src/novaretail. Count the lines you no longer need to write:
no Session, no headers, no raise_for_status, no csv/json boilerplate, and the client
already validates every stock record (models.StockLevel) and retries failures (Day 4).

RUN:
  python examples/lab3_watchlist_toolkit.py
"""
import sys
from datetime import datetime
from pathlib import Path

from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.exceptions import ApiAuthError, NovaError
from novaretail.file_ops import read_csv, timestamped_path, write_csv, write_json


def main() -> int:
    settings = Settings.from_env()                                       # .env + validation
    rows = read_csv(Path("data/input/watchlist.csv"), required=["sku", "min_stock"])   # checks the columns
    watch = {r["sku"].strip(): int(r["min_stock"]) for r in rows}

    try:
        with NovaApiClient(settings) as client:
            stock = {s.sku: s.on_hand for s in client.get_inventory()}  # StockLevel objects -> dict
    except ApiAuthError as exc:                                          # 401/403: no retry, fix the key
        print("ERROR:", exc)
        return 3
    except NovaError as exc:                                             # unreachable after all retries, etc.
        print("ERROR:", exc)
        return 1

    alerts = sorted(
        ({"sku": k, "on_hand": stock[k], "min_stock": m, "short_by": m - stock[k]}
         for k, m in watch.items() if k in stock and stock[k] < m),
        key=lambda a: a["short_by"], reverse=True)
    unknown = sorted(k for k in watch if k not in stock)

    now = datetime.now()
    csv_path = write_csv(alerts, timestamped_path(settings.output_dir, "watchlist", ".csv", now),
                         ["sku", "on_hand", "min_stock", "short_by"])   # atomic write
    json_path = write_json({"watched": len(watch), "alerts": len(alerts), "unknown_skus": unknown},
                           timestamped_path(settings.output_dir, "watchlist", ".json", now))
    print(f"Watched {len(watch)}, alerts {len(alerts)}, unknown {len(unknown)}")
    print("Files:", csv_path.as_posix(), json_path.as_posix())
    return 0


if __name__ == "__main__":
    sys.exit(main())
