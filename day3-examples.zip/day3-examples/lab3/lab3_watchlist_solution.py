"""
Lab 3 - Stock watchlist (TRAINER SOLUTION)

THE BUSINESS ASK
  The store manager keeps a short list of products that must never run low, each with
  a minimum stock level. Every morning they want to know which of those products are
  below their minimum, so they can reorder before customers notice.

INPUT    data/input/watchlist.csv                    columns: sku,min_stock
OUTPUT   output/watchlist_<timestamp>.csv            sku, on_hand, min_stock, short_by
         output/watchlist_<timestamp>.json           counts, unknown SKUs, run time
EXIT     0 = OK, 1 = API unreachable / bad input, 3 = wrong API key

RUN (project root, venv active, mock API running in terminal 2):
  python examples/lab3_watchlist.py

EXPECTED with the sample watchlist: 5 watched, 3 alerts, 1 unknown SKU (NR-9999)

WHERE THIS GOES NEXT
  Day 5 moves check() into src/novaretail/transform.py as check_watchlist() and adds a
  `novaretail watchlist --file ...` command to the capstone CLI. Keep this file: it is
  your Day 3 evidence.
"""
import csv
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

from novaretail.config import load_dotenv

INPUT = Path("data") / "input" / "watchlist.csv"
OUT_DIR = Path("output")
CSV_FIELDS = ["sku", "on_hand", "min_stock", "short_by"]


def load_settings() -> dict:
    """Read the API settings from the environment (.env is loaded first)."""
    load_dotenv()                                            # .env -> os.environ (real env vars win)
    key = os.getenv("NOVA_API_KEY", "").strip()
    if not key:
        sys.exit("NOVA_API_KEY is not set. Copy .env.example to .env.")   # exit code 1 with this message
    return {
        "base_url": os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/"),
        "api_key": key,
        "timeout": float(os.getenv("NOVA_TIMEOUT", "5")),
    }


def read_watchlist(path: Path) -> dict[str, int]:
    """Return {sku: min_stock}. Stops with a clear message if the file or a column is wrong."""
    if not path.is_file():
        sys.exit(f"Watchlist not found: {path}")
    with path.open(newline="", encoding="utf-8") as fh:      # newline="" for csv, utf-8 always
        reader = csv.DictReader(fh)
        missing = {"sku", "min_stock"} - set(reader.fieldnames or [])
        if missing:
            sys.exit(f"{path}: missing columns {sorted(missing)}")
        watch = {}
        for line_no, row in enumerate(reader, start=2):      # line 1 is the header
            try:
                watch[row["sku"].strip()] = int(row["min_stock"])   # CSV text -> int
            except ValueError:
                sys.exit(f"{path} line {line_no}: min_stock {row['min_stock']!r} is not a whole number")
    return watch


def fetch_stock(settings: dict) -> dict[str, int]:
    """Call GET /inventory ONCE and return {sku: on_hand}."""
    with requests.Session() as session:                      # closed automatically after the block
        session.headers.update({"X-API-Key": settings["api_key"], "Accept": "application/json"})
        resp = session.get(f"{settings['base_url']}/inventory", timeout=settings["timeout"])
        resp.raise_for_status()                              # 401, 503 ... -> requests.HTTPError
        return {item["sku"]: item["on_hand"] for item in resp.json()["items"]}


def check(watch: dict[str, int], stock: dict[str, int]) -> tuple[list[dict], list[str]]:
    """Compare stock with the watchlist. Returns (alerts, unknown_skus)."""
    alerts = [
        {"sku": sku, "on_hand": stock[sku], "min_stock": min_stock, "short_by": min_stock - stock[sku]}
        for sku, min_stock in watch.items()
        if sku in stock and stock[sku] < min_stock           # known SKU AND below its minimum
    ]
    alerts.sort(key=lambda a: a["short_by"], reverse=True)    # biggest shortfall first
    unknown = sorted(sku for sku in watch if sku not in stock)   # in the list but not in the API
    return alerts, unknown


def write_outputs(alerts: list[dict], summary: dict, stamp: str) -> tuple[Path, Path]:
    """Write the CSV and the JSON summary; return both paths."""
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUT_DIR / f"watchlist_{stamp}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        writer.writeheader()                                 # header is written even when there are no alerts
        writer.writerows(alerts)
    json_path = OUT_DIR / f"watchlist_{stamp}.json"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return csv_path, json_path


def main() -> int:
    started = time.perf_counter()
    settings = load_settings()
    watch = read_watchlist(INPUT)

    try:
        stock = fetch_stock(settings)
    except requests.HTTPError as exc:
        if exc.response.status_code in (401, 403):
            print(f"ERROR: the API rejected the key ({exc.response.status_code}). Check NOVA_API_KEY in .env.")
            return 3
        print(f"ERROR: the API answered {exc.response.status_code}: {exc.response.text[:200]}")
        return 1
    except requests.Timeout:                                 # check Timeout before ConnectionError:
        print(f"ERROR: no answer within {settings['timeout']} s from {settings['base_url']}.")
        return 1                                             # ConnectTimeout is both kinds
    except requests.ConnectionError:
        print(f"ERROR: cannot reach the API at {settings['base_url']}. Is the mock server running?")
        return 1

    alerts, unknown = check(watch, stock)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary = {
        "run_at": stamp,
        "watched": len(watch),
        "alerts": len(alerts),
        "unknown_skus": unknown,
        "seconds": round(time.perf_counter() - started, 3),
    }
    csv_path, json_path = write_outputs(alerts, summary, stamp)

    for a in alerts:
        print(f"ALERT {a['sku']}: on hand {a['on_hand']}, minimum {a['min_stock']}, short by {a['short_by']}")
    for sku in unknown:
        print(f"UNKNOWN {sku}: not in the API inventory - check the watchlist")
    print(f"Watched {summary['watched']}, alerts {summary['alerts']}, unknown {len(unknown)}")
    print("Files:", csv_path.as_posix(), json_path.as_posix())
    return 0


if __name__ == "__main__":
    sys.exit(main())
