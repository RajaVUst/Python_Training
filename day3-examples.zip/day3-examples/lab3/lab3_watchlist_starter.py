"""
Lab 3 - Stock watchlist (STARTER FILE: complete every TODO)

THE BUSINESS ASK
  The store manager keeps a short list of products that must never run low, each with
  a minimum stock level. Every morning they want to know which of those products are
  below their minimum, so they can reorder before customers notice.

INPUT
  data/input/watchlist.csv      columns: sku,min_stock

WHAT THE SCRIPT MUST DO
  1. Read the API settings from .env (never write the key in this file).
  2. Read the watchlist CSV and convert min_stock to int.
  3. Call GET /inventory ONCE (a Session, a timeout).
  4. Find watched SKUs whose on_hand is BELOW min_stock, and SKUs the API does not know.
  5. Write output/watchlist_<timestamp>.csv   (sku, on_hand, min_stock, short_by)
     and   output/watchlist_<timestamp>.json  (counts, unknown SKUs, run time).
  6. Give a clear message (not a traceback) for a wrong key and for a stopped server.

RUN (project root, venv active, mock API running in terminal 2):
  python examples/lab3_watchlist.py

EXPECTED RESULT with the sample watchlist:  5 watched, 3 alerts, 1 unknown SKU (NR-9999)
"""
import csv  # noqa: F401  (you will use these three imports in the TODOs)
import json
import os  # noqa: F401
import sys
import time
from datetime import datetime
from pathlib import Path

import requests  # noqa: F401

from novaretail.config import load_dotenv

INPUT = Path("data") / "input" / "watchlist.csv"
OUT_DIR = Path("output")


def load_settings() -> dict:
    """Return {"base_url": ..., "api_key": ..., "timeout": ...} from the environment."""
    load_dotenv()
    # TODO 1: read NOVA_API_KEY with os.getenv. If it is empty, stop with
    #         sys.exit("NOVA_API_KEY is not set ...")
    # TODO 2: read NOVA_API_BASE_URL (default "http://127.0.0.1:8000") and NOVA_TIMEOUT (default 5, as float)
    # TODO 3: return the three values in a dict
    ...


def read_watchlist(path: Path) -> dict[str, int]:
    """Return {sku: min_stock}, e.g. {"NR-1002": 5, ...}."""
    # TODO 4: open the file with newline="" and encoding="utf-8"
    # TODO 5: use csv.DictReader; for each row, strip() the sku and int() the min_stock
    # Tip: a dict comprehension does it in one line:  {row["sku"].strip(): int(row["min_stock"]) for row in reader}
    ...


def fetch_stock(settings: dict) -> dict[str, int]:
    """Call GET /inventory once and return {sku: on_hand}."""
    # TODO 6: create a requests.Session in a with-block, set the X-API-Key and Accept headers
    # TODO 7: GET f"{base_url}/inventory" with timeout=settings["timeout"]; call raise_for_status()
    # TODO 8: build and return {item["sku"]: item["on_hand"] for item in resp.json()["items"]}
    ...


def check(watch: dict[str, int], stock: dict[str, int]) -> tuple[list[dict], list[str]]:
    """Return (alerts, unknown_skus)."""
    # TODO 9: alerts = one dict per watched SKU that exists in stock AND has on_hand < min_stock:
    #         {"sku": ..., "on_hand": ..., "min_stock": ..., "short_by": min_stock - on_hand}
    # TODO 10: unknown = sorted list of watched SKUs that are not in stock
    ...


def write_outputs(alerts: list[dict], summary: dict, stamp: str) -> tuple[Path, Path]:
    """Write the CSV and JSON files and return their paths."""
    # TODO 11: OUT_DIR.mkdir(parents=True, exist_ok=True)
    # TODO 12: write OUT_DIR / f"watchlist_{stamp}.csv" with csv.DictWriter
    #          (fieldnames sku, on_hand, min_stock, short_by; newline=""; encoding="utf-8")
    # TODO 13: write OUT_DIR / f"watchlist_{stamp}.json" with json.dumps(summary, indent=2)
    ...


def main() -> int:
    started = time.perf_counter()
    settings = load_settings()
    watch = read_watchlist(INPUT)

    # TODO 14: call fetch_stock(settings) inside try/except:
    #   requests.HTTPError with status 401 -> print a clear message about NOVA_API_KEY, return 3
    #   requests.ConnectionError            -> print "cannot reach the API ... is the mock server running?", return 1
    #   requests.Timeout                    -> print a message, return 1
    stock = fetch_stock(settings)

    alerts, unknown = check(watch, stock)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary = {
        "run_at": stamp,
        "watched": len(watch),
        "alerts": len(alerts),
        "unknown_skus": unknown,
        "seconds": round(time.perf_counter() - started, 3),
    }
    csv_path, json_path = write_outputs(alerts, summary, stamp)
    print(json.dumps(summary, indent=2))
    print("Files:", csv_path, json_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())     # the return value becomes the exit code: 0 = success
