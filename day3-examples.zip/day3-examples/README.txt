Day 3 - File and API Automation: example files
==============================================

1. Copy the folder  practice/day3  into your novaretail-toolkit project
   (so you have  novaretail-toolkit/practice/day3/d3_01_paths.py ...).
2. Copy the folder  lab3  into the project root.
3. Activate the venv, and start the mock API in a second terminal:
       python mock_api/server.py
4. Run each example from the project root, in order:
       python practice/day3/d3_01_paths.py
       ...
       python practice/day3/d3_12_toolkit_version.py
   Examples 01-06 do not need the API; 07-12 do.
   Output files go to  work/day3/  (safe to delete at any time).

Lab 3 (stock watchlist)
   copy lab3/watchlist.csv                 -> data/input/watchlist.csv
   copy lab3/lab3_watchlist_starter.py     -> examples/lab3_watchlist.py   (complete the TODOs)
   lab3_watchlist_solution.py              trainer reference solution
   lab3_watchlist_toolkit.py               stretch task: same result using the toolkit
   Expected: 5 watched, 3 alerts, 1 unknown SKU (NR-9999)
