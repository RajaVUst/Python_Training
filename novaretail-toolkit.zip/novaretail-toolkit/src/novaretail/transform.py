"""Pure functions: no network, no files, no globals -> trivially testable.

Day 2 teaching file: functions, type hints, list/dict/set comprehensions,
defaultdict, sorted() with key=, and returning new data instead of mutating.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from .models import InventoryRow, Product, StockLevel


def join_inventory(products: Iterable[Product], stock: Iterable[StockLevel]) -> tuple[list[InventoryRow], list[str]]:
    """Join products with stock by SKU.

    Returns (rows, missing_skus). Products without a stock record are reported,
    not silently dropped -- data gaps must be visible.
    """
    stock_by_sku: dict[str, StockLevel] = {s.sku: s for s in stock}   # dict comprehension = O(1) lookups
    rows: list[InventoryRow] = []
    missing: list[str] = []
    for p in products:
        s = stock_by_sku.get(p.sku)
        if s is None:
            missing.append(p.sku)
            continue
        rows.append(InventoryRow(p.sku, p.name, p.category, p.price, s.on_hand, s.reorder_level))
    return rows, missing


def find_low_stock(rows: Iterable[InventoryRow]) -> list[InventoryRow]:
    """Low-stock rows, most urgent first (largest shortfall below reorder level)."""
    low = [r for r in rows if r.is_low_stock]
    return sorted(low, key=lambda r: (r.on_hand - r.reorder_level, r.sku))


def summarize_by_category(rows: Iterable[InventoryRow]) -> dict[str, dict]:
    """{category: {"products": n, "units": u, "stock_value": v, "low_stock": k}} sorted by category."""
    acc: defaultdict[str, dict] = defaultdict(lambda: {"products": 0, "units": 0, "stock_value": 0.0, "low_stock": 0})
    for r in rows:
        c = acc[r.category]
        c["products"] += 1
        c["units"] += r.on_hand
        c["stock_value"] += r.stock_value
        c["low_stock"] += int(r.is_low_stock)
    return {cat: {**v, "stock_value": round(v["stock_value"], 2)} for cat, v in sorted(acc.items())}


def restock_quantity(row: InventoryRow, cover_factor: int = 2) -> int:
    """How many units to order so stock reaches cover_factor x reorder_level.

    >>> restock_quantity(InventoryRow("A", "a", "c", 1.0, on_hand=5, reorder_level=10))
    15
    """
    if cover_factor < 1:
        raise ValueError("cover_factor must be >= 1")
    target = row.reorder_level * cover_factor
    return max(target - row.on_hand, 0)


def plan_restock(rows: Iterable[InventoryRow], cover_factor: int = 2, max_qty: int = 500) -> list[dict]:
    """Build order lines for every low-stock row (capped at max_qty, which the API enforces)."""
    plan = []
    for r in find_low_stock(rows):
        qty = min(restock_quantity(r, cover_factor), max_qty)
        if qty > 0:
            plan.append({"sku": r.sku, "name": r.name, "quantity": qty})
    return plan


def total_stock_value(rows: Iterable[InventoryRow]) -> float:
    return round(sum(r.stock_value for r in rows), 2)
