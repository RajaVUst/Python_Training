"""NovaRetail mock API -- fully offline, standard library only.

Run:
    python mock_api/server.py                  # http://127.0.0.1:8000
    python mock_api/server.py --port 8001
    python mock_api/server.py --fail-rate 0.3  # 30% of calls return 503 (chaos mode)
    python mock_api/server.py --latency 2      # every call sleeps 2 seconds

Endpoints (all except /health need header  X-API-Key: <key>):
    GET  /health
    GET  /products?page=1&page_size=10
    GET  /products/<id>
    GET  /inventory
    POST /orders            body: {"sku": "NR-1001", "quantity": 5}
    GET  /orders
    POST /admin/chaos       body: {"fail_rate": 0.5, "latency": 0}   (classroom demos)
    POST /admin/reset       resets orders and chaos settings

The lab key is read from env NOVA_MOCK_API_KEY (default: nova-lab-key-123).
It is a training key for a local server only -- never reuse real keys like this.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

API_KEY = os.getenv("NOVA_MOCK_API_KEY", "nova-lab-key-123")

CATEGORIES = ["Electronics", "Home", "Grocery", "Apparel"]

PRODUCTS = [
    {"id": i, "sku": f"NR-{1000 + i}", "name": name, "category": cat, "price": price}
    for i, (name, cat, price) in enumerate(
        [
            ("Wireless Mouse", "Electronics", 799.0),
            ("USB-C Charger 65W", "Electronics", 1899.0),
            ("Bluetooth Speaker", "Electronics", 2499.0),
            ("LED Desk Lamp", "Home", 1299.0),
            ("Steel Water Bottle", "Home", 549.0),
            ("Non-stick Pan 24cm", "Home", 1499.0),
            ("Basmati Rice 5kg", "Grocery", 699.0),
            ("Green Tea 100 bags", "Grocery", 349.0),
            ("Almonds 1kg", "Grocery", 999.0),
            ("Cotton T-Shirt", "Apparel", 499.0),
            ("Running Shoes", "Apparel", 3299.0),
            ("Denim Jacket", "Apparel", 2799.0),
            ("Mechanical Keyboard", "Electronics", 4599.0),
            ("Cushion Cover Set", "Home", 899.0),
            ("Olive Oil 1L", "Grocery", 1099.0),
            ("Rain Jacket", "Apparel", 1999.0),
            ("Smart Plug", "Electronics", 1199.0),
            ("Bedsheet Double", "Home", 1399.0),
            ("Dark Chocolate 200g", "Grocery", 299.0),
            ("Wool Socks (3 pack)", "Apparel", 599.0),
            ("Power Bank 20000mAh", "Electronics", 2199.0),
            ("Ceramic Mug Set", "Home", 799.0),
            ("Instant Coffee 200g", "Grocery", 549.0),
            ("Track Pants", "Apparel", 1299.0),
        ],
        start=1,
    )
]

# Deterministic stock so every learner sees the same numbers.
_rng = random.Random(42)
INVENTORY = [
    {"sku": p["sku"], "on_hand": _rng.randint(0, 60), "reorder_level": _rng.choice([10, 15, 20])}
    for p in PRODUCTS
]

STATE = {"orders": [], "fail_rate": 0.0, "latency": 0.0, "next_order_id": 1}
LOCK = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    server_version = "NovaRetailMock/1.0"

    # ---------- helpers ----------
    def _send(self, status: int, payload) -> None:
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            return json.loads(raw or b"{}")
        except json.JSONDecodeError:
            return None

    def _authorised(self) -> bool:
        if self.headers.get("X-API-Key") == API_KEY:
            return True
        self._send(401, {"error": "unauthorized", "detail": "missing or invalid X-API-Key"})
        return False

    def _chaos(self) -> bool:
        """Apply latency / random failures. Returns True if a failure was sent."""
        if STATE["latency"]:
            time.sleep(STATE["latency"])
        if STATE["fail_rate"] and random.random() < STATE["fail_rate"]:
            self._send(503, {"error": "service_unavailable", "detail": "chaos mode"})
            return True
        return False

    def log_message(self, fmt, *args):  # quieter, single-line access log
        print(f"[mock-api] {self.address_string()} {fmt % args}")

    # ---------- routes ----------
    def do_GET(self):
        url = urlparse(self.path)
        path = url.path.rstrip("/") or "/"
        if path == "/health":
            return self._send(200, {"status": "ok", "time": datetime.now(timezone.utc).isoformat()})
        if not self._authorised() or self._chaos():
            return
        if path == "/products":
            qs = parse_qs(url.query)
            try:
                page = int(qs.get("page", ["1"])[0])
                size = int(qs.get("page_size", ["10"])[0])
                if page < 1 or not 1 <= size <= 50:
                    raise ValueError
            except ValueError:
                return self._send(400, {"error": "bad_request", "detail": "page>=1, 1<=page_size<=50"})
            start = (page - 1) * size
            items = PRODUCTS[start:start + size]
            return self._send(200, {
                "items": items, "page": page, "page_size": size,
                "total": len(PRODUCTS), "has_next": start + size < len(PRODUCTS),
            })
        m = re.fullmatch(r"/products/(\d+)", path)
        if m:
            pid = int(m.group(1))
            for p in PRODUCTS:
                if p["id"] == pid:
                    return self._send(200, p)
            return self._send(404, {"error": "not_found", "detail": f"product {pid} not found"})
        if path == "/inventory":
            return self._send(200, {"items": INVENTORY, "as_of": datetime.now(timezone.utc).isoformat()})
        if path == "/orders":
            with LOCK:
                return self._send(200, {"items": list(STATE["orders"])})
        return self._send(404, {"error": "not_found", "detail": path})

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        if path.startswith("/admin/"):
            body = self._read_json() or {}
            with LOCK:
                if path == "/admin/chaos":
                    STATE["fail_rate"] = float(body.get("fail_rate", 0))
                    STATE["latency"] = float(body.get("latency", 0))
                    return self._send(200, {"fail_rate": STATE["fail_rate"], "latency": STATE["latency"]})
                if path == "/admin/reset":
                    STATE.update(orders=[], fail_rate=0.0, latency=0.0, next_order_id=1)
                    return self._send(200, {"status": "reset"})
            return self._send(404, {"error": "not_found"})
        if not self._authorised() or self._chaos():
            return
        if path == "/orders":
            body = self._read_json()
            if body is None:
                return self._send(400, {"error": "bad_request", "detail": "body must be JSON"})
            sku, qty = body.get("sku"), body.get("quantity")
            errors = []
            if sku not in {p["sku"] for p in PRODUCTS}:
                errors.append(f"unknown sku: {sku!r}")
            if not isinstance(qty, int) or isinstance(qty, bool) or not 1 <= qty <= 500:
                errors.append("quantity must be an integer 1..500")
            if errors:
                return self._send(400, {"error": "validation_failed", "detail": errors})
            with LOCK:
                order = {"order_id": STATE["next_order_id"], "sku": sku, "quantity": qty,
                         "status": "created", "created_at": datetime.now(timezone.utc).isoformat()}
                STATE["next_order_id"] += 1
                STATE["orders"].append(order)
            return self._send(201, order)
        return self._send(404, {"error": "not_found", "detail": path})


def make_server(host: str = "127.0.0.1", port: int = 8000) -> ThreadingHTTPServer:
    """Create (but do not start) a server. port=0 picks a free port -- used by tests."""
    return ThreadingHTTPServer((host, port), Handler)


def main() -> None:
    ap = argparse.ArgumentParser(description="NovaRetail offline mock API")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--fail-rate", type=float, default=0.0, help="0..1 share of calls that return 503")
    ap.add_argument("--latency", type=float, default=0.0, help="seconds to sleep per call")
    args = ap.parse_args()
    STATE["fail_rate"], STATE["latency"] = args.fail_rate, args.latency
    srv = make_server(args.host, args.port)
    print(f"NovaRetail mock API on http://{args.host}:{args.port}  (Ctrl+C to stop)")
    print(f"Lab API key: {API_KEY}   fail_rate={args.fail_rate}  latency={args.latency}s")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping mock API")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
