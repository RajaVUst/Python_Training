# NovaRetail Backend Automation Toolkit

Capstone project for the **Python Automation** course (8 days x 2 hours).
It pulls product and stock data from the NovaRetail API, validates it, builds an
inventory report (CSV + JSON), flags low-stock items, and can plan or place
restock orders. Everything runs **offline** against a local mock API.

## Architecture

```
            ┌────────────── novaretail CLI (cli.py) ──────────────┐
            │  health | report | restock      exit codes 0/1/2/3  │
            └───────────────┬────────────────────────────────────┘
                            │
                     workflow.py  (main flow + alternate flows)
          ┌─────────────────┼──────────────────┬───────────────┐
    api_client.py      transform.py        file_ops.py     logging_setup.py
    (requests,         (pure functions,    (CSV/JSON,      (console + rotating
     retries,           joins, summaries)   atomic writes,  file, redaction)
     timeouts)                              snapshots)
          │                 ▲
          ▼                 │
   mock_api/server.py   models.py (validated dataclasses)   config.py (.env / env vars)
```

| Flow | What happens |
|---|---|
| **Main** `report` | GET /products (paginated) + GET /inventory -> validate -> join -> low stock + category summary -> `output/reports/*.csv/json` + snapshot |
| **Alternate 1** API down | retries with backoff, then uses the latest snapshot; report marked `"source": "cache"` |
| **Alternate 2** `restock` | plans orders for low-stock SKUs; dry-run by default, `--execute` POSTs them; one failed line does not stop the batch |

## Quick start

| Step | Windows (PowerShell) | Linux / macOS (bash) |
|---|---|---|
| Create venv | `py -3.12 -m venv .venv` | `python3 -m venv .venv` |
| Activate | `.\.venv\Scripts\Activate.ps1` | `source .venv/bin/activate` |
| Install | `pip install -e ".[dev]"` | `pip install -e ".[dev]"` |
| Config | `Copy-Item .env.example .env` | `cp .env.example .env` |
| Start API (terminal 2) | `python mock_api\server.py` | `python mock_api/server.py` |
| Check setup | `python examples\day1_env_check.py` | `python examples/day1_env_check.py` |
| Run report | `novaretail report` | `novaretail report` |
| Tests | `pytest` | `pytest` |

If `Activate.ps1` is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

## Commands

```
novaretail health                 # is the API up?
novaretail report                 # main workflow
novaretail report --no-cache      # fail instead of using the snapshot
novaretail restock                # dry-run plan
novaretail restock --execute      # place orders
novaretail -v report              # DEBUG logs
python -m novaretail report       # same, without the console script
```

Exit codes: `0` ok · `1` run failed · `2` configuration error · `3` authentication error.

## Configuration (.env)

| Variable | Default | Meaning |
|---|---|---|
| `NOVA_API_BASE_URL` | `http://127.0.0.1:8000` | API root |
| `NOVA_API_KEY` | – (required) | sent as `X-API-Key`; never logged |
| `NOVA_TIMEOUT` | `5` | seconds per request |
| `NOVA_MAX_RETRIES` | `3` | retries for network errors / 429 / 5xx |
| `NOVA_BACKOFF` | `0.5` | first backoff delay, doubles each retry |
| `NOVA_OUTPUT_DIR` / `NOVA_LOG_DIR` | `output` / `logs` | where files go |
| `NOVA_LOG_LEVEL` | `INFO` | DEBUG/INFO/WARNING/ERROR |

## Folder layout

```
mock_api/          offline API (stdlib only) with chaos mode
src/novaretail/    the reusable package
tests/             pytest suite (unit + integration against the mock API)
examples/          one teaching script per day (day1 ... day8)
scheduling/        cron + Windows Task Scheduler wrappers
docs/              runbook, risk register, backlog, evidence checklist
output/ logs/      generated at run time (git-ignored)
evidence/          created by examples/day8_collect_evidence.py
```

## Day-wise examples

| Day | File | Topic |
|---|---|---|
| 1 | `examples/day1_env_check.py` | Environment checks + evidence JSON |
| 2 | `examples/day2_functions_data.py` | Functions, data structures, dataclasses, generators |
| 3 | `examples/day3_file_api_basics.py` | pathlib, CSV/JSON, requests GET/POST, pagination |
| 4 | `examples/day4_errors_logging.py` | try/except/else/finally, custom exceptions, retry, logging |
| 5 | `examples/day5_use_toolkit.py` + `src/novaretail/` | Packages and reusable modules |
| 6 | `examples/day6_pytest_basics/` + `tests/` | pytest, fixtures, parametrize, mocks |
| 7 | `examples/day7_scheduler_loop.py` + `scheduling/` | Scheduling, locks, packaging |
| 8 | `examples/day8_collect_evidence.py` | Full demo + evidence package |

## Packaging

```
pip install build
python -m build              # -> dist/novaretail_toolkit-1.0.0-py3-none-any.whl
pip install dist/novaretail_toolkit-1.0.0-py3-none-any.whl
```

See `docs/RUNBOOK.md` for operations and troubleshooting, `docs/RISK_REGISTER.md`
for risks, and `docs/BACKLOG.md` for limitations and next steps.

## Assumptions and lab constraints

* Python 3.10+; only `requests` is needed at run time.
* The mock API key `nova-lab-key-123` is a public lab value for a local server only.
* Mock data is deterministic (seeded) so every learner gets the same numbers: 24 products, 7 low stock.
* Orders are kept in memory by the mock API and reset when it restarts.
