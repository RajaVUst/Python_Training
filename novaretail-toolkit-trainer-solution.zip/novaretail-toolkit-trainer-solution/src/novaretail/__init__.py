"""NovaRetail backend automation toolkit."""

__version__ = "1.0.0"

from .config import Settings  # noqa: E402  (re-export the public API)
from .exceptions import NovaError  # noqa: E402

__all__ = ["Settings", "NovaError", "__version__"]
