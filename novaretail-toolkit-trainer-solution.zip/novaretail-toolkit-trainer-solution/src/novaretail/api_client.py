"""HTTP client for the NovaRetail API.

Key ideas (Day 3 + Day 4):
  * One requests.Session -> connection reuse + shared headers.
  * Always set a timeout. A request without a timeout can hang forever.
  * Retry only what is retryable: connection errors, timeouts, 429 and 5xx.
    Never retry 400/401/404 -- the same request will fail the same way.
  * Exponential backoff with jitter: 0.5s, 1s, 2s ... (+ small random part).
  * Translate low-level errors into our own exception types.
"""
from __future__ import annotations

import logging
import random
import time
from collections.abc import Iterator

import requests

from .config import Settings
from .exceptions import ApiAuthError, ApiError, ApiUnavailableError, DataValidationError
from .models import Product, StockLevel

log = logging.getLogger(__name__)

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class NovaApiClient:
    def __init__(self, settings: Settings, session: requests.Session | None = None):
        self.settings = settings
        self.session = session or requests.Session()
        self.session.headers.update({
            "X-API-Key": settings.api_key,
            "Accept": "application/json",
            "User-Agent": "novaretail-toolkit/1.0",
        })

    # context-manager support:  with NovaApiClient(s) as client: ...
    def __enter__(self) -> NovaApiClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self.session.close()

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.settings.api_base_url}{path}"
        attempts = self.settings.max_retries + 1
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                resp = self.session.request(method, url, timeout=self.settings.timeout, **kwargs)
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = exc
                log.warning("%s %s failed (attempt %d/%d): %s", method, path, attempt, attempts, type(exc).__name__)
            else:
                if resp.status_code in (401, 403):
                    raise ApiAuthError(f"{method} {path} -> {resp.status_code}: check NOVA_API_KEY", resp.status_code)
                if resp.status_code in RETRYABLE_STATUS:
                    last_error = ApiError(f"{resp.status_code}", resp.status_code)
                    log.warning("%s %s -> %d (attempt %d/%d)", method, path, resp.status_code, attempt, attempts)
                elif resp.status_code >= 400:
                    raise ApiError(f"{method} {path} -> {resp.status_code}: {resp.text[:200]}", resp.status_code)
                else:
                    log.debug("%s %s -> %d in %.0f ms", method, path, resp.status_code, resp.elapsed.total_seconds() * 1000)
                    try:
                        return resp.json()
                    except ValueError as exc:
                        raise DataValidationError(f"{method} {path}: response is not JSON") from exc
            if attempt < attempts:
                delay = self.settings.backoff * (2 ** (attempt - 1)) + random.uniform(0, 0.1)
                time.sleep(delay)
        raise ApiUnavailableError(f"{method} {path} failed after {attempts} attempts: {last_error}",
                                  getattr(last_error, "status", None))

    # ---------- public API ----------
    def health(self) -> dict:
        return self._request("GET", "/health")

    def iter_products(self, page_size: int = 10) -> Iterator[Product]:
        """Generator that walks every page. Memory stays flat even for huge catalogues."""
        page = 1
        while True:
            data = self._request("GET", "/products", params={"page": page, "page_size": page_size})
            for item in data.get("items", []):
                yield Product.from_dict(item)
            if not data.get("has_next"):
                break
            page += 1

    def get_products(self, page_size: int = 10) -> list[Product]:
        return list(self.iter_products(page_size))

    def get_inventory(self) -> list[StockLevel]:
        data = self._request("GET", "/inventory")
        return [StockLevel.from_dict(i) for i in data.get("items", [])]

    def create_order(self, sku: str, quantity: int) -> dict:
        return self._request("POST", "/orders", json={"sku": sku, "quantity": quantity})
