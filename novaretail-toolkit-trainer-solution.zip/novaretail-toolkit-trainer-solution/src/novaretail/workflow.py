"""Business workflows -- the capstone's "main flow" and "alternate flow".

run_report  (happy path)  : API -> validate -> join -> analyse -> CSV + JSON report
            (alternate)   : API down after retries -> use last good snapshot, flag it
run_restock (alternate 2) : plan orders for low stock; dry-run by default, --execute to POST
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .api_client import NovaApiClient
from .config import Settings
from .exceptions import ApiError, ApiUnavailableError, NovaError
from .file_ops import cleanup_old_files, latest_file, read_json, timestamped_path, write_csv, write_json
from .models import Product, StockLevel
from .transform import find_low_stock, join_inventory, plan_restock, summarize_by_category, total_stock_value

log = logging.getLogger(__name__)

REPORT_FIELDS = ["sku", "name", "category", "price", "on_hand", "reorder_level", "stock_value", "is_low_stock"]


@dataclass
class ReportResult:
    source: str                      # "live" or "cache"
    products: int
    low_stock: int
    total_value: float
    csv_path: Path
    json_path: Path
    missing_skus: list[str] = field(default_factory=list)
    duration_s: float = 0.0


def _fetch_live(client: NovaApiClient, settings: Settings) -> tuple[list[Product], list[StockLevel]]:
    products = client.get_products()
    stock = client.get_inventory()
    snapshot = {
        "taken_at": datetime.now().isoformat(timespec="seconds"),
        "products": [p.__dict__ for p in products],
        "inventory": [s.__dict__ for s in stock],
    }
    path = write_json(snapshot, timestamped_path(settings.output_dir / "snapshots", "snapshot", ".json"))
    log.info("Saved snapshot %s", path)
    cleanup_old_files(settings.output_dir / "snapshots", "snapshot_*.json", keep=5)
    return products, stock


def _fetch_cache(settings: Settings) -> tuple[list[Product], list[StockLevel], str]:
    snap_path = latest_file(settings.output_dir / "snapshots", "snapshot_*.json")
    if snap_path is None:
        raise NovaError("API unavailable and no cached snapshot exists -- cannot produce a report")
    data = read_json(snap_path)
    products = [Product.from_dict(p) for p in data["products"]]
    stock = [StockLevel.from_dict(s) for s in data["inventory"]]
    return products, stock, data.get("taken_at", "unknown")


def run_report(settings: Settings, client: NovaApiClient | None = None, allow_cache: bool = True) -> ReportResult:
    started = time.perf_counter()
    own_client = client is None
    client = client or NovaApiClient(settings)
    source, cache_time = "live", None
    try:
        products, stock = _fetch_live(client, settings)
    except ApiUnavailableError as exc:
        if not allow_cache:
            raise
        log.warning("Live fetch failed (%s). Falling back to cached snapshot.", exc)
        products, stock, cache_time = _fetch_cache(settings)
        source = "cache"
    finally:
        if own_client:
            client.close()

    rows, missing = join_inventory(products, stock)
    if missing:
        log.warning("%d product(s) have no stock record: %s", len(missing), ", ".join(missing))
    low = find_low_stock(rows)
    summary = summarize_by_category(rows)
    total = total_stock_value(rows)

    reports = settings.output_dir / "reports"
    csv_path = write_csv([r.to_dict() for r in rows], timestamped_path(reports, "inventory_report", ".csv"), REPORT_FIELDS)
    json_path = write_json({
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "source": source,
        "cache_taken_at": cache_time,
        "totals": {"products": len(rows), "low_stock": len(low), "stock_value": total},
        "by_category": summary,
        "low_stock_items": [r.to_dict() for r in low],
        "missing_skus": missing,
    }, timestamped_path(reports, "inventory_summary", ".json"))
    cleanup_old_files(reports, "inventory_*", keep=20)

    result = ReportResult(source, len(rows), len(low), total, csv_path, json_path, missing,
                          round(time.perf_counter() - started, 3))
    log.info("Report done: source=%s products=%d low_stock=%d value=%.2f in %.2fs",
             result.source, result.products, result.low_stock, result.total_value, result.duration_s)
    return result


def run_restock(settings: Settings, client: NovaApiClient | None = None,
                execute: bool = False, cover_factor: int = 2) -> dict:
    own_client = client is None
    client = client or NovaApiClient(settings)
    try:
        rows, _ = join_inventory(client.get_products(), client.get_inventory())
        plan = plan_restock(rows, cover_factor=cover_factor)
        results = []
        for line in plan:
            if not execute:
                results.append({**line, "status": "planned (dry-run)"})
                continue
            try:
                order = client.create_order(line["sku"], line["quantity"])
                results.append({**line, "status": "created", "order_id": order["order_id"]})
            except ApiError as exc:            # one bad line must not stop the batch
                log.error("Order failed for %s: %s", line["sku"], exc)
                results.append({**line, "status": f"failed: {exc}"})
    finally:
        if own_client:
            client.close()

    path = write_csv(results, timestamped_path(settings.output_dir / "reports", "restock", ".csv"),
                     ["sku", "name", "quantity", "status", "order_id"])
    failed = sum(1 for r in results if r["status"].startswith("failed"))
    log.info("Restock %s: %d line(s), %d failed -> %s", "EXECUTED" if execute else "dry-run", len(results), failed, path)
    return {"lines": len(results), "failed": failed, "path": path, "execute": execute}


# ---------------- Lab 5 reference solution ----------------
def load_watchlist(path: Path) -> dict[str, int]:
    from .exceptions import DataValidationError
    from .file_ops import read_csv
    watch: dict[str, int] = {}
    for i, row in enumerate(read_csv(path, required=["sku", "min_stock"]), start=2):   # line 1 = header
        try:
            watch[row["sku"].strip()] = int(row["min_stock"])
        except ValueError as exc:
            raise DataValidationError(f"{path}:{i}: min_stock must be an integer, got {row['min_stock']!r}") from exc
    return watch


def run_watchlist(settings: Settings, path: Path, client: NovaApiClient | None = None) -> dict:
    from .transform import check_watchlist
    watch = load_watchlist(Path(path))
    own_client = client is None
    client = client or NovaApiClient(settings)
    try:
        rows, _ = join_inventory(client.get_products(), client.get_inventory())
    finally:
        if own_client:
            client.close()
    alerts, unknown = check_watchlist(rows, watch)
    for sku in unknown:
        log.warning("Watchlist SKU not in catalogue: %s", sku)
    out = write_json({"generated_at": datetime.now().isoformat(timespec="seconds"), "watched": len(watch),
                      "alerts": alerts, "unknown_skus": unknown},
                     timestamped_path(settings.output_dir / "reports", "watchlist", ".json"))
    log.info("Watchlist: %d watched, %d alert(s), %d unknown -> %s", len(watch), len(alerts), len(unknown), out)
    return {"watched": len(watch), "alerts": alerts, "unknown": unknown, "path": out}
