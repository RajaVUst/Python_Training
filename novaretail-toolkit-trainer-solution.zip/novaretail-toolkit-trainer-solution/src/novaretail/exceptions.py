"""Exception hierarchy for the toolkit.

One base class lets callers catch "anything from our toolkit" with a single
`except NovaError`, while specific subclasses let them react differently
(e.g. retry on ApiUnavailableError, stop immediately on ApiAuthError).
"""


class NovaError(Exception):
    """Base class for every error raised by the toolkit."""


class ConfigError(NovaError):
    """Missing or invalid configuration (env vars, .env file)."""


class DataValidationError(NovaError):
    """Data from the API or a file does not match the expected shape."""


class ApiError(NovaError):
    """The API answered with an error status."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class ApiAuthError(ApiError):
    """401/403 -- retrying will not help; fix the key."""


class ApiUnavailableError(ApiError):
    """Network failure, timeout or 5xx after all retries were used."""
