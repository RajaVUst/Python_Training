"""Logging: console + rotating file, one format, secrets redacted.

Call setup_logging() ONCE at program start (in the CLI). Library modules only do
    log = logging.getLogger(__name__)
and never configure handlers themselves.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


class RedactFilter(logging.Filter):
    """Replaces any occurrence of the given secrets in log messages with ****."""

    def __init__(self, secrets: list[str]):
        super().__init__()
        self.secrets = [s for s in secrets if s]

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        for s in self.secrets:
            if s in msg:
                msg = msg.replace(s, "****")
                record.msg, record.args = msg, ()
        return True


def setup_logging(level: str = "INFO", log_dir: str | Path | None = "logs",
                  secrets: list[str] | None = None, filename: str = "novaretail.log") -> logging.Logger:
    root = logging.getLogger()
    root.setLevel(level)
    for h in list(root.handlers):          # makes the function safe to call twice (tests, notebooks)
        root.removeHandler(h)
        h.close()
    formatter = logging.Formatter(FORMAT)
    redact = RedactFilter(secrets or [])

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.addFilter(redact)
    root.addHandler(console)

    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            Path(log_dir) / filename, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
        fh.setFormatter(formatter)
        fh.addFilter(redact)
        root.addHandler(fh)

    logging.getLogger("urllib3").setLevel(logging.WARNING)   # keep third-party noise down
    return root
