"""Typed data models. Validate at the boundary, trust inside.

Everything coming from the API or a file passes through `from_dict`, which
raises DataValidationError with a precise message instead of letting a
KeyError surface three functions later.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

from .exceptions import DataValidationError


def _require(data: dict, key: str, typ: type | tuple[type, ...], where: str):
    if key not in data:
        raise DataValidationError(f"{where}: missing field {key!r}")
    value = data[key]
    if isinstance(value, bool) or not isinstance(value, typ):
        raise DataValidationError(f"{where}: field {key!r} has wrong type {type(value).__name__}")
    return value


@dataclass(frozen=True)
class Product:
    id: int
    sku: str
    name: str
    category: str
    price: float

    @classmethod
    def from_dict(cls, data: dict) -> Product:
        where = f"product {data.get('sku', '?')}"
        price = float(_require(data, "price", (int, float), where))
        if price < 0:
            raise DataValidationError(f"{where}: negative price {price}")
        return cls(
            id=_require(data, "id", int, where),
            sku=_require(data, "sku", str, where),
            name=_require(data, "name", str, where),
            category=_require(data, "category", str, where),
            price=price,
        )


@dataclass(frozen=True)
class StockLevel:
    sku: str
    on_hand: int
    reorder_level: int

    @classmethod
    def from_dict(cls, data: dict) -> StockLevel:
        where = f"stock {data.get('sku', '?')}"
        on_hand = _require(data, "on_hand", int, where)
        if on_hand < 0:
            raise DataValidationError(f"{where}: on_hand cannot be negative")
        return cls(
            sku=_require(data, "sku", str, where),
            on_hand=on_hand,
            reorder_level=_require(data, "reorder_level", int, where),
        )


@dataclass(frozen=True)
class InventoryRow:
    """A product joined with its stock level -- the row our reports are built from."""
    sku: str
    name: str
    category: str
    price: float
    on_hand: int
    reorder_level: int

    @property
    def stock_value(self) -> float:
        return round(self.price * self.on_hand, 2)

    @property
    def is_low_stock(self) -> bool:
        return self.on_hand <= self.reorder_level

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(stock_value=self.stock_value, is_low_stock=self.is_low_stock)
        return d
