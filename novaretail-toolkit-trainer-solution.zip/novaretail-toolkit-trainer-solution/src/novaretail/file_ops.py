"""File helpers: CSV/JSON with pathlib, UTF-8 and atomic writes.

Atomic write = write to a temp file in the same folder, then os.replace().
If the script crashes halfway, the old report stays intact instead of a
half-written file that the next job would happily read.
"""
from __future__ import annotations

import csv
import io
import json
import os
import tempfile
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path

from .exceptions import DataValidationError


def timestamped_path(folder: str | Path, prefix: str, suffix: str, now: datetime | None = None) -> Path:
    """output/inventory_report_20261005_153900.csv"""
    now = now or datetime.now()
    return Path(folder) / f"{prefix}_{now:%Y%m%d_%H%M%S}{suffix}"


def _atomic_write_text(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
    return path


def write_json(data, path: str | Path) -> Path:
    return _atomic_write_text(Path(path), json.dumps(data, indent=2, ensure_ascii=False, default=str))


def read_json(path: str | Path):
    p = Path(path)
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise
    except json.JSONDecodeError as exc:
        raise DataValidationError(f"{p} is not valid JSON (line {exc.lineno}): {exc.msg}") from exc


def write_csv(rows: Iterable[dict], path: str | Path, fieldnames: list[str] | None = None) -> Path:
    rows = list(rows)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return _atomic_write_text(Path(path), buf.getvalue())


def read_csv(path: str | Path, required: Iterable[str] = ()) -> list[dict]:
    p = Path(path)
    with p.open(encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        missing = set(required) - set(reader.fieldnames or [])
        if missing:
            raise DataValidationError(f"{p}: missing columns {sorted(missing)}")
        return list(reader)


def latest_file(folder: str | Path, pattern: str) -> Path | None:
    files = sorted(Path(folder).glob(pattern), key=lambda f: f.stat().st_mtime)
    return files[-1] if files else None


def cleanup_old_files(folder: str | Path, pattern: str, keep: int = 10) -> list[Path]:
    """Keep the newest `keep` files matching pattern; delete the rest. Returns deleted paths."""
    files = sorted(Path(folder).glob(pattern), key=lambda f: f.stat().st_mtime, reverse=True)
    removed = files[keep:]
    for f in removed:
        f.unlink(missing_ok=True)
    return removed
