"""Configuration: read settings from environment variables (and an optional .env file).

Rules we follow:
  * No secrets in code or in git. The key comes from NOVA_API_KEY.
  * Fail fast with a clear message when something required is missing.
  * Never print the full key -- use Settings.masked_key in logs.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from .exceptions import ConfigError


def load_dotenv(path: str | Path = ".env") -> None:
    """Tiny .env loader (no third-party package needed).

    Real environment variables win over values in the file (setdefault).
    """
    p = Path(path)
    if not p.is_file():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw in (None, ""):
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be a number, got {raw!r}") from exc


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw in (None, ""):
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer, got {raw!r}") from exc


@dataclass(frozen=True)
class Settings:
    api_base_url: str
    api_key: str = field(repr=False)          # repr=False keeps the key out of print()/logs
    timeout: float = 5.0
    max_retries: int = 3
    backoff: float = 0.5
    output_dir: Path = Path("output")
    log_dir: Path = Path("logs")
    log_level: str = "INFO"

    @property
    def masked_key(self) -> str:
        return "****" + self.api_key[-4:] if len(self.api_key) > 4 else "****"

    @classmethod
    def from_env(cls, env_file: str | Path | None = ".env") -> Settings:
        if env_file:
            load_dotenv(env_file)
        key = os.getenv("NOVA_API_KEY", "").strip()
        if not key:
            raise ConfigError("NOVA_API_KEY is not set. Copy .env.example to .env and fill it in.")
        base = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
        if not base.startswith(("http://", "https://")):
            raise ConfigError(f"NOVA_API_BASE_URL must start with http:// or https://, got {base!r}")
        level = os.getenv("NOVA_LOG_LEVEL", "INFO").upper()
        if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ConfigError(f"NOVA_LOG_LEVEL invalid: {level!r}")
        settings = cls(
            api_base_url=base,
            api_key=key,
            timeout=_env_float("NOVA_TIMEOUT", 5.0),
            max_retries=_env_int("NOVA_MAX_RETRIES", 3),
            backoff=_env_float("NOVA_BACKOFF", 0.5),
            output_dir=Path(os.getenv("NOVA_OUTPUT_DIR", "output")),
            log_dir=Path(os.getenv("NOVA_LOG_DIR", "logs")),
            log_level=level,
        )
        if settings.timeout <= 0 or settings.max_retries < 0:
            raise ConfigError("NOVA_TIMEOUT must be > 0 and NOVA_MAX_RETRIES >= 0")
        return settings
