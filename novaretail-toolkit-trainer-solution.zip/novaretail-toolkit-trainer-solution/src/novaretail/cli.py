"""Command-line entry point.

    novaretail health
    novaretail report [--no-cache]
    novaretail restock [--execute] [--cover 2]

(or: python -m novaretail report)

Exit codes -- schedulers and CI read these:
    0 success   1 runtime/API failure   2 configuration error   3 auth error
"""
from __future__ import annotations

import argparse
import logging
import sys

from . import __version__
from .api_client import NovaApiClient
from .config import Settings
from .exceptions import ApiAuthError, ConfigError, NovaError
from .logging_setup import setup_logging
from .workflow import run_report, run_restock, run_watchlist

log = logging.getLogger("novaretail.cli")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="novaretail", description="NovaRetail backend automation toolkit")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument("--env-file", default=".env", help="path to .env file (default: .env)")
    p.add_argument("-v", "--verbose", action="store_true", help="DEBUG logging")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("health", help="check the API is reachable")
    r = sub.add_parser("report", help="generate the inventory report")
    r.add_argument("--no-cache", action="store_true", help="fail instead of falling back to the last snapshot")
    s = sub.add_parser("restock", help="plan (or place) restock orders for low-stock items")
    s.add_argument("--execute", action="store_true", help="actually POST orders (default is dry-run)")
    s.add_argument("--cover", type=int, default=2, help="target stock = cover x reorder level")
    w = sub.add_parser("watchlist", help="alert on watched SKUs below their minimum stock")
    w.add_argument("--file", required=True, help="CSV with columns sku,min_stock")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        settings = Settings.from_env(args.env_file)
    except ConfigError as exc:
        print(f"CONFIG ERROR: {exc}", file=sys.stderr)
        return 2
    setup_logging("DEBUG" if args.verbose else settings.log_level, settings.log_dir, secrets=[settings.api_key])
    log.info("novaretail %s | command=%s | api=%s | key=%s",
             __version__, args.command, settings.api_base_url, settings.masked_key)
    try:
        if args.command == "health":
            with NovaApiClient(settings) as client:
                log.info("API health: %s", client.health())
        elif args.command == "report":
            res = run_report(settings, allow_cache=not args.no_cache)
            print(f"Report ({res.source}): {res.products} products, {res.low_stock} low stock, "
                  f"value {res.total_value:,.2f}\n  CSV : {res.csv_path}\n  JSON: {res.json_path}")
        elif args.command == "restock":
            res = run_restock(settings, execute=args.execute, cover_factor=args.cover)
            print(f"Restock ({'executed' if res['execute'] else 'dry-run'}): {res['lines']} lines, "
                  f"{res['failed']} failed -> {res['path']}")
            if res["failed"]:
                return 1
        elif args.command == "watchlist":
            res = run_watchlist(settings, args.file)
            print(f"Watchlist: {res['watched']} watched, {len(res['alerts'])} alert(s), "
                  f"{len(res['unknown'])} unknown -> {res['path']}")
    except ApiAuthError as exc:
        log.error("Authentication failed: %s", exc)
        return 3
    except NovaError as exc:
        log.error("Run failed: %s", exc)
        return 1
    except Exception:                       # last-resort net: log the traceback, still exit non-zero
        log.exception("Unexpected error")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
