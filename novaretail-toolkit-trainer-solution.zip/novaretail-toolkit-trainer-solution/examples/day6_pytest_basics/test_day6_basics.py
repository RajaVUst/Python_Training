"""Day 6 -- pytest from zero to mocks, on tiny examples.

Run just this file:   pytest examples/day6_pytest_basics -v
(The real project tests live in tests/ -- run them with:  pytest)
"""
import json
from unittest.mock import MagicMock, patch

import pytest


# ---------------- code under test (normally imported from your package) ----------------
def apply_discount(price: float, pct: float) -> float:
    if not 0 <= pct <= 100:
        raise ValueError("pct must be 0..100")
    return round(price * (1 - pct / 100), 2)


def load_config(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def fetch_price(session, sku: str) -> float:
    resp = session.get(f"http://api/prices/{sku}", timeout=5)
    resp.raise_for_status()
    return resp.json()["price"]


# ---------------- 1. plain assert ----------------
def test_discount_basic():
    assert apply_discount(1000, 10) == 900


# ---------------- 2. expecting an exception ----------------
def test_discount_rejects_bad_pct():
    with pytest.raises(ValueError, match="0..100"):
        apply_discount(100, 150)


# ---------------- 3. parametrize: one test, many cases ----------------
@pytest.mark.parametrize("price, pct, expected", [
    (100, 0, 100),
    (100, 100, 0),
    (799, 15, 679.15),
    (0.1, 50, 0.05),
])
def test_discount_cases(price, pct, expected):
    assert apply_discount(price, pct) == pytest.approx(expected)


# ---------------- 4. fixtures: reusable setup ----------------
@pytest.fixture
def config_file(tmp_path):                     # tmp_path is a built-in fixture
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"retries": 3}))
    return p


def test_load_config(config_file):
    assert load_config(config_file)["retries"] == 3


def test_load_config_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "nope.json")


# ---------------- 5. monkeypatch: control environment ----------------
def read_mode():
    import os
    return os.getenv("APP_MODE", "dev")


def test_env_default(monkeypatch):
    monkeypatch.delenv("APP_MODE", raising=False)
    assert read_mode() == "dev"


def test_env_override(monkeypatch):
    monkeypatch.setenv("APP_MODE", "prod")
    assert read_mode() == "prod"


# ---------------- 6. mocks: fake the network ----------------
def test_fetch_price_with_mock():
    session = MagicMock()
    session.get.return_value.json.return_value = {"price": 799.0}

    assert fetch_price(session, "NR-1001") == 799.0
    session.get.assert_called_once_with("http://api/prices/NR-1001", timeout=5)


def test_fetch_price_http_error():
    session = MagicMock()
    session.get.return_value.raise_for_status.side_effect = RuntimeError("503")
    with pytest.raises(RuntimeError):
        fetch_price(session, "NR-1001")


# ---------------- 7. patch: replace something inside a module ----------------
def test_patch_time():
    import time
    with patch("time.time", return_value=1_700_000_000):
        assert time.time() == 1_700_000_000


# ---------------- 8. capsys: check printed output ----------------
def greet(name):
    print(f"Hello {name}")


def test_greet(capsys):
    greet("NovaRetail")
    assert capsys.readouterr().out == "Hello NovaRetail\n"
