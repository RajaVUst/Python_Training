"""Day 5 -- Using the toolkit as reusable modules.

The scripts from Days 2-4 have been refactored into the package src/novaretail/:
    config.py      settings from env        exceptions.py  error hierarchy
    models.py      validated dataclasses     transform.py   pure business logic
    file_ops.py    CSV/JSON, atomic writes   api_client.py  HTTP + retries
    logging_setup  one logging config        workflow.py    orchestration
    cli.py         command-line entry point

Install once in editable mode (code changes apply instantly):
    pip install -e .
Then run:
    python examples/day5_use_toolkit.py
"""
from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.logging_setup import setup_logging
from novaretail.transform import find_low_stock, join_inventory, summarize_by_category

settings = Settings.from_env()                  # reads .env
setup_logging(settings.log_level, log_dir=None, secrets=[settings.api_key])
print("Settings:", settings)                    # note: api_key is hidden by repr=False

with NovaApiClient(settings) as client:         # same client the CLI uses
    rows, missing = join_inventory(client.get_products(), client.get_inventory())

print(f"\n{len(rows)} rows, missing stock for: {missing or 'none'}")
for cat, s in summarize_by_category(rows).items():
    print(f"  {cat:<12} products={s['products']:>2}  units={s['units']:>4}  value={s['stock_value']:>12,.2f}")
print("\nTop 3 urgent restocks:")
for r in find_low_stock(rows)[:3]:
    print(f"  {r.sku} {r.name:<22} on_hand={r.on_hand:>2} reorder_level={r.reorder_level}")
