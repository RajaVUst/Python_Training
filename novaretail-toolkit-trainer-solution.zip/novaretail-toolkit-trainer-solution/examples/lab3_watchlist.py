"""Lab 3 reference solution: watchlist check with plain requests + csv/json."""
import csv
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")
API_KEY = os.getenv("NOVA_API_KEY")
INPUT = Path("data/input/watchlist.csv")
OUT_DIR = Path("output")

if not API_KEY:
    sys.exit("NOVA_API_KEY is not set")

started = time.perf_counter()
with INPUT.open(newline="", encoding="utf-8") as fh:
    watch = {row["sku"].strip(): int(row["min_stock"]) for row in csv.DictReader(fh)}

with requests.Session() as session:
    session.headers.update({"X-API-Key": API_KEY, "Accept": "application/json"})
    resp = session.get(f"{BASE_URL}/inventory", timeout=5)
    resp.raise_for_status()
    stock = {item["sku"]: item["on_hand"] for item in resp.json()["items"]}

alerts = [{"sku": sku, "on_hand": stock[sku], "min_stock": m, "short_by": m - stock[sku]}
          for sku, m in watch.items() if sku in stock and stock[sku] < m]
unknown = sorted(sku for sku in watch if sku not in stock)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
OUT_DIR.mkdir(exist_ok=True)
csv_path = OUT_DIR / f"watchlist_{stamp}.csv"
with csv_path.open("w", newline="", encoding="utf-8") as fh:
    writer = csv.DictWriter(fh, fieldnames=["sku", "on_hand", "min_stock", "short_by"])
    writer.writeheader()
    writer.writerows(alerts)
summary = {"run_at": stamp, "watched": len(watch), "alerts": len(alerts), "unknown_skus": unknown,
           "seconds": round(time.perf_counter() - started, 3)}
(OUT_DIR / f"watchlist_{stamp}.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
