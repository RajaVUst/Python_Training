"""Day 4 -- Error handling and logging patterns.

Run:  python examples/day4_errors_logging.py
Optional: start the mock API in chaos mode to see real retries:
      python mock_api/server.py --fail-rate 0.5
Log output goes to the console AND work/day4/app.log.
"""
from __future__ import annotations

import functools
import json
import logging
import random
import time
from contextlib import contextmanager
from pathlib import Path

import requests

# ------------------------------------------------------------- 1. logging configuration
LOG_DIR = Path("work") / "day4"
LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s | %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler(LOG_DIR / "app.log", encoding="utf-8")],
)
log = logging.getLogger("day4")
logging.getLogger("urllib3").setLevel(logging.WARNING)

log.debug("detail for developers (hidden at INFO level)")
log.info("normal progress message")
log.warning("something unexpected but we continue")
log.error("an operation failed")
log.critical("the program cannot continue")

# ------------------------------------------------------------- 2. try / except / else / finally
print("\n--- 2. try/except/else/finally")


def parse_quantity(raw: str) -> int | None:
    try:
        qty = int(raw)
    except ValueError:
        log.warning("Not a number: %r", raw)            # %-style: formatted only if the level is enabled
        return None
    else:                                               # runs only when no exception happened
        log.debug("Parsed %r -> %d", raw, qty)
        return qty
    finally:                                            # always runs (cleanup, metrics)
        log.debug("parse_quantity finished for %r", raw)


print([parse_quantity(x) for x in ["5", "five", "12"]])

# ------------------------------------------------------------- 3. custom exceptions + raise from
print("\n--- 3. custom exceptions and chaining")


class OrderError(Exception):
    """Base for order problems."""


class InvalidOrder(OrderError):
    pass


def load_order(text: str) -> dict:
    try:
        order = json.loads(text)
    except json.JSONDecodeError as exc:
        raise InvalidOrder(f"order is not valid JSON: {exc.msg}") from exc   # keeps the original cause
    if order.get("quantity", 0) <= 0:
        raise InvalidOrder("quantity must be positive")
    return order


for payload in ['{"sku": "NR-1001", "quantity": 2}', '{"sku": "NR-1001", "quantity": 0}', "{broken"]:
    try:
        print("OK:", load_order(payload))
    except InvalidOrder as e:
        print("Rejected:", e, "| cause:", repr(e.__cause__))

# ------------------------------------------------------------- 4. logging tracebacks
print("\n--- 4. log.exception keeps the traceback")
try:
    {}["missing"]
except KeyError:
    log.exception("Lookup failed")              # ERROR level + full traceback in the log file

# ------------------------------------------------------------- 5. retry decorator
print("\n--- 5. retry decorator with exponential backoff")


def retry(times: int = 3, delay: float = 0.2, exceptions: tuple[type[Exception], ...] = (Exception,)):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(1, times + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    if attempt == times:
                        log.error("%s gave up after %d attempts", func.__name__, times)
                        raise
                    wait = delay * 2 ** (attempt - 1)
                    log.warning("%s failed (%s), retry %d/%d in %.1fs", func.__name__, exc, attempt, times, wait)
                    time.sleep(wait)
        return wrapper
    return decorator


random.seed(7)


@retry(times=4, exceptions=(ConnectionError,))
def flaky_call() -> str:
    if random.random() < 0.6:
        raise ConnectionError("network blip")
    return "data"


print("flaky_call ->", flaky_call())

# ------------------------------------------------------------- 6. real HTTP errors
print("\n--- 6. classifying requests errors")


@retry(times=3, exceptions=(requests.ConnectionError, requests.Timeout))
def get_inventory(base: str = "http://127.0.0.1:8000") -> dict:
    r = requests.get(f"{base}/inventory", headers={"X-API-Key": "nova-lab-key-123"}, timeout=3)
    r.raise_for_status()
    return r.json()


try:
    print("inventory items:", len(get_inventory()["items"]))
except requests.HTTPError as e:
    log.error("HTTP error %s -- maybe chaos mode is on", e.response.status_code)
except (requests.ConnectionError, requests.Timeout):
    log.error("API not reachable -- is mock_api/server.py running?")

# ------------------------------------------------------------- 7. context manager for timing/cleanup
print("\n--- 7. context manager")


@contextmanager
def timed(step: str):
    start = time.perf_counter()
    log.info("START %s", step)
    try:
        yield
    except Exception:
        log.exception("FAILED %s", step)
        raise
    finally:
        log.info("END %s (%.3fs)", step, time.perf_counter() - start)


with timed("build report"):
    time.sleep(0.1)

print(f"\nOpen {LOG_DIR / 'app.log'} to see the persisted log.")
