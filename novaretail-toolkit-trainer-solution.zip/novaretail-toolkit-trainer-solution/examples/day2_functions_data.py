"""Day 2 -- Functions and data structures, using NovaRetail order data.

Run:  python examples/day2_functions_data.py
Each section prints its result so you can follow along.
"""
from __future__ import annotations

from collections import Counter, defaultdict, namedtuple
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field

ORDERS = [
    {"order_id": 101, "store": "BLR-01", "sku": "NR-1001", "qty": 2, "unit_price": 799.0, "status": "paid"},
    {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0, "status": "paid"},
    {"order_id": 103, "store": "BLR-01", "sku": "NR-1011", "qty": 1, "unit_price": 3299.0, "status": "refunded"},
    {"order_id": 104, "store": "HYD-03", "sku": "NR-1001", "qty": 3, "unit_price": 799.0, "status": "paid"},
    {"order_id": 105, "store": "CHN-02", "sku": "NR-1002", "qty": 1, "unit_price": 1899.0, "status": "pending"},
    {"order_id": 106, "store": "BLR-01", "sku": "NR-1007", "qty": 4, "unit_price": 699.0, "status": "paid"},
]


def section(title: str) -> None:
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------- 1. Choosing the structure
section("1. list vs tuple vs set vs dict")
skus_list = [o["sku"] for o in ORDERS]            # ordered, duplicates allowed
skus_set = {o["sku"] for o in ORDERS}             # unique, fast membership test
order_index = {o["order_id"]: o for o in ORDERS}  # key -> value, O(1) lookup
point = ("BLR-01", 12.97, 77.59)                  # fixed record, immutable, hashable
print("list :", skus_list)
print("set  :", sorted(skus_set), "| 'NR-1001' in set ->", "NR-1001" in skus_set)
print("dict :", order_index[104]["store"])
print("tuple:", point, "-> can be a dict key or set member")


# ---------------------------------------------------------------- 2. Functions done right
section("2. Functions: type hints, defaults, keyword-only args, docstrings")


def line_total(qty: int, unit_price: float, *, discount_pct: float = 0.0) -> float:
    """Total for one order line. `*` forces discount_pct to be passed by name."""
    if not 0 <= discount_pct <= 100:
        raise ValueError("discount_pct must be 0..100")
    return round(qty * unit_price * (1 - discount_pct / 100), 2)


print(line_total(2, 799.0))
print(line_total(2, 799.0, discount_pct=10))
# line_total(2, 799.0, 10)  -> TypeError: keyword-only, prevents silent mix-ups


section("3. The mutable default argument trap")


def add_tag_bad(tag: str, tags: list[str] = []) -> list[str]:   # noqa: B006 -- deliberate bug
    tags.append(tag)
    return tags


def add_tag_good(tag: str, tags: list[str] | None = None) -> list[str]:
    tags = [] if tags is None else list(tags)
    tags.append(tag)
    return tags


print("bad :", add_tag_bad("a"), add_tag_bad("b"), "<- same list shared between calls!")
print("good:", add_tag_good("a"), add_tag_good("b"))


section("4. *args and **kwargs")


def build_filter(*statuses: str, **conditions) -> callable:
    """Return a predicate: build_filter('paid', store='BLR-01')."""
    def predicate(order: dict) -> bool:
        if statuses and order["status"] not in statuses:
            return False
        return all(order.get(k) == v for k, v in conditions.items())
    return predicate                      # a function returning a function = closure


paid_blr = build_filter("paid", store="BLR-01")
print([o["order_id"] for o in ORDERS if paid_blr(o)])


# ---------------------------------------------------------------- 3. Comprehensions & built-ins
section("5. Comprehensions, sorted(key=), any/all, enumerate")
paid = [o for o in ORDERS if o["status"] == "paid"]
revenue_by_order = {o["order_id"]: line_total(o["qty"], o["unit_price"]) for o in paid}
top = sorted(paid, key=lambda o: o["qty"] * o["unit_price"], reverse=True)[:2]
print("revenue_by_order:", revenue_by_order)
print("top 2 orders    :", [o["order_id"] for o in top])
print("any refunded?   :", any(o["status"] == "refunded" for o in ORDERS))
print("all qty > 0?    :", all(o["qty"] > 0 for o in ORDERS))
for rank, (oid, amount) in enumerate(revenue_by_order.items(), start=1):
    print(f"  #{rank} order {oid}: {amount:,.2f}")


section("6. Grouping: defaultdict and Counter")
revenue_by_store: defaultdict[str, float] = defaultdict(float)
for o in paid:
    revenue_by_store[o["store"]] += line_total(o["qty"], o["unit_price"])
print("revenue by store:", dict(revenue_by_store))
status_counts = Counter(o["status"] for o in ORDERS)
units_by_sku = Counter()
for o in paid:
    units_by_sku[o["sku"]] += o["qty"]
print("status counts   :", status_counts)
print("best seller     :", units_by_sku.most_common(1))


# ---------------------------------------------------------------- 4. Records with structure
section("7. namedtuple vs dataclass")
Store = namedtuple("Store", "code city")
s = Store("BLR-01", "Bengaluru")
print(s.city, "| immutable tuple with names")


@dataclass
class Order:
    order_id: int
    store: str
    sku: str
    qty: int
    unit_price: float
    status: str = "pending"
    tags: list[str] = field(default_factory=list)   # the safe way to default a list

    @property
    def total(self) -> float:
        return line_total(self.qty, self.unit_price)

    def __post_init__(self):
        if self.qty <= 0:
            raise ValueError(f"order {self.order_id}: qty must be positive")


orders = [Order(**o) for o in ORDERS]                    # dict unpacking into a constructor
print(orders[0])
print("total of first order:", orders[0].total)
try:
    Order(999, "X", "Y", qty=0, unit_price=1)
except ValueError as e:
    print("validation:", e)


# ---------------------------------------------------------------- 5. Generators
section("8. Generators: process big data one item at a time")


def read_orders_in_batches(items: Iterable[Order], size: int) -> Iterator[list[Order]]:
    batch: list[Order] = []
    for item in items:
        batch.append(item)
        if len(batch) == size:
            yield batch
            batch = []
    if batch:
        yield batch


for i, batch in enumerate(read_orders_in_batches(orders, 4), start=1):
    print(f"batch {i}: {[o.order_id for o in batch]}")

total_units = sum(o.qty for o in orders)               # generator expression: no list built
print("total units:", total_units)


section("9. Copy vs reference")
original = {"store": "BLR-01", "tags": ["vip"]}
alias = original
shallow = dict(original)
import copy  # noqa: E402

deep = copy.deepcopy(original)
original["tags"].append("bulk")
print("alias  :", alias["tags"], "| shallow:", shallow["tags"], "| deep:", deep["tags"])
