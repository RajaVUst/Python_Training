"""Day 8 -- One command to run the capstone demo and collect the evidence package.

Prerequisites: venv active, `pip install -e .[dev]`, .env present.
The script starts its own mock API on port 8765, so nothing else needs to run.

    python examples/day8_collect_evidence.py

Creates evidence/<timestamp>/ with:
    01_versions.txt        02_project_tree.txt     03_tests.txt (+ coverage if available)
    04_lint.txt            05_happy_path.txt       06_restock_dry_run.txt
    07_failure_api_down_cache.txt                  08_failure_no_cache.txt
    09_failure_bad_key.txt 10_failure_missing_config.txt
    reports/ (copied CSV/JSON)   SUMMARY.md (pass/fail table)
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUT = ROOT / "evidence" / STAMP
PORT = 8765
BASE = f"http://127.0.0.1:{PORT}"
results: list[tuple[str, str, str]] = []      # (step, expected, actual)


def run(name: str, cmd: list[str], expect_code: int, env_extra: dict | None = None) -> int:
    env = {**os.environ, "NOVA_API_BASE_URL": BASE, "NOVA_BACKOFF": "0.1",
           "NOVA_OUTPUT_DIR": str(OUT / "run_output"), "NOVA_LOG_DIR": str(OUT / "logs")}
    env.update(env_extra or {})
    proc = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True)
    (OUT / f"{name}.txt").write_text(
        f"$ {' '.join(cmd)}\n# exit code: {proc.returncode} (expected {expect_code})\n\n"
        f"--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}", encoding="utf-8")
    status = "PASS" if proc.returncode == expect_code else "FAIL"
    results.append((name, f"exit {expect_code}", f"exit {proc.returncode} {status}"))
    print(f"[{status}] {name}")
    return proc.returncode


def chaos(fail_rate: float) -> None:
    requests.post(f"{BASE}/admin/chaos", json={"fail_rate": fail_rate}, timeout=3)


def tree(folder: Path, prefix: str = "") -> list[str]:
    skip = {".venv", "venv", "__pycache__", ".pytest_cache", "evidence", ".git", "work", "output", "logs"}
    lines = []
    items = sorted([p for p in folder.iterdir() if p.name not in skip and not p.name.endswith(".egg-info")],
                   key=lambda p: (p.is_file(), p.name))
    for i, p in enumerate(items):
        last = i == len(items) - 1
        lines.append(f"{prefix}{'└── ' if last else '├── '}{p.name}")
        if p.is_dir():
            lines += tree(p, prefix + ("    " if last else "│   "))
    return lines


def main() -> int:
    OUT.mkdir(parents=True)
    py = sys.executable
    nova = [py, "-m", "novaretail", "--env-file", str(ROOT / ".env")]

    (OUT / "01_versions.txt").write_text(
        f"python {platform.python_version()} ({sys.executable})\nos {platform.platform()}\n"
        + subprocess.run([py, "-m", "pip", "list"], capture_output=True, text=True).stdout)
    (OUT / "02_project_tree.txt").write_text(ROOT.name + "\n" + "\n".join(tree(ROOT)), encoding="utf-8")

    run("03_tests", [py, "-m", "pytest", "-v"], 0)
    if shutil.which("ruff") or subprocess.run([py, "-m", "ruff", "--version"], capture_output=True).returncode == 0:
        run("04_lint", [py, "-m", "ruff", "check", "src", "tests"], 0)

    server = subprocess.Popen([py, "mock_api/server.py", "--port", str(PORT)], cwd=ROOT,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(50):
            try:
                requests.get(f"{BASE}/health", timeout=0.5)
                break
            except requests.ConnectionError:
                time.sleep(0.1)
        run("05_happy_path", nova + ["report"], 0)
        run("06_restock_dry_run", nova + ["restock"], 0)
        chaos(1.0)
        run("07_failure_api_down_cache", nova + ["report"], 0)            # alternate flow: cache
        run("08_failure_no_cache", nova + ["report", "--no-cache"], 1)
        chaos(0.0)
        run("09_failure_bad_key", nova + ["report"], 3, {"NOVA_API_KEY": "wrong-key"})
        run("10_failure_missing_config", [py, "-m", "novaretail", "--env-file", "none.env", "report"], 2,
            {"NOVA_API_KEY": ""})
    finally:
        server.terminate()
        server.wait(timeout=5)

    reports = OUT / "run_output" / "reports"
    if reports.exists():
        shutil.copytree(reports, OUT / "reports")

    lines = [f"# Evidence summary -- {STAMP}", "", "| Step | Expected | Actual |", "|---|---|---|"]
    lines += [f"| {s} | {e} | {a} |" for s, e, a in results]
    failed = [r for r in results if "FAIL" in r[2]]
    lines += ["", f"**{len(results) - len(failed)}/{len(results)} steps as expected.**"]
    (OUT / "SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"\nEvidence package: {OUT}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
