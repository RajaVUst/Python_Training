"""Day 7 -- A tiny in-process scheduler (stdlib only) with an overlap lock.

Use this to understand scheduling concepts. In production prefer the OS
scheduler (cron on Linux/macOS, Task Scheduler on Windows) -- see scheduling/.

Run (Ctrl+C to stop):
    python examples/day7_scheduler_loop.py --every 30 --runs 3
"""
from __future__ import annotations

import argparse
import logging
import os
import subprocess
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
log = logging.getLogger("scheduler")
LOCK = Path("output") / "novaretail.lock"


@contextmanager
def single_instance(lock_path: Path, stale_after: int = 3600):
    """Prevent two runs at once. A lock older than stale_after seconds is treated as left over from a crash."""
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    if lock_path.exists() and time.time() - lock_path.stat().st_mtime < stale_after:
        raise RuntimeError(f"another run holds {lock_path} -- skipping")
    lock_path.write_text(str(os.getpid()))
    try:
        yield
    finally:
        lock_path.unlink(missing_ok=True)


def run_job() -> int:
    """Run the toolkit exactly as a scheduler would: as a separate process, checking the exit code."""
    cmd = [sys.executable, "-m", "novaretail", "report"]
    log.info("Running: %s", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode == 0:
        log.info("Job OK: %s", result.stdout.strip().splitlines()[0] if result.stdout else "")
    else:
        log.error("Job FAILED (exit %d): %s", result.returncode, result.stderr.strip()[-300:])
    return result.returncode


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--every", type=int, default=60, help="seconds between runs")
    ap.add_argument("--runs", type=int, default=0, help="stop after N runs (0 = forever)")
    args = ap.parse_args()

    done = 0
    next_run = datetime.now()
    while True:
        now = datetime.now()
        if now >= next_run:
            try:
                with single_instance(LOCK):
                    run_job()
            except RuntimeError as exc:
                log.warning("%s", exc)
            done += 1
            next_run = now + timedelta(seconds=args.every)   # schedule from start time = no drift
            if args.runs and done >= args.runs:
                break
            log.info("Next run at %s", next_run.strftime("%H:%M:%S"))
        time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.info("Scheduler stopped")
