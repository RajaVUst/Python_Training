"""Day 1 -- Environment check script (produces setup evidence).

Run inside your activated virtual environment:
    python examples/day1_env_check.py

It answers the questions a reviewer asks first:
  * Which Python? Is it >= 3.10?   * Am I inside a venv?
  * Are the required packages installed (and which versions)?
  * Is the mock API reachable?     * Is .env present and the key set?
Results are printed AND saved to evidence/day1_env_report.json.
"""
from __future__ import annotations

import importlib.metadata as md
import json
import os
import platform
import sys
from datetime import datetime
from pathlib import Path

REQUIRED = {"requests": "2.31"}
OPTIONAL = ["pytest", "ruff"]
MIN_PY = (3, 10)


def in_virtualenv() -> bool:
    # In a venv, sys.prefix points to the venv folder; base_prefix to the real install.
    return sys.prefix != getattr(sys, "base_prefix", sys.prefix)


def package_version(name: str) -> str | None:
    try:
        return md.version(name)
    except md.PackageNotFoundError:
        return None


def version_tuple(v: str) -> tuple[int, ...]:
    return tuple(int(p) for p in v.split(".")[:3] if p.isdigit())


def check_api(url: str) -> str:
    try:
        import requests
        r = requests.get(f"{url}/health", timeout=3)
        return f"OK ({r.status_code})"
    except Exception as exc:  # noqa: BLE001 -- an env check must never crash
        return f"NOT REACHABLE ({type(exc).__name__}) -> start it: python mock_api/server.py"


def main() -> int:
    checks: dict[str, dict] = {}

    py_ok = sys.version_info[:2] >= MIN_PY
    checks["python"] = {"ok": py_ok, "value": platform.python_version(), "path": sys.executable}
    checks["virtualenv"] = {"ok": in_virtualenv(), "value": sys.prefix}

    for name, minimum in REQUIRED.items():
        v = package_version(name)
        ok = v is not None and version_tuple(v) >= version_tuple(minimum)
        checks[f"pkg:{name}"] = {"ok": ok, "value": v or "missing", "minimum": minimum}
    for name in OPTIONAL:
        v = package_version(name)
        checks[f"pkg:{name} (optional)"] = {"ok": True, "value": v or "not installed"}

    env_file = Path(".env")
    checks[".env file"] = {"ok": env_file.is_file(), "value": str(env_file.resolve())}
    if env_file.is_file():                       # read .env like the toolkit does; terminal values still win
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    key_set = bool(os.getenv("NOVA_API_KEY")) or (env_file.is_file() and "NOVA_API_KEY=" in env_file.read_text())
    checks["NOVA_API_KEY set"] = {"ok": key_set, "value": "yes" if key_set else "no"}   # never print the key

    api_url = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")
    api_status = check_api(api_url)
    checks["mock API"] = {"ok": api_status.startswith("OK"), "value": f"{api_url} {api_status}"}

    print(f"\nNovaRetail environment check -- {platform.system()} {platform.release()}\n" + "-" * 60)
    for name, c in checks.items():
        print(f"[{'PASS' if c['ok'] else 'FAIL'}] {name:<26} {c['value']}")

    report = {"checked_at": datetime.now().isoformat(timespec="seconds"),
              "os": platform.platform(), "checks": checks}
    out = Path("evidence") / "day1_env_report.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report, indent=2))
    failed = [n for n, c in checks.items() if not c["ok"]]
    print("-" * 60 + f"\nSaved {out}.  {'ALL CHECKS PASSED' if not failed else 'FAILED: ' + ', '.join(failed)}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
