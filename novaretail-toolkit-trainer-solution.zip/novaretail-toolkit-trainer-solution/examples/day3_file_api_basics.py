"""Day 3 -- File and API automation basics (no toolkit imports: plain Python + requests).

Start the mock API first (separate terminal):   python mock_api/server.py
Then run:                                       python examples/day3_file_api_basics.py

Flow: read a CSV of SKUs -> call the API for each product (GET with headers,
params, timeout) -> paginate the catalogue -> place an order (POST JSON) ->
write results to JSON and CSV in work/day3/.
"""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path

import requests

BASE_URL = os.getenv("NOVA_API_BASE_URL", "http://127.0.0.1:8000")
API_KEY = os.getenv("NOVA_API_KEY", "nova-lab-key-123")      # lab default; real code reads env only
WORK = Path("work") / "day3"
HEADERS = {"X-API-Key": API_KEY, "Accept": "application/json"}

# ------------------------------------------------------------- 1. pathlib basics
WORK.mkdir(parents=True, exist_ok=True)                       # works on Windows and Linux
input_csv = WORK / "skus_to_check.csv"                        # the / operator joins paths
print("Working folder:", WORK.resolve())

# ------------------------------------------------------------- 2. write + read CSV
with input_csv.open("w", newline="", encoding="utf-8") as fh:  # newline="" avoids blank rows on Windows
    writer = csv.writer(fh)
    writer.writerow(["product_id", "note"])
    writer.writerows([[1, "mouse"], [7, "rice"], [99, "does not exist"]])

with input_csv.open(newline="", encoding="utf-8") as fh:
    wanted = list(csv.DictReader(fh))
print("Read", len(wanted), "rows:", wanted)

# ------------------------------------------------------------- 3. GET one resource
session = requests.Session()                 # reuse TCP connection + headers
session.headers.update(HEADERS)

found, not_found = [], []
for row in wanted:
    resp = session.get(f"{BASE_URL}/products/{row['product_id']}", timeout=5)   # ALWAYS a timeout
    print(f"GET /products/{row['product_id']} -> {resp.status_code}")
    if resp.status_code == 200:
        found.append(resp.json())
    elif resp.status_code == 404:
        not_found.append(row["product_id"])
    else:
        resp.raise_for_status()               # turn other 4xx/5xx into an exception

# ------------------------------------------------------------- 4. pagination
catalogue, page = [], 1
while True:
    resp = session.get(f"{BASE_URL}/products", params={"page": page, "page_size": 10}, timeout=5)
    resp.raise_for_status()
    data = resp.json()
    catalogue.extend(data["items"])
    print(f"page {page}: {len(data['items'])} items, has_next={data['has_next']}")
    if not data["has_next"]:
        break
    page += 1
print("Catalogue size:", len(catalogue))

# ------------------------------------------------------------- 5. POST JSON
resp = session.post(f"{BASE_URL}/orders", json={"sku": "NR-1001", "quantity": 3}, timeout=5)
print("POST /orders ->", resp.status_code, resp.json())
bad = session.post(f"{BASE_URL}/orders", json={"sku": "NOPE", "quantity": 0}, timeout=5)
print("POST bad order ->", bad.status_code, bad.json()["detail"])

# ------------------------------------------------------------- 6. what a wrong key looks like
r = requests.get(f"{BASE_URL}/inventory", headers={"X-API-Key": "wrong"}, timeout=5)
print("Wrong key ->", r.status_code, r.json())

# ------------------------------------------------------------- 7. save results
(WORK / "found_products.json").write_text(json.dumps(found, indent=2), encoding="utf-8")
with (WORK / "catalogue.csv").open("w", newline="", encoding="utf-8") as fh:
    writer = csv.DictWriter(fh, fieldnames=["id", "sku", "name", "category", "price"])
    writer.writeheader()
    writer.writerows(catalogue)
print("Not found:", not_found)
print("Files written:", sorted(p.name for p in WORK.iterdir()))
session.close()
