#!/usr/bin/env bash
# Wrapper used by cron on Linux/macOS.
# cron runs with a minimal environment: no venv, different working directory,
# almost empty PATH. So this script sets all of that explicitly.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

# Use the venv's python directly -- no need to "activate" in scripts.
PY="$PROJECT_DIR/.venv/bin/python"

mkdir -p logs
status=0
"$PY" -m novaretail report >> logs/cron.log 2>&1 || status=$?   # capture failure without set -e aborting
echo "$(date '+%F %T') report exit=$status" >> logs/cron.log
exit $status
