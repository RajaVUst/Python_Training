# Wrapper used by Windows Task Scheduler.
# Task Scheduler starts in C:\Windows\System32 with no venv, so we set everything explicitly.
$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectDir

$Py = Join-Path $ProjectDir ".venv\Scripts\python.exe"
New-Item -ItemType Directory -Force -Path "logs" | Out-Null

& $Py -m novaretail report *>> "logs\task.log"
$code = $LASTEXITCODE
Add-Content -Path "logs\task.log" -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') report exit=$code"
exit $code
