# Registers a daily 07:30 Task Scheduler job that runs run_report.ps1.
# Run once in PowerShell (as the user who should own the task):
#     powershell -ExecutionPolicy Bypass -File scheduling\register_windows_task.ps1
# Check:   Get-ScheduledTask -TaskName "NovaRetail Daily Report"
# Run now: Start-ScheduledTask -TaskName "NovaRetail Daily Report"
# Remove:  Unregister-ScheduledTask -TaskName "NovaRetail Daily Report" -Confirm:$false

$TaskName = "NovaRetail Daily Report"
$Script   = Join-Path $PSScriptRoot "run_report.ps1"

$Action   = New-ScheduledTaskAction -Execute "powershell.exe" `
            -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$Script`""
$Trigger  = New-ScheduledTaskTrigger -Daily -At 7:30am
$Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew `
            -ExecutionTimeLimit (New-TimeSpan -Minutes 30)

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Force
Write-Host "Registered '$TaskName'. Last result code 0 = success (see Task Scheduler > History)."
