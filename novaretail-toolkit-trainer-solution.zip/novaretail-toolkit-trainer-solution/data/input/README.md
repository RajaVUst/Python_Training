Input files for labs. Day 3's script generates `work/day3/skus_to_check.csv`; put any extra CSVs you want to process here.
