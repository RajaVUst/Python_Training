# Evidence Checklist (maps to curriculum §3.6)

Tick each item; most are produced by `python examples/day8_collect_evidence.py`.

| # | Evidence (curriculum) | Where it comes from | Done |
|---|---|---|---|
| 1 | Tool versions | `evidence/<ts>/01_versions.txt`, `evidence/day1_env_report.json` | ☐ |
| 2 | Project tree | `02_project_tree.txt` | ☐ |
| 3 | Source, tests, config | `src/`, `tests/`, `.env.example`, `pyproject.toml` | ☐ |
| 4 | Setup / install evidence | Day 1 env report + screenshot of `pip install -e .` | ☐ |
| 5 | Configuration files | `.env.example`, README config table | ☐ |
| 6 | Successful workflow | `05_happy_path.txt`, `reports/*.csv/json` | ☐ |
| 7 | Failure → diagnosis → fix | `07`–`10_failure_*.txt` + your notes in RUNBOOK §4 | ☐ |
| 8 | Validation checklist | `SUMMARY.md` + this file | ☐ |
| 9 | Security / data handling | `test_log_file_never_contains_key`, `.gitignore`, RISK R4/R5 | ☐ |
| 10 | Quality gates | `03_tests.txt`, `04_lint.txt` | ☐ |
| 11 | Runbook | `docs/RUNBOOK.md` | ☐ |
| 12 | Risk register | `docs/RISK_REGISTER.md` | ☐ |
| 13 | Final demo notes | your slides / demo script (Day 8) | ☐ |
| 14 | Improvement backlog | `docs/BACKLOG.md` | ☐ |
