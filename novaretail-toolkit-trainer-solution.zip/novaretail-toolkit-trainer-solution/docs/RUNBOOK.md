# Runbook – NovaRetail Automation Toolkit

## 1. Setup
1. Install Python 3.10+ (`python --version` / `py --version`).
2. Create and activate a venv (see README table).
3. `pip install -e ".[dev]"`
4. Copy `.env.example` to `.env`; set `NOVA_API_KEY`.
5. Start the mock API: `python mock_api/server.py`
6. Verify: `python examples/day1_env_check.py` → all PASS.

## 2. Execution
| Task | Command | Expected |
|---|---|---|
| Health | `novaretail health` | log line `API health: {'status': 'ok'...}` exit 0 |
| Report | `novaretail report` | `Report (live): 24 products, 7 low stock` exit 0 |
| Restock plan | `novaretail restock` | `Restock (dry-run): 7 lines, 0 failed` |
| Restock real | `novaretail restock --execute` | 7 orders created |

## 3. Validation
* `pytest` → all tests pass.
* `ruff check src tests` → no findings.
* Open the newest `output/reports/inventory_summary_*.json`: `totals.products == 24`, `source == "live"`.
* `logs/novaretail.log` has a `Report done` line and does **not** contain the API key.

## 4. Troubleshooting
| Symptom | Likely cause | Diagnose | Fix |
|---|---|---|---|
| `CONFIG ERROR: NOVA_API_KEY is not set` (exit 2) | no `.env` or wrong folder | `dir .env` / `ls -a` | copy `.env.example` → `.env`; run from project root or pass `--env-file` |
| `Authentication failed ... 401` (exit 3) | wrong key | compare `.env` with server banner | fix `NOVA_API_KEY` |
| `failed after 4 attempts: ConnectionError` | API not running / wrong port | `curl http://127.0.0.1:8000/health` | start `mock_api/server.py`; check `NOVA_API_BASE_URL` |
| repeated `-> 503` warnings | API overloaded / chaos mode | `curl -X POST .../admin/reset` | wait or reset; report falls back to cache |
| `Report (cache)` | live fetch failed, snapshot used | WARNING line above it | fix API, re-run; tell consumers data is stale (`cache_taken_at`) |
| `no cached snapshot exists` | first ever run and API down | `ls output/snapshots` | get API up, run once live |
| `ModuleNotFoundError: novaretail` | venv not active / not installed | `pip show novaretail-toolkit` | activate venv, `pip install -e .` |
| `Activate.ps1 cannot be loaded` | PowerShell execution policy | – | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `Address already in use` / `WinError 10048` | port 8000 busy | `netstat -ano | findstr 8000` / `lsof -i :8000` | `--port 8001` and update `.env` |
| Scheduled job does nothing | wrong cwd / no venv in scheduler | `logs/cron.log`, Task Scheduler history | use the wrapper scripts with absolute paths |

## 5. Cleanup
* Stop the mock API (Ctrl+C).
* Old reports are pruned automatically (20 kept); snapshots (5 kept).
* Full reset: delete `output/*`, `logs/*`, `work/`, `evidence/`.
* Remove scheduled jobs: `crontab -e` (delete line) / `Unregister-ScheduledTask -TaskName "NovaRetail Daily Report"`.

## 6. Escalation
| Level | When | Who |
|---|---|---|
| L1 | Config / venv / port issues | Learner – this runbook |
| L2 | Tests fail after a code change, unclear stack traces | Peer review / trainer |
| L3 | API contract changed (new fields, 4xx on valid input) | API owner (NovaRetail platform team) |

Always attach: command run, exit code, last 30 log lines, `pip list`, OS.
