# Risk Register

| ID | Type | Risk | Likelihood | Impact | Mitigation in place | Residual / next step |
|---|---|---|---|---|---|---|
| R1 | Operational | API unavailable at run time | Medium | High | Timeouts, retries with backoff, snapshot fallback flagged as `cache` | Stale data if outage is long → alert when `source=cache` (B3) |
| R2 | Operational | Two scheduled runs overlap | Low | Medium | Lock file (Day 7), `MultipleInstances IgnoreNew` on Windows | Lock left after hard crash expires after 1 h |
| R3 | Operational | Disk fills with reports | Low | Medium | Auto-prune (20 reports, 5 snapshots), rotating logs (5 × 1 MB) | No disk-space check |
| R4 | Security | API key leaked in git or logs | Medium | High | `.env` git-ignored, `repr=False`, masked key, log redaction filter, test asserts key absent | Lab key is plaintext in `.env`; use a secrets manager in production (B5) |
| R5 | Security | Orders placed by mistake | Low | High | Restock is dry-run by default; `--execute` required | No approval step / max order value (B4) |
| R6 | Quality | API returns unexpected data shape | Medium | Medium | Dataclass validation with clear `DataValidationError` | Schema changes need code changes |
| R7 | Quality | Products without stock records | Medium | Low | Reported as `missing_skus` and logged as WARNING | – |
| R8 | Maintainability | Logic spread across scripts | – | Medium | Package with single-purpose modules, pure `transform.py` | – |
| R9 | Maintainability | Regression after change | Medium | Medium | 47 automated tests + lint, evidence script | No CI pipeline yet (B1) |
| R10 | Operational | Scheduler environment differs from shell | High | Medium | Wrapper scripts with absolute venv path, logs exit code | – |
