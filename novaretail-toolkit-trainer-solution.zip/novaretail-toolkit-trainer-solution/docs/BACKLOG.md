# Known Limitations and Improvement Backlog

## Limitations
* Single API source; no database. Reports are files only.
* Mock API keeps orders in memory; restarting it loses them.
* Cache fallback may produce stale data (clearly flagged, not prevented).
* No notification (email/chat) on failure — operators must read logs / exit codes.
* Restock rule is simple (`cover × reorder_level`); no lead time or sales velocity.

## Backlog
| ID | Item | Priority | Suggested owner | Notes |
|---|---|---|---|---|
| B1 | CI pipeline running `pytest` + `ruff` on every push | High | Dev lead | GitHub Actions / GitLab CI |
| B2 | Coverage gate ≥ 85 % | High | QA | `pytest --cov=novaretail --cov-fail-under=85` |
| B3 | Alert when report source is `cache` or run fails | High | Ops | webhook / email |
| B4 | Approval threshold for `--execute` (max units / value) | Medium | Product owner | protects against bad data |
| B5 | Secrets from a vault instead of `.env` | Medium | Security | Azure Key Vault / AWS Secrets Manager |
| B6 | Async/concurrent fetching for large catalogues | Low | Dev | `httpx` + `asyncio` |
| B7 | HTML/Excel report output | Low | Dev | `openpyxl` / Jinja2 |
| B8 | Container image + scheduled job in cloud | Low | DevOps | Docker + cron / cloud scheduler |
