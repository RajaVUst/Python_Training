# Trainer solution (do not share before Day 8)

All lab reference solutions applied on top of the learner project:

| Lab | Files |
|---|---|
| 2 | `src/novaretail/transform.py`: `top_value_items`, `units_by_category` |
| 3 | `examples/lab3_watchlist.py`, `data/input/watchlist.csv` |
| 5 | `transform.check_watchlist`, `workflow.load_watchlist` / `run_watchlist`, `cli.py` `watchlist` command |
| 6 | `tests/test_watchlist.py` |

Expected: `pytest` -> 61 passed; `novaretail watchlist --file data/input/watchlist.csv` -> 5 watched, 3 alert(s), 1 unknown.
