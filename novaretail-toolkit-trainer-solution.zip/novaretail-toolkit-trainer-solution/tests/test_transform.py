"""Unit tests for pure functions -- no network, no files. Pattern: Arrange / Act / Assert."""
import pytest

from novaretail.models import InventoryRow, Product, StockLevel
from novaretail.transform import (
    find_low_stock,
    join_inventory,
    plan_restock,
    restock_quantity,
    summarize_by_category,
    total_stock_value,
)


def test_join_reports_missing_skus():
    products = [Product(1, "A-1", "Mouse", "Electronics", 100.0), Product(2, "A-2", "Lamp", "Home", 50.0)]
    stock = [StockLevel("A-1", 5, 10)]

    rows, missing = join_inventory(products, stock)

    assert [r.sku for r in rows] == ["A-1"]
    assert missing == ["A-2"]


def test_low_stock_includes_boundary_and_sorts_by_urgency(sample_rows):
    low = find_low_stock(sample_rows)
    # A-3 shortfall -15, A-1 -5, A-4 0 (on_hand == reorder_level counts as low)
    assert [r.sku for r in low] == ["A-3", "A-1", "A-4"]


def test_summary_by_category(sample_rows):
    summary = summarize_by_category(sample_rows)
    assert list(summary) == ["Electronics", "Grocery", "Home"]          # sorted keys
    assert summary["Electronics"] == {"products": 2, "units": 15, "stock_value": 600.0, "low_stock": 2}


@pytest.mark.parametrize(
    "on_hand, reorder, cover, expected",
    [
        (5, 10, 2, 15),     # normal case
        (0, 10, 2, 20),     # empty shelf
        (30, 10, 2, 0),     # already above target -> never negative
        (5, 10, 3, 25),     # bigger cover factor
    ],
)
def test_restock_quantity(on_hand, reorder, cover, expected):
    row = InventoryRow("X", "x", "c", 1.0, on_hand, reorder)
    assert restock_quantity(row, cover) == expected


def test_restock_quantity_rejects_bad_cover():
    with pytest.raises(ValueError, match="cover_factor"):
        restock_quantity(InventoryRow("X", "x", "c", 1.0, 1, 1), cover_factor=0)


def test_plan_restock_caps_quantity():
    rows = [InventoryRow("BIG", "b", "c", 1.0, on_hand=0, reorder_level=400)]
    assert plan_restock(rows, cover_factor=2, max_qty=500) == [{"sku": "BIG", "name": "b", "quantity": 500}]


def test_total_value(sample_rows):
    assert total_stock_value(sample_rows) == 500 + 2000 + 0 + 100
