"""Lab 6 reference tests for the watchlist feature."""
import pytest

from mock_api.server import API_KEY
from novaretail import cli
from novaretail.exceptions import ApiUnavailableError, DataValidationError
from novaretail.models import InventoryRow
from novaretail.transform import check_watchlist
from novaretail.workflow import load_watchlist, run_watchlist

ROWS = [InventoryRow("A", "Mouse", "Electronics", 1.0, on_hand=5, reorder_level=1)]


@pytest.mark.parametrize("min_stock, alerted", [(6, True), (5, False), (4, False), (0, False)])
def test_threshold_boundaries(min_stock, alerted):
    alerts, unknown = check_watchlist(ROWS, {"A": min_stock})
    assert bool(alerts) is alerted and unknown == []


def test_unknown_and_empty():
    assert check_watchlist(ROWS, {"ZZ": 1}) == ([], ["ZZ"])
    assert check_watchlist([], {}) == ([], [])


def test_load_watchlist(tmp_path):
    p = tmp_path / "w.csv"
    p.write_text("sku,min_stock\nNR-1002,5\nNR-1013, 3\n")
    assert load_watchlist(p) == {"NR-1002": 5, "NR-1013": 3}


def test_load_watchlist_missing_column(tmp_path):
    p = tmp_path / "w.csv"
    p.write_text("sku\nNR-1002\n")
    with pytest.raises(DataValidationError, match="min_stock"):
        load_watchlist(p)


def test_load_watchlist_bad_number(tmp_path):
    p = tmp_path / "w.csv"
    p.write_text("sku,min_stock\nNR-1002,five\n")
    with pytest.raises(DataValidationError, match=":2:"):
        load_watchlist(p)


@pytest.fixture
def watch_file(tmp_path):
    p = tmp_path / "watch.csv"
    p.write_text("sku,min_stock\nNR-1002,5\nNR-1001,5\nNR-9999,1\n")
    return p


@pytest.mark.integration
def test_run_watchlist_against_mock(settings, watch_file):
    res = run_watchlist(settings, watch_file)
    assert [a["sku"] for a in res["alerts"]] == ["NR-1002"]      # on_hand 1 < 5; NR-1001 has 40
    assert res["unknown"] == ["NR-9999"]
    assert res["path"].exists()


@pytest.mark.integration
def test_run_watchlist_api_down(settings, watch_file, chaos):
    chaos(fail_rate=1.0)
    with pytest.raises(ApiUnavailableError):
        run_watchlist(settings, watch_file)


@pytest.mark.integration
def test_cli_watchlist_exit_codes(monkeypatch, settings, watch_file, chaos, capsys):
    monkeypatch.setenv("NOVA_API_BASE_URL", settings.api_base_url)
    monkeypatch.setenv("NOVA_API_KEY", API_KEY)
    monkeypatch.setenv("NOVA_OUTPUT_DIR", str(settings.output_dir))
    monkeypatch.setenv("NOVA_LOG_DIR", str(settings.log_dir))
    monkeypatch.setenv("NOVA_BACKOFF", "0.01")
    assert cli.main(["--env-file", "none.env", "watchlist", "--file", str(watch_file)]) == 0
    assert "1 alert(s)" in capsys.readouterr().out
    chaos(fail_rate=1.0)
    assert cli.main(["--env-file", "none.env", "watchlist", "--file", str(watch_file)]) == 1
