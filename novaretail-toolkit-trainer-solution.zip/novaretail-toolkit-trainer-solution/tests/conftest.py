"""Shared fixtures.

mock_server  : starts the real mock API on a free port in a background thread,
               once per test session (fast, offline, realistic HTTP).
settings     : Settings pointing at that server, writing into a tmp folder,
               with tiny backoff so retry tests run in milliseconds.
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path

import pytest
import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))            # so `import mock_api` works
sys.path.insert(0, str(ROOT / "src"))    # so tests run even without `pip install -e .`

from mock_api.server import API_KEY, make_server  # noqa: E402
from novaretail.config import Settings  # noqa: E402
from novaretail.models import InventoryRow  # noqa: E402


@pytest.fixture(scope="session")
def mock_server():
    srv = make_server("127.0.0.1", 0)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    host, port = srv.server_address
    yield f"http://{host}:{port}"
    srv.shutdown()
    srv.server_close()


@pytest.fixture(autouse=True)
def _reset_server(request):
    """Reset orders/chaos before every test that uses the server."""
    if "mock_server" in request.fixturenames:
        base = request.getfixturevalue("mock_server")
        requests.post(f"{base}/admin/reset", timeout=2)
    yield


@pytest.fixture
def settings(mock_server, tmp_path) -> Settings:
    return Settings(api_base_url=mock_server, api_key=API_KEY, timeout=2, max_retries=2,
                    backoff=0.01, output_dir=tmp_path / "output", log_dir=tmp_path / "logs")


@pytest.fixture
def chaos(mock_server):
    """Call chaos(fail_rate=1.0) inside a test to make the server fail."""
    def _set(fail_rate: float = 0.0, latency: float = 0.0):
        requests.post(f"{mock_server}/admin/chaos", json={"fail_rate": fail_rate, "latency": latency}, timeout=2)
    return _set


@pytest.fixture
def sample_rows() -> list[InventoryRow]:
    return [
        InventoryRow("A-1", "Mouse", "Electronics", 100.0, on_hand=5, reorder_level=10),
        InventoryRow("A-2", "Lamp", "Home", 50.0, on_hand=40, reorder_level=10),
        InventoryRow("A-3", "Rice", "Grocery", 20.0, on_hand=0, reorder_level=15),
        InventoryRow("A-4", "Cable", "Electronics", 10.0, on_hand=10, reorder_level=10),
    ]
