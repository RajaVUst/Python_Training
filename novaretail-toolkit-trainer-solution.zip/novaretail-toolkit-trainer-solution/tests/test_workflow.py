"""End-to-end workflow tests: happy path, cache fallback, restock, CLI exit codes."""
import pytest

from mock_api.server import API_KEY
from novaretail import cli
from novaretail.exceptions import ApiUnavailableError, NovaError
from novaretail.file_ops import read_csv, read_json
from novaretail.workflow import run_report, run_restock

pytestmark = pytest.mark.integration


def test_report_happy_path(settings):
    res = run_report(settings)
    assert res.source == "live" and res.products == 24
    assert res.low_stock > 0
    rows = read_csv(res.csv_path, required=["sku", "stock_value", "is_low_stock"])
    assert len(rows) == 24
    summary = read_json(res.json_path)
    assert summary["totals"]["low_stock"] == res.low_stock
    assert sum(c["products"] for c in summary["by_category"].values()) == 24


def test_report_falls_back_to_cache(settings, chaos):
    run_report(settings)                 # creates a snapshot
    chaos(fail_rate=1.0)                 # API now fails every call
    res = run_report(settings)
    assert res.source == "cache"
    assert read_json(res.json_path)["cache_taken_at"] is not None


def test_report_no_cache_raises(settings, chaos):
    chaos(fail_rate=1.0)
    with pytest.raises(ApiUnavailableError):
        run_report(settings, allow_cache=False)


def test_report_fails_cleanly_without_snapshot(settings, chaos):
    chaos(fail_rate=1.0)
    with pytest.raises(NovaError, match="no cached snapshot"):
        run_report(settings)


def test_restock_dry_run_creates_no_orders(settings, mock_server):
    import requests
    res = run_restock(settings, execute=False)
    assert res["lines"] > 0 and res["failed"] == 0
    orders = requests.get(f"{mock_server}/orders", headers={"X-API-Key": API_KEY}, timeout=2).json()["items"]
    assert orders == []


def test_restock_execute(settings):
    res = run_restock(settings, execute=True)
    rows = read_csv(res["path"])
    assert all(r["status"] == "created" for r in rows)


@pytest.fixture
def cli_env(monkeypatch, settings):
    monkeypatch.setenv("NOVA_API_BASE_URL", settings.api_base_url)
    monkeypatch.setenv("NOVA_API_KEY", API_KEY)
    monkeypatch.setenv("NOVA_OUTPUT_DIR", str(settings.output_dir))
    monkeypatch.setenv("NOVA_LOG_DIR", str(settings.log_dir))
    monkeypatch.setenv("NOVA_BACKOFF", "0.01")
    return settings


def test_cli_report_exit_0(cli_env, capsys):
    assert cli.main(["--env-file", "nonexistent.env", "report"]) == 0
    assert "24 products" in capsys.readouterr().out


def test_cli_bad_key_exit_3(cli_env, monkeypatch):
    monkeypatch.setenv("NOVA_API_KEY", "wrong")
    assert cli.main(["--env-file", "nonexistent.env", "health"]) == 0   # /health is public
    assert cli.main(["--env-file", "nonexistent.env", "report"]) == 3


def test_cli_missing_key_exit_2(monkeypatch):
    monkeypatch.delenv("NOVA_API_KEY", raising=False)
    assert cli.main(["--env-file", "nonexistent.env", "report"]) == 2


def test_log_file_never_contains_key(cli_env):
    cli.main(["--env-file", "nonexistent.env", "report"])
    log_text = (cli_env.log_dir / "novaretail.log").read_text()
    assert "Report done" in log_text
    assert API_KEY not in log_text
