"""Validation tests: bad input must fail loudly with a clear message."""
import pytest

from novaretail.config import Settings
from novaretail.exceptions import ConfigError, DataValidationError
from novaretail.models import Product, StockLevel

GOOD = {"id": 1, "sku": "NR-1001", "name": "Mouse", "category": "Electronics", "price": 799}


def test_product_from_dict_ok():
    p = Product.from_dict(GOOD)
    assert p.price == 799.0 and isinstance(p.price, float)


@pytest.mark.parametrize("bad, message", [
    ({k: v for k, v in GOOD.items() if k != "sku"}, "missing field 'sku'"),
    ({**GOOD, "price": "799"}, "wrong type"),
    ({**GOOD, "price": -1}, "negative price"),
    ({**GOOD, "id": True}, "wrong type"),           # bool is an int subclass -- we reject it
])
def test_product_from_dict_rejects(bad, message):
    with pytest.raises(DataValidationError, match=message):
        Product.from_dict(bad)


def test_stock_rejects_negative():
    with pytest.raises(DataValidationError, match="negative"):
        StockLevel.from_dict({"sku": "A", "on_hand": -3, "reorder_level": 10})


def test_settings_requires_key(monkeypatch):
    monkeypatch.delenv("NOVA_API_KEY", raising=False)
    with pytest.raises(ConfigError, match="NOVA_API_KEY"):
        Settings.from_env(env_file=None)


def test_settings_reads_env_and_masks_key(monkeypatch):
    monkeypatch.setenv("NOVA_API_KEY", "secret-abcd")
    monkeypatch.setenv("NOVA_TIMEOUT", "7.5")
    s = Settings.from_env(env_file=None)
    assert s.timeout == 7.5
    assert s.masked_key == "****abcd"
    assert "secret" not in repr(s)                    # repr=False on api_key


def test_settings_bad_number(monkeypatch):
    monkeypatch.setenv("NOVA_API_KEY", "k")
    monkeypatch.setenv("NOVA_MAX_RETRIES", "three")
    with pytest.raises(ConfigError, match="integer"):
        Settings.from_env(env_file=None)


def test_dotenv_file(tmp_path, monkeypatch):
    monkeypatch.delenv("NOVA_API_KEY", raising=False)
    monkeypatch.delenv("NOVA_API_BASE_URL", raising=False)
    env = tmp_path / ".env"
    env.write_text("# comment\nNOVA_API_KEY='from-file-1234'\nNOVA_API_BASE_URL=http://localhost:9000/\n")
    s = Settings.from_env(env)
    assert s.api_key == "from-file-1234"
    assert s.api_base_url == "http://localhost:9000"
