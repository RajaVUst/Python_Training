"""File tests use pytest's tmp_path -- every test gets a fresh empty folder."""
import os
import time
from datetime import datetime

import pytest

from novaretail.exceptions import DataValidationError
from novaretail.file_ops import (
    cleanup_old_files,
    latest_file,
    read_csv,
    read_json,
    timestamped_path,
    write_csv,
    write_json,
)


def test_csv_round_trip(tmp_path):
    rows = [{"sku": "A", "qty": 1}, {"sku": "B", "qty": 2}]
    path = write_csv(rows, tmp_path / "sub" / "out.csv")          # parent folder is created
    assert read_csv(path, required=["sku", "qty"]) == [{"sku": "A", "qty": "1"}, {"sku": "B", "qty": "2"}]


def test_read_csv_missing_column(tmp_path):
    p = tmp_path / "x.csv"
    p.write_text("sku\nA\n")
    with pytest.raises(DataValidationError, match="qty"):
        read_csv(p, required=["sku", "qty"])


def test_json_round_trip_unicode(tmp_path):
    data = {"name": "Café ₹ 499", "items": [1, 2]}
    assert read_json(write_json(data, tmp_path / "d.json")) == data


def test_bad_json_message(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("{not json")
    with pytest.raises(DataValidationError, match="not valid JSON"):
        read_json(p)


def test_no_temp_files_left(tmp_path):
    write_json({"a": 1}, tmp_path / "a.json")
    assert [f.name for f in tmp_path.iterdir()] == ["a.json"]


def test_timestamped_path():
    p = timestamped_path("out", "report", ".csv", now=datetime(2026, 10, 5, 15, 39, 0))
    assert p.as_posix() == "out/report_20261005_153900.csv"


def test_cleanup_keeps_newest(tmp_path):
    for i in range(5):
        f = tmp_path / f"r_{i}.csv"
        f.write_text("x")
        os.utime(f, (time.time() + i, time.time() + i))           # make mtimes distinct
    removed = cleanup_old_files(tmp_path, "r_*.csv", keep=2)
    assert len(removed) == 3
    assert latest_file(tmp_path, "r_*.csv").name == "r_4.csv"
