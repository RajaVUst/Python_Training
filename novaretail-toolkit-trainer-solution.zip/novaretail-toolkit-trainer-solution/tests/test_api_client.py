"""Integration tests against the real (local) mock API, plus mocks for edge cases."""
from unittest.mock import MagicMock

import pytest
import requests

from novaretail.api_client import NovaApiClient
from novaretail.config import Settings
from novaretail.exceptions import ApiAuthError, ApiError, ApiUnavailableError

pytestmark = pytest.mark.integration


def test_health(settings):
    with NovaApiClient(settings) as c:
        assert c.health()["status"] == "ok"


def test_pagination_returns_all_products(settings):
    with NovaApiClient(settings) as c:
        products = c.get_products(page_size=5)          # 24 products -> 5 pages
    assert len(products) == 24
    assert len({p.sku for p in products}) == 24


def test_inventory(settings):
    with NovaApiClient(settings) as c:
        stock = c.get_inventory()
    assert len(stock) == 24 and all(s.on_hand >= 0 for s in stock)


def test_bad_key_raises_auth_error_without_retry(mock_server):
    s = Settings(api_base_url=mock_server, api_key="wrong", max_retries=3, backoff=0.01)
    with NovaApiClient(s) as c, pytest.raises(ApiAuthError):
        c.get_inventory()


def test_validation_error_is_not_retried(settings):
    with NovaApiClient(settings) as c, pytest.raises(ApiError) as exc_info:
        c.create_order("NR-1001", 0)
    assert exc_info.value.status == 400


def test_create_order(settings):
    with NovaApiClient(settings) as c:
        order = c.create_order("NR-1001", 5)
    assert order["status"] == "created" and order["quantity"] == 5


def test_server_down_raises_unavailable(settings, chaos):
    chaos(fail_rate=1.0)
    with NovaApiClient(settings) as c, pytest.raises(ApiUnavailableError, match="after 3 attempts"):
        c.get_inventory()


def test_connection_refused():
    s = Settings(api_base_url="http://127.0.0.1:9", api_key="k", timeout=0.5, max_retries=1, backoff=0.01)
    with NovaApiClient(s) as c, pytest.raises(ApiUnavailableError):
        c.get_inventory()


def test_retry_then_success_with_mock_session(settings):
    """Unit-level: fake Session -> first call 503, second call 200. Proves retry logic."""
    fail = MagicMock(status_code=503)
    ok = MagicMock(status_code=200)
    ok.json.return_value = {"items": [{"sku": "A", "on_hand": 1, "reorder_level": 2}]}
    session = MagicMock(spec=requests.Session)
    session.headers = {}
    session.request.side_effect = [fail, ok]

    client = NovaApiClient(settings, session=session)
    stock = client.get_inventory()

    assert stock[0].sku == "A"
    assert session.request.call_count == 2
    _, kwargs = session.request.call_args
    assert kwargs["timeout"] == settings.timeout      # timeout always passed
