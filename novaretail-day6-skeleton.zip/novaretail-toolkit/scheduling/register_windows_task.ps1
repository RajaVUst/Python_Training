# registers the Windows scheduled task
# TODO: Day 6 - STEP 11: replace everything in this file with the code from Step 11 of the guide.
