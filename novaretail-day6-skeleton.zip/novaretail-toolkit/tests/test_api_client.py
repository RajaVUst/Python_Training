"""Tests: the API client against the mock API.

TODO: Day 6 - STEP 10: replace everything in this file with the code from Step 10 of the guide.
"""
