# NovaRetail Automation Toolkit - Day 6 skeleton

This project is the starting point for the Day 6 capstone build.

* The folders, `pyproject.toml`, `.env.example`, the mock API (`mock_api/`) and the helper
  scripts in `examples/` are ready to use.
* Every file you write contains only a `TODO: Day 6 - STEP n` line. Follow the
  **Day 6 Capstone Build Guide** step by step and replace each file's contents with the code
  from that step. Run the check at the end of each step before moving on.

Quick start (details in Step 0 of the guide):

    py -3.13 -m venv .venv            # Linux/macOS: python3 -m venv .venv
    .venv\Scripts\Activate.ps1        # Linux/macOS: source .venv/bin/activate
    pip install -e ".[dev]"
    copy .env.example .env            # Linux/macOS: cp .env.example .env
    python mock_api/server.py         # in a second terminal
    python examples/day1_env_check.py

Step 12 replaces this README with the final one.
