"""Configuration: settings from environment variables and .env.

TODO: Day 6 - STEP 2: replace everything in this file with the code from Step 2 of the guide.
"""
