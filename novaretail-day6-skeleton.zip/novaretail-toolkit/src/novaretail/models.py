"""Typed, validated data models.

TODO: Day 6 - STEP 3: replace everything in this file with the code from Step 3 of the guide.
"""
