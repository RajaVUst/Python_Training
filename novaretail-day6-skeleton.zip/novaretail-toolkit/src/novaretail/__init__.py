"""NovaRetail backend automation toolkit."""

__version__ = "1.0.0"

# TODO: Day 6 - STEP 9 completes this file (re-exports Settings and NovaError).
