"""Logging: console + rotating file, secrets redacted.

TODO: Day 6 - STEP 6: replace everything in this file with the code from Step 6 of the guide.
"""
