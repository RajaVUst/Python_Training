"""Lets `python -m novaretail` run the CLI.

TODO: Day 6 - STEP 9: replace everything in this file with the code from Step 9 of the guide.
"""
