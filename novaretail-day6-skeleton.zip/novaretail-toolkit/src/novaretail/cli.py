"""Command-line entry point: novaretail health | report | restock | watchlist.

TODO: Day 6 - STEP 9: replace everything in this file with the code from Step 9 of the guide.
"""
