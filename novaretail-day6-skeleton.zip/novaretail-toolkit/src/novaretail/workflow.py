"""Business workflows: report (with cache fallback), restock, watchlist.

TODO: Day 6 - STEP 8: replace everything in this file with the code from Step 8 of the guide.
"""
