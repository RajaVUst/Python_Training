"""HTTP client for the NovaRetail API: timeouts, retries, pagination.

TODO: Day 6 - STEP 7: replace everything in this file with the code from Step 7 of the guide.
"""
