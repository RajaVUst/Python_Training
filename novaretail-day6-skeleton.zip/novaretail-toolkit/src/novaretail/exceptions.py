"""Exception hierarchy for the toolkit.

TODO: Day 6 - STEP 1: replace everything in this file with the code from Step 1 of the guide.
"""
