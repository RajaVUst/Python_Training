"""File helpers: CSV/JSON, atomic writes, timestamped names, cleanup.

TODO: Day 6 - STEP 5: replace everything in this file with the code from Step 5 of the guide.
"""
