"""Pure business rules: join, low stock, summaries, restock, watchlist.

TODO: Day 6 - STEP 4: replace everything in this file with the code from Step 4 of the guide.
"""
