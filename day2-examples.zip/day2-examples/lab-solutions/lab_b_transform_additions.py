# Paste these two functions at the bottom of src/novaretail/transform.py
# and change the import line to: from collections import Counter, defaultdict

def top_value_items(rows: Iterable[InventoryRow], n: int = 5) -> list[InventoryRow]:
    """The n rows with the highest stock value, highest first.

    >>> rows = [InventoryRow("A", "a", "c", 10.0, 1, 1), InventoryRow("B", "b", "c", 5.0, 10, 1)]
    >>> [r.sku for r in top_value_items(rows, 1)]
    ['B']
    >>> top_value_items(rows, 0)
    []
    """
    if n <= 0:
        return []
    return sorted(rows, key=lambda r: (-r.stock_value, r.sku))[:n]


def units_by_category(rows: Iterable[InventoryRow]) -> dict[str, int]:
    """Total units on hand per category.

    >>> units_by_category([InventoryRow("A", "a", "Home", 1.0, 3, 1), InventoryRow("B", "b", "Home", 1.0, 4, 1)])
    {'Home': 7}
    >>> units_by_category([])
    {}
    """
    totals: Counter[str] = Counter()
    for r in rows:
        totals[r.category] += r.on_hand
    return dict(totals)
