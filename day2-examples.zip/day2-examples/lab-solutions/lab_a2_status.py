def stock_status(on_hand: int, reorder_level: int) -> str:
    """Return OUT, LOW or OK for one product."""
    if on_hand == 0:
        return "OUT"
    if on_hand <= reorder_level:
        return "LOW"
    return "OK"


for on_hand, reorder in [(0, 10), (4, 10), (10, 10), (25, 10)]:
    print(on_hand, reorder, stock_status(on_hand, reorder))
