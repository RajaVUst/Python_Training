from novaretail.models import InventoryRow
from novaretail.transform import top_value_items, units_by_category

rows = [
    InventoryRow("NR-1001", "Wireless Mouse", "Electronics", 799.0, on_hand=40, reorder_level=10),
    InventoryRow("NR-1002", "USB-C Charger 65W", "Electronics", 1899.0, on_hand=1, reorder_level=20),
    InventoryRow("NR-1007", "Basmati Rice 5kg", "Grocery", 699.0, on_hand=57, reorder_level=20),
    InventoryRow("NR-1004", "LED Desk Lamp", "Home", 1299.0, on_hand=14, reorder_level=10),
]
for r in top_value_items(rows, 2):
    print(r.sku, r.name, r.stock_value)
print(units_by_category(rows))
