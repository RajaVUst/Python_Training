quantities = [5, 2, 9, 1, 7, 3]

total = sum(quantities)
average = total / len(quantities)
big_orders = len([q for q in quantities if q >= 5])

print("total:", total)
print("average:", round(average, 2))
print("orders of 5 or more:", big_orders)
