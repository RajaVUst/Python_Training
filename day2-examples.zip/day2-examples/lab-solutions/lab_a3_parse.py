lines = ["NR-1001,2", "NR-1007,5", "NR-1001,3", "NR-1002,x", "NR-1007,4"]

totals = {}
for line in lines:
    sku, qty_text = line.split(",")
    try:
        qty = int(qty_text)
    except ValueError:
        print("skipping bad line:", line)
        continue
    totals[sku] = totals.get(sku, 0) + qty

print(totals)
