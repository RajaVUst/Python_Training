Day 2 example files

practice/        ex01-ex20: every example from the Day 2 document, ready to run.
lab-solutions/   Lab A solutions, Lab B try script, and the two functions to add to transform.py.

Copy the "practice" folder into your novaretail-toolkit project folder, activate the venv,
then run for example:   python practice/ex01_variables.py
ex20_use_project.py and lab_b_try.py need the project installed (Day 1 step 3.3).
lab_b_try.py also needs the Lab B functions added to transform.py first.
