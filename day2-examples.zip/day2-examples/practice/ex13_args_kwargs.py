ORDERS = [
    {"order_id": 101, "store": "BLR-01", "sku": "NR-1001", "qty": 2, "unit_price": 799.0, "status": "paid"},
    {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0, "status": "paid"},
    {"order_id": 103, "store": "BLR-01", "sku": "NR-1011", "qty": 1, "unit_price": 3299.0, "status": "refunded"},
    {"order_id": 104, "store": "HYD-03", "sku": "NR-1001", "qty": 3, "unit_price": 799.0, "status": "paid"},
    {"order_id": 105, "store": "CHN-02", "sku": "NR-1002", "qty": 1, "unit_price": 1899.0, "status": "pending"},
    {"order_id": 106, "store": "BLR-01", "sku": "NR-1007", "qty": 4, "unit_price": 699.0, "status": "paid"},
]


# *values collects any number of positional arguments into a tuple
def total_units(*values):
    print("received:", values)
    return sum(values)


print(total_units(2, 5, 1))


# **options collects any number of named arguments into a dict
def describe_order(order_id, **details):
    print(order_id, details)


describe_order(101, store="BLR-01", rush=True)


# A function can build and return another function
def build_filter(*statuses, **conditions):
    """build_filter("paid", store="BLR-01") returns a test for one order."""
    def matches(order):
        if statuses and order["status"] not in statuses:
            return False
        for key, value in conditions.items():
            if order.get(key) != value:
                return False
        return True
    return matches


paid_in_blr = build_filter("paid", store="BLR-01")
print([o["order_id"] for o in ORDERS if paid_in_blr(o)])

any_status_chn = build_filter(store="CHN-02")
print([o["order_id"] for o in ORDERS if any_status_chn(o)])
