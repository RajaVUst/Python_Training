"""Use the course project's own functions (run from the project folder, venv active)."""
from novaretail.models import InventoryRow
from novaretail.transform import find_low_stock, plan_restock, restock_quantity, summarize_by_category

rows = [
    InventoryRow("NR-1001", "Wireless Mouse", "Electronics", 799.0, on_hand=40, reorder_level=10),
    InventoryRow("NR-1002", "USB-C Charger 65W", "Electronics", 1899.0, on_hand=1, reorder_level=20),
    InventoryRow("NR-1008", "Green Tea 100 bags", "Grocery", 349.0, on_hand=5, reorder_level=20),
    InventoryRow("NR-1004", "LED Desk Lamp", "Home", 1299.0, on_hand=14, reorder_level=10),
]

print("Low stock:", [r.sku for r in find_low_stock(rows)])
print("Restock NR-1002:", restock_quantity(rows[1]))
print("Plan:", plan_restock(rows))
for category, totals in summarize_by_category(rows).items():
    print(category, totals)
