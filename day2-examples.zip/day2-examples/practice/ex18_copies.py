import copy

original = {"store": "BLR-01", "tags": ["vip"]}

alias = original                    # the SAME object, a second name
shallow = dict(original)            # new dict, but the inner list is shared
deep = copy.deepcopy(original)      # a completely independent copy

original["tags"].append("bulk")
original["store"] = "BLR-99"

print("original:", original)
print("alias   :", alias)
print("shallow :", shallow)
print("deep    :", deep)
