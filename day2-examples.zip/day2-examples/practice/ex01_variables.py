# A variable is a name that points to a value.
store = "BLR-01"          # str   (text)
quantity = 5              # int   (whole number)
unit_price = 799.0        # float (decimal number)
is_paid = True            # bool  (True or False)
discount = None           # None  (no value yet)

print(store, quantity, unit_price, is_paid, discount)

# type() tells you what kind of value a variable holds
print(type(store))
print(type(quantity))
print(type(unit_price))
print(type(is_paid))
print(type(discount))

# Variables can be changed (re-assigned)
quantity = quantity + 3
print("New quantity:", quantity)

# f-strings: put variables inside text with {}
total = quantity * unit_price
print(f"Store {store} ordered {quantity} units, total {total}")
