from dataclasses import dataclass, field


@dataclass
class Order:
    order_id: int
    store: str
    sku: str
    qty: int
    unit_price: float
    status: str = "pending"                       # default value
    tags: list[str] = field(default_factory=list)  # safe default list

    @property
    def total(self) -> float:
        """Calculated from other fields, used like a normal attribute."""
        return round(self.qty * self.unit_price, 2)

    def __post_init__(self):
        """Runs automatically after creation: a good place to validate."""
        if self.qty <= 0:
            raise ValueError(f"order {self.order_id}: qty must be positive")


order = Order(101, "BLR-01", "NR-1001", 2, 799.0, "paid")
print(order)
print(order.store, order.total)

# Turn a dictionary into an Order with **
data = {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0}
order2 = Order(**data)
print(order2)

# A typo is caught immediately (with a dict it would silently create a new key)
try:
    order2.qtty
except AttributeError as error:
    print("AttributeError:", error)

# Validation in __post_init__
try:
    Order(999, "BLR-01", "NR-1001", 0, 799.0)
except ValueError as error:
    print("ValueError:", error)


# frozen=True makes it read-only, like data that must not change
@dataclass(frozen=True)
class StockLevel:
    sku: str
    on_hand: int
    reorder_level: int


s = StockLevel("NR-1002", 1, 20)
try:
    s.on_hand = 50
except Exception as error:
    print(type(error).__name__, ":", error)
