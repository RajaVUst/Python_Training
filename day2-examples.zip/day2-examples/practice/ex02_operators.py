price = 799.0
qty = 3

# Arithmetic
print("add      ", price + 100)
print("subtract ", price - 100)
print("multiply ", price * qty)
print("divide   ", 10 / 4)       # always gives a float
print("floor div", 10 // 4)      # whole part only
print("remainder", 10 % 4)       # what is left over
print("power    ", 2 ** 10)

# Comparison: the answer is always True or False
print("qty > 2   ", qty > 2)
print("qty == 3  ", qty == 3)     # == compares; = assigns
print("qty != 3  ", qty != 3)

# Logical: and, or, not
on_hand = 4
reorder_level = 10
is_active = True
needs_restock = on_hand <= reorder_level and is_active
print("needs restock?", needs_restock)
print("not active?   ", not is_active)

# Decimals are stored approximately, so round money before showing it
print("0.1 + 0.2  ", 0.1 + 0.2)
print("rounded    ", round(0.1 + 0.2, 2))
