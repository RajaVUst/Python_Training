ORDERS = [
    {"order_id": 101, "store": "BLR-01", "sku": "NR-1001", "qty": 2, "unit_price": 799.0, "status": "paid"},
    {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0, "status": "paid"},
    {"order_id": 103, "store": "BLR-01", "sku": "NR-1011", "qty": 1, "unit_price": 3299.0, "status": "refunded"},
    {"order_id": 104, "store": "HYD-03", "sku": "NR-1001", "qty": 3, "unit_price": 799.0, "status": "paid"},
    {"order_id": 105, "store": "CHN-02", "sku": "NR-1002", "qty": 1, "unit_price": 1899.0, "status": "pending"},
    {"order_id": 106, "store": "BLR-01", "sku": "NR-1007", "qty": 4, "unit_price": 699.0, "status": "paid"},
]

# Loop version
paid_loop = []
for o in ORDERS:
    if o["status"] == "paid":
        paid_loop.append(o)

# Comprehension version: the same in one line
paid = [o for o in ORDERS if o["status"] == "paid"]
print(len(paid_loop), len(paid))

# Dict comprehension: order id -> value
revenue = {o["order_id"]: o["qty"] * o["unit_price"] for o in paid}
print(revenue)

# Set comprehension: unique stores
print(sorted({o["store"] for o in ORDERS}))

# sorted() with key=: sort by any rule you choose
top2 = sorted(paid, key=lambda o: o["qty"] * o["unit_price"], reverse=True)[:2]
print("top 2:", [o["order_id"] for o in top2])

# Useful built-ins
print("any refunded?", any(o["status"] == "refunded" for o in ORDERS))
print("all qty > 0? ", all(o["qty"] > 0 for o in ORDERS))
print("paid units:  ", sum(o["qty"] for o in paid))
print("max price:   ", max(o["unit_price"] for o in ORDERS))
