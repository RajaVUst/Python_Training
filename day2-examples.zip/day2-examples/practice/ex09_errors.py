# This program fails on purpose. Read the error from the BOTTOM up.
stock = {"NR-1001": 40}

def get_stock(sku):
    return stock[sku]

print(get_stock("NR-1001"))
print(get_stock("NR-9999"))   # this SKU does not exist
