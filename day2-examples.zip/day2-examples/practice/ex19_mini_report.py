"""NovaRetail mini stock report: everything from Day 2 in one program."""
from collections import Counter, defaultdict
from dataclasses import dataclass

# ---------------------------------------------------------------- data
# Raw data as it might arrive from an API: lists of dictionaries.
PRODUCTS = [
    {"sku": "NR-1001", "name": "Wireless Mouse", "category": "Electronics", "price": 799.0},
    {"sku": "NR-1002", "name": "USB-C Charger 65W", "category": "Electronics", "price": 1899.0},
    {"sku": "NR-1004", "name": "LED Desk Lamp", "category": "Home", "price": 1299.0},
    {"sku": "NR-1007", "name": "Basmati Rice 5kg", "category": "Grocery", "price": 699.0},
    {"sku": "NR-1008", "name": "Green Tea 100 bags", "category": "Grocery", "price": 349.0},
    {"sku": "NR-1010", "name": "Cotton T-Shirt", "category": "Apparel", "price": 499.0},
    {"sku": "NR-1013", "name": "Mechanical Keyboard", "category": "Electronics", "price": 4599.0},
    {"sku": "NR-1099", "name": "Gift Card", "category": "Other", "price": 500.0},
]
STOCK = [
    {"sku": "NR-1001", "on_hand": 40, "reorder_level": 10},
    {"sku": "NR-1002", "on_hand": 1, "reorder_level": 20},
    {"sku": "NR-1004", "on_hand": 14, "reorder_level": 10},
    {"sku": "NR-1007", "on_hand": 57, "reorder_level": 20},
    {"sku": "NR-1008", "on_hand": 5, "reorder_level": 20},
    {"sku": "NR-1010", "on_hand": 1, "reorder_level": 10},
    {"sku": "NR-1013", "on_hand": 1, "reorder_level": 20},
]


# ---------------------------------------------------------------- model
@dataclass(frozen=True)
class Row:
    sku: str
    name: str
    category: str
    price: float
    on_hand: int
    reorder_level: int

    @property
    def stock_value(self) -> float:
        return round(self.price * self.on_hand, 2)

    @property
    def is_low(self) -> bool:
        return self.on_hand <= self.reorder_level


# ---------------------------------------------------------------- functions
def join(products: list[dict], stock: list[dict]) -> tuple[list[Row], list[str]]:
    """Combine products with their stock. Also return SKUs that have no stock record."""
    stock_by_sku = {s["sku"]: s for s in stock}          # dict: instant lookup by SKU
    rows, missing = [], []
    for p in products:
        s = stock_by_sku.get(p["sku"])
        if s is None:
            missing.append(p["sku"])
            continue
        rows.append(Row(p["sku"], p["name"], p["category"], p["price"], s["on_hand"], s["reorder_level"]))
    return rows, missing


def low_stock(rows: list[Row]) -> list[Row]:
    """Low-stock rows, most urgent (largest shortfall) first."""
    return sorted((r for r in rows if r.is_low), key=lambda r: r.on_hand - r.reorder_level)


def value_by_category(rows: list[Row]) -> dict[str, float]:
    """Total stock value per category."""
    totals: defaultdict[str, float] = defaultdict(float)
    for r in rows:
        totals[r.category] += r.stock_value
    return dict(sorted(totals.items()))


def restock_quantity(row: Row, cover: int = 2) -> int:
    """Units to order so stock reaches cover x reorder level (never negative)."""
    return max(row.reorder_level * cover - row.on_hand, 0)


# ---------------------------------------------------------------- report
rows, missing = join(PRODUCTS, STOCK)
print(f"Products with stock: {len(rows)}   missing stock record: {missing}")
print()

print("Stock value by category")
for category, value in value_by_category(rows).items():
    print(f"  {category:<12} {value:>12,.2f}")
print()

print("Low stock - restock plan")
print(f"  {'SKU':<8} {'Name':<20} {'On hand':>7} {'Reorder':>7} {'Order':>6}")
for r in low_stock(rows):
    print(f"  {r.sku:<8} {r.name:<20} {r.on_hand:>7} {r.reorder_level:>7} {restock_quantity(r):>6}")
print()

counts = Counter("LOW" if r.is_low else "OK" for r in rows)
print("Status count:", dict(counts))
