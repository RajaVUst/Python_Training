# def creates a function: a named, reusable piece of code.
def line_total(qty: int, unit_price: float) -> float:
    """Return the total for one order line."""
    return qty * unit_price


print(line_total(2, 799.0))
print(line_total(qty=5, unit_price=699.0))   # arguments by name


# Default values make an argument optional.
# The * makes discount_pct keyword-only: it must be passed by name.
def line_total_v2(qty: int, unit_price: float, *, discount_pct: float = 0.0) -> float:
    """Return the line total after an optional percentage discount."""
    if not 0 <= discount_pct <= 100:
        raise ValueError("discount_pct must be 0..100")
    return round(qty * unit_price * (1 - discount_pct / 100), 2)


print(line_total_v2(2, 799.0))
print(line_total_v2(2, 799.0, discount_pct=10))

try:
    line_total_v2(2, 799.0, 10)        # not allowed: discount must be named
except TypeError as error:
    print("TypeError:", error)

try:
    line_total_v2(2, 799.0, discount_pct=150)
except ValueError as error:
    print("ValueError:", error)


# A function that RETURNS can be reused; one that only PRINTS cannot.
def describe(qty: int) -> str:
    return "bulk" if qty >= 5 else "single"


labels = [describe(q) for q in [1, 5, 3]]
print(labels)

# help() shows the docstring
help(line_total)
