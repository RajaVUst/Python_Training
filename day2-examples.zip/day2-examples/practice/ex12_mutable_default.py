# WRONG: the default list is created once and shared by every call
def add_tag_bad(tag, tags=[]):
    tags.append(tag)
    return tags


print(add_tag_bad("vip"))
print(add_tag_bad("bulk"))      # surprise: still has "vip"


# RIGHT: use None and create a new list inside the function
def add_tag_good(tag, tags=None):
    if tags is None:
        tags = []
    tags.append(tag)
    return tags


print(add_tag_good("vip"))
print(add_tag_good("bulk"))
