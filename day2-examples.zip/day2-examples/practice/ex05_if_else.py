on_hand = 4
reorder_level = 10

# The indented lines run only when the condition is True.
if on_hand == 0:
    status = "OUT OF STOCK"
elif on_hand <= reorder_level:
    status = "LOW"
else:
    status = "OK"

print(f"on_hand={on_hand} -> {status}")

# Try a few values
for value in [0, 4, 10, 25]:
    if value == 0:
        label = "OUT OF STOCK"
    elif value <= reorder_level:
        label = "LOW"
    else:
        label = "OK"
    print(value, label)
