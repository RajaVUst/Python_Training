# A dictionary maps a KEY to a VALUE
product = {
    "sku": "NR-1001",
    "name": "Wireless Mouse",
    "price": 799.0,
}

print(product["name"])               # look up by key
product["price"] = 749.0             # change a value
product["category"] = "Electronics"  # add a new key
print(product)

# .get() returns a default instead of crashing when the key is missing
print(product.get("colour", "not set"))

# Loop over keys and values
for key, value in product.items():
    print(f"{key:>10}: {value}")

# A dictionary of stock levels, keyed by SKU
stock = {"NR-1001": 40, "NR-1002": 1, "NR-1013": 1}
print("NR-1002 on hand:", stock["NR-1002"])
stock["NR-1002"] += 20               # restocked
print(stock)
