import time

# The same 6 orders, used in every Day 2 example
ORDERS = [
    {"order_id": 101, "store": "BLR-01", "sku": "NR-1001", "qty": 2, "unit_price": 799.0, "status": "paid"},
    {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0, "status": "paid"},
    {"order_id": 103, "store": "BLR-01", "sku": "NR-1011", "qty": 1, "unit_price": 3299.0, "status": "refunded"},
    {"order_id": 104, "store": "HYD-03", "sku": "NR-1001", "qty": 3, "unit_price": 799.0, "status": "paid"},
    {"order_id": 105, "store": "CHN-02", "sku": "NR-1002", "qty": 1, "unit_price": 1899.0, "status": "pending"},
    {"order_id": 106, "store": "BLR-01", "sku": "NR-1007", "qty": 4, "unit_price": 699.0, "status": "paid"},
]

# list: ordered, duplicates allowed
skus_list = [o["sku"] for o in ORDERS]
# set: unique values only, very fast "is it in here?"
skus_set = {o["sku"] for o in ORDERS}
# dict: look up a whole order by its id
order_index = {o["order_id"]: o for o in ORDERS}
# tuple: a fixed record that cannot change
store_location = ("BLR-01", 12.97, 77.59)

print("list :", skus_list)
print("set  :", sorted(skus_set))
print("dict :", order_index[104]["store"])
print("tuple:", store_location)

# Why the choice matters: search 100,000 SKUs 1,000 times
big_list = [f"NR-{i}" for i in range(100_000)]
big_set = set(big_list)

start = time.perf_counter()
for _ in range(1_000):
    "NR-99999" in big_list
list_time = time.perf_counter() - start

start = time.perf_counter()
for _ in range(1_000):
    "NR-99999" in big_set
set_time = time.perf_counter() - start

print(f"list search: {list_time:.3f} s")
print(f"set search : {set_time:.5f} s")
print(f"the set was about {list_time / set_time:,.0f} times faster")
