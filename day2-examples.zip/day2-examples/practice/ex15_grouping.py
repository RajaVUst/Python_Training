from collections import Counter, defaultdict

ORDERS = [
    {"order_id": 101, "store": "BLR-01", "sku": "NR-1001", "qty": 2, "unit_price": 799.0, "status": "paid"},
    {"order_id": 102, "store": "CHN-02", "sku": "NR-1007", "qty": 5, "unit_price": 699.0, "status": "paid"},
    {"order_id": 103, "store": "BLR-01", "sku": "NR-1011", "qty": 1, "unit_price": 3299.0, "status": "refunded"},
    {"order_id": 104, "store": "HYD-03", "sku": "NR-1001", "qty": 3, "unit_price": 799.0, "status": "paid"},
    {"order_id": 105, "store": "CHN-02", "sku": "NR-1002", "qty": 1, "unit_price": 1899.0, "status": "pending"},
    {"order_id": 106, "store": "BLR-01", "sku": "NR-1007", "qty": 4, "unit_price": 699.0, "status": "paid"},
]

paid = [o for o in ORDERS if o["status"] == "paid"]

# Grouping by hand with a normal dict
revenue_plain = {}
for o in paid:
    store = o["store"]
    if store not in revenue_plain:
        revenue_plain[store] = 0.0
    revenue_plain[store] += o["qty"] * o["unit_price"]
print("plain dict :", revenue_plain)

# defaultdict creates the starting value for you
revenue_by_store = defaultdict(float)
for o in paid:
    revenue_by_store[o["store"]] += o["qty"] * o["unit_price"]
print("defaultdict:", dict(revenue_by_store))

# Counter counts things
status_counts = Counter(o["status"] for o in ORDERS)
print(status_counts)

units_by_sku = Counter()
for o in paid:
    units_by_sku[o["sku"]] += o["qty"]
print(units_by_sku)
print("best seller:", units_by_sku.most_common(1))
