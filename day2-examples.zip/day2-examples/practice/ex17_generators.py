# A normal function returns everything at once.
# A generator (a function with yield) hands back one item at a time.

def batches(items, size):
    batch = []
    for item in items:
        batch.append(item)
        if len(batch) == size:
            yield batch          # pause here and hand over this batch
            batch = []
    if batch:
        yield batch              # whatever is left at the end


order_ids = [101, 102, 103, 104, 105, 106]
for b in batches(order_ids, 4):
    print("batch:", b)


# Like pages from an API: produce page after page until there are no more
def fake_pages():
    pages = {1: ["NR-1001", "NR-1002"], 2: ["NR-1003", "NR-1004"], 3: ["NR-1005"]}
    page = 1
    while page in pages:
        print(f"  (fetching page {page})")
        yield from pages[page]   # hand over each item of the page
        page += 1


for sku in fake_pages():
    print("got", sku)

# A generator expression: like a list comprehension but with ( ), no list is built
total = sum(q for q in [2, 5, 1, 3])
print("total units:", total)
