skus = ["NR-1001", "NR-1007", "NR-1002"]

print(skus[0])          # first item
print(skus[-1])         # last item
print(len(skus))        # how many items: 3

skus.append("NR-1011")  # add at the end
print(skus)

skus.remove("NR-1007")  # remove by value
print(skus)

print("NR-1002" in skus)   # is it in the list? True

quantities = [5, 2, 9, 1]
print(sum(quantities), min(quantities), max(quantities))
print(sorted(quantities))                 # new sorted list
print(sorted(quantities, reverse=True))   # biggest first

# Loop over a list and build a new one
doubled = []
for q in quantities:
    doubled.append(q * 2)
print(doubled)
