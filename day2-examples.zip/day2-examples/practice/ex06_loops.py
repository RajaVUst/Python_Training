# for: repeat once for each item
stores = ["BLR-01", "CHN-02", "HYD-03"]
for store in stores:
    print("Checking store", store)

# range(n) gives 0, 1, ... n-1
for i in range(3):
    print("attempt", i + 1)

# enumerate gives the position and the item
for position, store in enumerate(stores, start=1):
    print(position, store)

# while: repeat while a condition is True
stock = 10
day = 0
while stock > 0:
    day += 1          # same as day = day + 1
    stock -= 3        # sell 3 per day
print("Stock ran out after", day, "days")

# break stops the loop; continue skips to the next item
for qty in [5, 0, 7, -1, 9]:
    if qty == 0:
        continue      # skip zeros
    if qty < 0:
        print("bad quantity, stopping")
        break
    print("processing", qty)
