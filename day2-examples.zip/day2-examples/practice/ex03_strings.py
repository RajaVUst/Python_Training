name = "  Wireless Mouse  "
sku = "nr-1001"

print(name.strip())            # remove spaces at both ends
print(sku.upper())             # NR-1001
print(sku.replace("-", "_"))   # nr_1001
print(len(sku))                # number of characters: 7

# Indexing and slicing: positions start at 0
code = "NR-1001"
print(code[0])        # first character: N
print(code[-1])       # last character: 1
print(code[0:2])      # characters 0 and 1: NR
print(code[3:])       # from position 3 to the end: 1001

# Checking text
print(code.startswith("NR"))   # True
print("100" in code)           # True

# Splitting and joining
line = "NR-1001,Wireless Mouse,799"
parts = line.split(",")
print(parts)                   # a list of 3 strings
print(" | ".join(parts))

# f-string formatting for reports
price = 1899.5
print(f"Price: {price:.2f}")          # 2 decimal places
print(f"Price: {price:,.2f}")         # thousands separator
print(f"[{'SKU':<10}][{'Qty':>5}]")   # left / right aligned columns
