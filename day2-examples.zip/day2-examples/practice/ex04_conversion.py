# Data from files and APIs often arrives as TEXT. Convert before doing maths.
qty_text = "12"
price_text = "699.50"

print(qty_text + qty_text)        # joins text: 1212 (not what we want!)

qty = int(qty_text)               # text -> whole number
price = float(price_text)         # text -> decimal number
print(qty + qty)                  # 24
print(qty * price)                # 8394.0

print(str(qty) + " units")        # number -> text

# A conversion that cannot work raises an error. Catch it to keep going.
for raw in ["5", "five", "7"]:
    try:
        print("parsed", int(raw))
    except ValueError:
        print("not a number:", raw)
